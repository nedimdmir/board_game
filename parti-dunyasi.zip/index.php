<?php
/**
 * PartyCraft: Wonder Board - All-In-One Edition
 * 
 * 🎮 TEK DOSYA SUNUCU + OYUN SÜRÜMÜ (All-in-One Single File Edition)
 * Bu tek dosyayı (index.php) PHP destekleyen herhangi bir web hostinge yükleyip hemen oynayabilirsiniz.
 * Harici veritabanı, npm, composer veya ek dosya gerekmez!
 * 
 * - Tarayıcıdan açıldığında: Tam HTML5/CSS/Vanilla JS oyun arayüzünü sunar.
 * - Çok oyunculu oda, zar, hamle ve mini oyun isteklerinde: JSON dosya tabanlı PHP arka ucunu çalıştırır.
 */

$isApiRequest = (
    isset($_GET['action']) || 
    isset($_POST['action']) || 
    (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') || 
    (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS')
);

if ($isApiRequest) {
/**
 * PartyCraft: Wonder Board - Lightweight Multi-Player PHP Backend
 * 
 * Zero external libraries, zero database required.
 * Stores room state in local JSON files inside 'rooms/' with atomic file locking.
 * Supports up to 4 players, automatic bot substitution, reconnection, and authoritative game state.
 */

// Error handling & headers
error_reporting(0);
ini_set('display_errors', '0');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Ensure data storage directory exists and is secured
$roomsDir = __DIR__ . DIRECTORY_SEPARATOR . 'rooms';
if (!is_dir($roomsDir)) {
    @mkdir($roomsDir, 0777, true);
    // Protect JSON files from direct web browsing
    @file_put_contents($roomsDir . DIRECTORY_SEPARATOR . '.htaccess', "Deny from all\n");
    @file_put_contents($roomsDir . DIRECTORY_SEPARATOR . 'index.html', "<!-- Protected -->");
}

$storageWritable = is_writable($roomsDir);

// Helper: Parse JSON input
function getRequestData() {
    $raw = file_get_contents('php://input');
    if (!empty($raw)) {
        $json = json_decode($raw, true);
        if (is_array($json)) return $json;
    }
    return $_REQUEST;
}

// Helper: Response helper
function sendJson($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function sendError($msg, $code = 400) {
    sendJson(['type' => 'error', 'message' => $msg], $code);
}

// Garbage Collector: Remove rooms older than 3 hours (5% probability)
if (mt_rand(1, 20) === 1 && is_dir($roomsDir)) {
    $now = time();
    $files = @glob($roomsDir . DIRECTORY_SEPARATOR . '*.json');
    if ($files) {
        foreach ($files as $f) {
            if ($now - @filemtime($f) > 10800) { // 3 hours
                @unlink($f);
            }
        }
    }
}

// Board Tiles Generator
function generateBoardForTheme($theme = 'istanbul') {
    if ($theme === 'cyber') $theme = 'tokyo';
    if ($theme === 'candy') $theme = 'paris';
    if ($theme === 'tropics') $theme = 'istanbul';

    if ($theme === 'tokyo') {
        return [
            ['id' => 0, 'type' => 'start', 'title' => 'Shibuya Meydanı', 'desc' => '+10 Altın Başlangıç Bonusu!', 'icon' => 'flag', 'color' => '#10B981'],
            ['id' => 1, 'type' => 'coin', 'amount' => 4, 'title' => 'Akihabara Tech', 'desc' => '+4 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 2, 'type' => 'mystery', 'title' => 'Gacha Kapsülü', 'desc' => 'Gizemli anime sürprizi!', 'icon' => 'sparkles', 'color' => '#EC4899'],
            ['id' => 3, 'type' => 'coin', 'amount' => 5, 'title' => 'Shinjuku Neon', 'desc' => '+5 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 4, 'type' => 'freeze', 'title' => 'EMP Siber Şok', 'desc' => 'Sistem dondu! 1 tur eşya kullanamazsın!', 'icon' => 'zap', 'color' => '#0284C7'],
            ['id' => 5, 'type' => 'shop', 'title' => 'Harajuku Market', 'desc' => 'Fütüristik eşyalar satın al!', 'icon' => 'shopping-bag', 'color' => '#F59E0B'],
            ['id' => 6, 'type' => 'coin', 'amount' => 6, 'title' => 'Ginza Lüksü', 'desc' => '+6 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 7, 'type' => 'star', 'title' => 'Tokyo Skytree', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24'],
            ['id' => 8, 'type' => 'warp', 'target' => 20, 'title' => 'Shinkansen Hızlı Tren', 'desc' => '20. karoya ışınlan!', 'icon' => 'zap', 'color' => '#06B6D4'],
            ['id' => 9, 'type' => 'coin', 'amount' => 4, 'title' => 'Roppongi Gece', 'desc' => '+4 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 10, 'type' => 'jail', 'title' => 'Siber Kodes', 'desc' => '1 tur kilitli kal veya 5 altın kefalet öde!', 'icon' => 'shield', 'color' => '#DC2626'],
            ['id' => 11, 'type' => 'trap', 'penalty' => 5, 'title' => 'Neon Aşırı Yükleme', 'desc' => '-5 Altın hasarı!', 'icon' => 'flame', 'color' => '#EF4444'],
            ['id' => 12, 'type' => 'mystery', 'title' => 'Şans Kedisi Maneki', 'desc' => 'Şans ruletini çevir!', 'icon' => 'sparkles', 'color' => '#EC4899'],
            ['id' => 13, 'type' => 'bank', 'title' => 'Tokyo Merkez Bankası', 'desc' => 'Biriken havuz altınlarını topla!', 'icon' => 'coins', 'color' => '#10B981'],
            ['id' => 14, 'type' => 'shop', 'title' => 'Akiba Dükkanı', 'desc' => 'Siber eşyalar!', 'icon' => 'shopping-bag', 'color' => '#F59E0B'],
            ['id' => 15, 'type' => 'star', 'title' => 'Tokyo Kulesi', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24'],
            ['id' => 16, 'type' => 'coin', 'amount' => 4, 'title' => 'Ueno Parkı', 'desc' => '+4 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 17, 'type' => 'slip', 'steps' => -3, 'title' => 'Islak Ramen Zemini', 'desc' => '3 adım geri kaydın!', 'icon' => 'undo-2', 'color' => '#EAB308'],
            ['id' => 18, 'type' => 'mystery', 'title' => 'Torii Çarkı', 'desc' => 'Kutsal tapınak ödülü!', 'icon' => 'sparkles', 'color' => '#EC4899'],
            ['id' => 19, 'type' => 'coin', 'amount' => 5, 'title' => 'Asakusa Feneri', 'desc' => '+5 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 20, 'type' => 'duel', 'title' => 'Samuray Düellosu', 'desc' => 'Rakipten altın kap!', 'icon' => 'swords', 'color' => '#EC4899'],
            ['id' => 21, 'type' => 'reverse', 'title' => 'Zaman Bükülmesi', 'desc' => 'Sonraki zarda ters yöne yürü!', 'icon' => 'undo-2', 'color' => '#9333EA'],
            ['id' => 22, 'type' => 'coin', 'amount' => 6, 'title' => 'Tsukiji Balık Pazarı', 'desc' => '+6 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 23, 'type' => 'star', 'title' => 'Fuji Dağı Kaidesi', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24'],
            ['id' => 24, 'type' => 'tax', 'title' => 'Tokyo Belediye Vergisi', 'desc' => '%25 Altın cezası en fakir oyuncuya gider!', 'icon' => 'coins', 'color' => '#E11D48'],
            ['id' => 25, 'type' => 'mystery', 'title' => 'Sakura Sandığı', 'desc' => 'Şansını sına!', 'icon' => 'sparkles', 'color' => '#EC4899'],
            ['id' => 26, 'type' => 'shop', 'title' => 'Shibuya Alışveriş', 'desc' => 'Nadir taktik eşyaları!', 'icon' => 'shopping-bag', 'color' => '#F59E0B'],
            ['id' => 27, 'type' => 'coin', 'amount' => 8, 'title' => 'İmparatorluk Sarayı', 'desc' => '+8 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 28, 'type' => 'trap', 'penalty' => 5, 'title' => 'Yakuza Pususu', 'desc' => '-5 Altın kaybettin!', 'icon' => 'flame', 'color' => '#EF4444'],
            ['id' => 29, 'type' => 'duel', 'title' => 'Sumo Arenası', 'desc' => 'Liderden altın arakla!', 'icon' => 'swords', 'color' => '#EC4899'],
            ['id' => 30, 'type' => 'coin', 'amount' => 5, 'title' => 'Omotesando Caddesi', 'desc' => '+5 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 31, 'type' => 'star', 'title' => 'Meiji Tapınağı', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24']
        ];
    }

    if ($theme === 'paris') {
        return [
            ['id' => 0, 'type' => 'start', 'title' => 'Eyfel Kulesi', 'desc' => '+10 Altın Başlangıç Bonusu!', 'icon' => 'flag', 'color' => '#10B981'],
            ['id' => 1, 'type' => 'coin', 'amount' => 4, 'title' => 'Champs-Élysées', 'desc' => '+4 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 2, 'type' => 'mystery', 'title' => 'Louvre Tablosu', 'desc' => 'Mona Lisa gülümsedi!', 'icon' => 'sparkles', 'color' => '#8B5CF6'],
            ['id' => 3, 'type' => 'coin', 'amount' => 5, 'title' => 'Kruvasan Fırını', 'desc' => '+5 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 4, 'type' => 'trap', 'penalty' => 4, 'title' => 'Parke Taşı Çukuru', 'desc' => '-4 Altın kaybettin!', 'icon' => 'flame', 'color' => '#EF4444'],
            ['id' => 5, 'type' => 'shop', 'title' => 'Fransız Butiği', 'desc' => 'Lüks parti eşyaları al!', 'icon' => 'shopping-bag', 'color' => '#F59E0B'],
            ['id' => 6, 'type' => 'coin', 'amount' => 6, 'title' => 'Notre-Dame Avlusu', 'desc' => '+6 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 7, 'type' => 'star', 'title' => 'Zafer Takı', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24'],
            ['id' => 8, 'type' => 'warp', 'target' => 18, 'title' => 'Sen Nehri Teknesi', 'desc' => '18. karoya yüz!', 'icon' => 'zap', 'color' => '#06B6D4'],
            ['id' => 9, 'type' => 'coin', 'amount' => 4, 'title' => 'Montmartre Tepesi', 'desc' => '+4 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 10, 'type' => 'jail', 'title' => 'Bastille Kalesi', 'desc' => '1 tur kilitli kal veya 5 altın kefalet öde!', 'icon' => 'shield', 'color' => '#DC2626'],
            ['id' => 11, 'type' => 'tax', 'title' => 'Lüks Moda Vergisi', 'desc' => '%25 Altın cezası en fakir oyuncuya dağıtılır!', 'icon' => 'coins', 'color' => '#E11D48'],
            ['id' => 12, 'type' => 'mystery', 'title' => 'Cam Piramit', 'desc' => 'Rulet çarkını çevir!', 'icon' => 'sparkles', 'color' => '#8B5CF6'],
            ['id' => 13, 'type' => 'bank', 'title' => 'Banque de France', 'desc' => 'Kasadaki tüm altınları süpür!', 'icon' => 'coins', 'color' => '#10B981'],
            ['id' => 14, 'type' => 'shop', 'title' => 'Parfüm Marketi', 'desc' => 'Taktik eşyaları!', 'icon' => 'shopping-bag', 'color' => '#F59E0B'],
            ['id' => 15, 'type' => 'star', 'title' => 'Sacre-Coeur', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24'],
            ['id' => 16, 'type' => 'coin', 'amount' => 4, 'title' => 'Latin Mahallesi', 'desc' => '+4 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 17, 'type' => 'slip', 'steps' => -3, 'title' => 'Eriyen Dondurma', 'desc' => '3 adım geri kaydın!', 'icon' => 'undo-2', 'color' => '#EAB308'],
            ['id' => 18, 'type' => 'mystery', 'title' => 'Moulin Rouge Çarkı', 'desc' => 'Büyük ödüller!', 'icon' => 'sparkles', 'color' => '#8B5CF6'],
            ['id' => 19, 'type' => 'coin', 'amount' => 5, 'title' => 'Lüksemburg Bahçesi', 'desc' => '+5 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 20, 'type' => 'duel', 'title' => 'Eskrim Meydanı', 'desc' => 'Rakipten altın kap!', 'icon' => 'swords', 'color' => '#EC4899'],
            ['id' => 21, 'type' => 'reverse', 'title' => 'Sen Nehri Akıntısı', 'desc' => 'Sonraki zarda ters yöne yürü!', 'icon' => 'undo-2', 'color' => '#9333EA'],
            ['id' => 22, 'type' => 'coin', 'amount' => 6, 'title' => 'Opera Garnier', 'desc' => '+6 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 23, 'type' => 'star', 'title' => 'Pantheon Kaidesi', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24'],
            ['id' => 24, 'type' => 'freeze', 'title' => 'Paris Kar Fırtınası', 'desc' => '1 tur eşya kullanımın engellendi!', 'icon' => 'zap', 'color' => '#0284C7'],
            ['id' => 25, 'type' => 'mystery', 'title' => 'Sanatçı Sandığı', 'desc' => 'Şansını sına!', 'icon' => 'sparkles', 'color' => '#8B5CF6'],
            ['id' => 26, 'type' => 'shop', 'title' => 'Fransız Butiği', 'desc' => 'Eşya kuşan!', 'icon' => 'shopping-bag', 'color' => '#F59E0B'],
            ['id' => 27, 'type' => 'coin', 'amount' => 8, 'title' => 'Vendome Meydanı', 'desc' => '+8 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 28, 'type' => 'trap', 'penalty' => 5, 'title' => 'Metro Arızası', 'desc' => '-5 Altın!', 'icon' => 'flame', 'color' => '#EF4444'],
            ['id' => 29, 'type' => 'duel', 'title' => 'Şövalye Düellosu', 'desc' => 'Liderden altın arakla!', 'icon' => 'swords', 'color' => '#EC4899'],
            ['id' => 30, 'type' => 'coin', 'amount' => 5, 'title' => 'Saint-Germain', 'desc' => '+5 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 31, 'type' => 'star', 'title' => 'Louvre Sarayı', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24']
        ];
    }

    if ($theme === 'newyork') {
        return [
            ['id' => 0, 'type' => 'start', 'title' => 'Times Square', 'desc' => '+10 Altın Başlangıç Bonusu!', 'icon' => 'flag', 'color' => '#10B981'],
            ['id' => 1, 'type' => 'coin', 'amount' => 4, 'title' => 'Broadway Işıkları', 'desc' => '+4 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 2, 'type' => 'mystery', 'title' => 'Sarı Taksi Şansı', 'desc' => 'Sürpriz yolculuk!', 'icon' => 'sparkles', 'color' => '#F59E0B'],
            ['id' => 3, 'type' => 'coin', 'amount' => 5, 'title' => '5th Avenue Alışverişi', 'desc' => '+5 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 4, 'type' => 'trap', 'penalty' => 4, 'title' => 'Buhar Rogarı', 'desc' => '-4 Altın kaybettin!', 'icon' => 'flame', 'color' => '#EF4444'],
            ['id' => 5, 'type' => 'shop', 'title' => 'Manhattan Market', 'desc' => 'Güçlü eşyalar satın al!', 'icon' => 'shopping-bag', 'color' => '#F59E0B'],
            ['id' => 6, 'type' => 'coin', 'amount' => 6, 'title' => 'Wall Street Borsası', 'desc' => '+6 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 7, 'type' => 'star', 'title' => 'Empire State', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24'],
            ['id' => 8, 'type' => 'warp', 'target' => 20, 'title' => 'Subway Ekspres', 'desc' => '20. karoya fırla!', 'icon' => 'zap', 'color' => '#06B6D4'],
            ['id' => 9, 'type' => 'coin', 'amount' => 4, 'title' => 'SoHo Sanat', 'desc' => '+4 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 10, 'type' => 'jail', 'title' => 'Rikers Kodesi', 'desc' => '1 tur kilitli kal veya 5 altın kefalet öde!', 'icon' => 'shield', 'color' => '#DC2626'],
            ['id' => 11, 'type' => 'tax', 'title' => 'Wall Street Vergisi', 'desc' => '%25 Altın cezası en fakir oyuncuya dağıtılır!', 'icon' => 'coins', 'color' => '#E11D48'],
            ['id' => 12, 'type' => 'mystery', 'title' => 'Gizemli Çatı Katı', 'desc' => 'Rulet çarkını çevir!', 'icon' => 'sparkles', 'color' => '#F59E0B'],
            ['id' => 13, 'type' => 'bank', 'title' => 'Federal Reserve Bankası', 'desc' => 'Kasadaki tüm altınları topla!', 'icon' => 'coins', 'color' => '#10B981'],
            ['id' => 14, 'type' => 'shop', 'title' => 'Brooklyn Deposu', 'desc' => 'Taktik eşyaları!', 'icon' => 'shopping-bag', 'color' => '#F59E0B'],
            ['id' => 15, 'type' => 'star', 'title' => 'Özgürlük Heykeli', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24'],
            ['id' => 16, 'type' => 'coin', 'amount' => 4, 'title' => 'Central Park', 'desc' => '+4 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 17, 'type' => 'slip', 'steps' => -3, 'title' => 'Muzlu Donut Zemini', 'desc' => '3 adım geri kaydın!', 'icon' => 'undo-2', 'color' => '#EAB308'],
            ['id' => 18, 'type' => 'mystery', 'title' => 'Grand Central Saati', 'desc' => 'Büyük ödüller!', 'icon' => 'sparkles', 'color' => '#F59E0B'],
            ['id' => 19, 'type' => 'coin', 'amount' => 5, 'title' => 'DUMBO Manzarası', 'desc' => '+5 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 20, 'type' => 'duel', 'title' => 'Boks Ringi', 'desc' => 'Rakipten altın kap!', 'icon' => 'swords', 'color' => '#EC4899'],
            ['id' => 21, 'type' => 'freeze', 'title' => 'Blizzard Kar Fırtınası', 'desc' => '1 tur eşya kullanımın engellendi!', 'icon' => 'zap', 'color' => '#0284C7'],
            ['id' => 22, 'type' => 'coin', 'amount' => 6, 'title' => 'Chrysler Binası', 'desc' => '+6 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 23, 'type' => 'star', 'title' => 'Brooklyn Köprüsü', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24'],
            ['id' => 24, 'type' => 'reverse', 'title' => 'Trafik Tıkanıklığı', 'desc' => 'Ters yöne gitmek zorundasın!', 'icon' => 'undo-2', 'color' => '#9333EA'],
            ['id' => 25, 'type' => 'mystery', 'title' => 'Broadway Sandığı', 'desc' => 'Şansını sına!', 'icon' => 'sparkles', 'color' => '#F59E0B'],
            ['id' => 26, 'type' => 'shop', 'title' => 'Manhattan Market', 'desc' => 'Eşya kuşan!', 'icon' => 'shopping-bag', 'color' => '#F59E0B'],
            ['id' => 27, 'type' => 'coin', 'amount' => 8, 'title' => 'Federal Reserve Altını', 'desc' => '+8 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 28, 'type' => 'trap', 'penalty' => 5, 'title' => 'Park Cezası', 'desc' => '-5 Altın!', 'icon' => 'flame', 'color' => '#EF4444'],
            ['id' => 29, 'type' => 'duel', 'title' => 'Wall Street Düellosu', 'desc' => 'Liderden altın arakla!', 'icon' => 'swords', 'color' => '#EC4899'],
            ['id' => 30, 'type' => 'coin', 'amount' => 5, 'title' => 'Greenwich Village', 'desc' => '+5 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
            ['id' => 31, 'type' => 'star', 'title' => 'One World Observatory', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24']
        ];
    }

    // Default: 'istanbul'
    return [
        ['id' => 0, 'type' => 'start', 'title' => 'Eminönü İskelesi', 'desc' => '+10 Altın Başlangıç Bonusu!', 'icon' => 'flag', 'color' => '#10B981'],
        ['id' => 1, 'type' => 'coin', 'amount' => 4, 'title' => 'Mısır Çarşısı', 'desc' => '+4 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
        ['id' => 2, 'type' => 'mystery', 'title' => 'Kapalıçarşı Sandığı', 'desc' => 'Tarihi bir hazine sürprizi!', 'icon' => 'sparkles', 'color' => '#8B5CF6'],
        ['id' => 3, 'type' => 'coin', 'amount' => 5, 'title' => 'Sultanahmet Meydanı', 'desc' => '+5 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
        ['id' => 4, 'type' => 'trap', 'penalty' => 4, 'title' => 'Tarihi Arnavutkaldırımı', 'desc' => '-4 Altın düşürdün!', 'icon' => 'flame', 'color' => '#EF4444'],
        ['id' => 5, 'type' => 'shop', 'title' => 'Kapalıçarşı Bedesteni', 'desc' => 'Güçlü eşyalar satın al!', 'icon' => 'shopping-bag', 'color' => '#F59E0B'],
        ['id' => 6, 'type' => 'coin', 'amount' => 6, 'title' => 'Karaköy Rıhtımı', 'desc' => '+6 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
        ['id' => 7, 'type' => 'star', 'title' => 'Galata Kulesi', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24'],
        ['id' => 8, 'type' => 'warp', 'target' => 16, 'title' => 'Şehir Hatları Vapuru', 'desc' => '16. karoya yüz!', 'icon' => 'zap', 'color' => '#06B6D4'],
        ['id' => 9, 'type' => 'coin', 'amount' => 4, 'title' => 'İstiklal Caddesi', 'desc' => '+4 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
        ['id' => 10, 'type' => 'duel', 'title' => 'Kırkpınar Er Meydanı', 'desc' => 'Rakipten altın kap!', 'icon' => 'swords', 'color' => '#EC4899'],
        ['id' => 11, 'type' => 'tax', 'title' => 'Boğaz Köprüsü Gişesi', 'desc' => '%25 Altın cezası en fakir oyuncuya dağıtılır!', 'icon' => 'coins', 'color' => '#E11D48'],
        ['id' => 12, 'type' => 'mystery', 'title' => 'Yerebatan Sarnıcı', 'desc' => 'Rulet çarkını çevir!', 'icon' => 'sparkles', 'color' => '#8B5CF6'],
        ['id' => 13, 'type' => 'bank', 'title' => 'Topkapı Hazine Kasası', 'desc' => 'Kasadaki tüm altınları tek seferde kap!', 'icon' => 'coins', 'color' => '#10B981'],
        ['id' => 14, 'type' => 'shop', 'title' => 'Tahtakale Pazarı', 'desc' => 'Nadir taktik eşyaları!', 'icon' => 'shopping-bag', 'color' => '#F59E0B'],
        ['id' => 15, 'type' => 'star', 'title' => 'Kız Kulesi Kaidesi', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24'],
        ['id' => 16, 'type' => 'coin', 'amount' => 4, 'title' => 'Üsküdar Sahili', 'desc' => '+4 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
        ['id' => 17, 'type' => 'jail', 'title' => 'Yedikule Zindanları', 'desc' => '1 tur kilitli kal veya 5 altın kefalet öde!', 'icon' => 'shield', 'color' => '#DC2626'],
        ['id' => 18, 'type' => 'mystery', 'title' => 'Çamlıca Tepesi', 'desc' => 'Büyük ödüller veya sürprizler!', 'icon' => 'sparkles', 'color' => '#8B5CF6'],
        ['id' => 19, 'type' => 'coin', 'amount' => 5, 'title' => 'Kadıköy Boğa Meydanı', 'desc' => '+5 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
        ['id' => 20, 'type' => 'duel', 'title' => 'Boğaziçi Arenası', 'desc' => 'Rakiplerle düello!', 'icon' => 'swords', 'color' => '#EC4899'],
        ['id' => 21, 'type' => 'freeze', 'title' => 'Karadeniz Kar Fırtınası', 'desc' => 'Buz fırtınası! 1 tur eşya kullanamazsın!', 'icon' => 'zap', 'color' => '#0284C7'],
        ['id' => 22, 'type' => 'coin', 'amount' => 6, 'title' => 'Dolmabahçe Sarayı', 'desc' => '+6 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
        ['id' => 23, 'type' => 'star', 'title' => 'Ortaköy Camii Kaidesi', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24'],
        ['id' => 24, 'type' => 'reverse', 'title' => 'Boğaz Ters Akıntısı', 'desc' => 'Pusula bozuldu! Sonraki zarda geriye yürüyeceksin!', 'icon' => 'undo-2', 'color' => '#9333EA'],
        ['id' => 25, 'type' => 'mystery', 'title' => 'Balat Renkli Sandık', 'desc' => 'Şansını sına!', 'icon' => 'sparkles', 'color' => '#8B5CF6'],
        ['id' => 26, 'type' => 'shop', 'title' => 'Beşiktaş Çarşısı', 'desc' => 'Zafer için eşya kuşan!', 'icon' => 'shopping-bag', 'color' => '#F59E0B'],
        ['id' => 27, 'type' => 'coin', 'amount' => 8, 'title' => 'Boğaziçi Yalıları', 'desc' => '+8 Altın!', 'icon' => 'coins', 'color' => '#3B82F6'],
        ['id' => 28, 'type' => 'trap', 'penalty' => 4, 'title' => 'Trafik Yoğunluğu', 'desc' => '-4 Altın kaybettin!', 'icon' => 'flame', 'color' => '#EF4444'],
        ['id' => 29, 'type' => 'duel', 'title' => 'Haliç Hesaplaşması', 'desc' => 'Liderden altın arakla!', 'icon' => 'swords', 'color' => '#EC4899'],
        ['id' => 30, 'type' => 'coin', 'amount' => 5, 'title' => 'Taksim Meydanı', 'desc' => '+5 Altın kazandın!', 'icon' => 'coins', 'color' => '#3B82F6'],
        ['id' => 31, 'type' => 'star', 'title' => 'Ayasofya Kaidesi', 'desc' => '20 Altına 1 Altın Yıldız!', 'icon' => 'star', 'color' => '#FBBF24']
    ];
}

$BOT_TEMPLATES = [
    ['name' => 'Lego Usta', 'avatar' => 'builder', 'title' => 'Mimar', 'color' => '#3B82F6'],
    ['name' => 'Yeşil Dino', 'avatar' => 'dino', 'title' => 'Parti Canavarı', 'color' => '#10B981'],
    ['name' => 'Siber Kedi', 'avatar' => 'cat', 'title' => 'Hızlı Patiler', 'color' => '#EC4899'],
    ['name' => 'Gandi Bot', 'avatar' => 'wizard', 'title' => 'Büyücü', 'color' => '#8B5CF6'],
    ['name' => 'Robo-X', 'avatar' => 'robot', 'title' => 'Hesap Uzmanı', 'color' => '#06B6D4'],
    ['name' => 'Dedektif', 'avatar' => 'detective', 'title' => 'Gizem Avcısı', 'color' => '#F59E0B']
];

$SHOP_ITEMS = [
    ['id' => 'double_dice', 'name' => 'Çift Zar', 'cost' => 7, 'desc' => 'Bir sonraki turda 2 zar birden atarsın (2-12 adım).', 'icon' => 'dices'],
    ['id' => 'rocket', 'name' => 'Süper Roket', 'cost' => 12, 'desc' => 'Hedefine doğru direkt 7 adım uçar!', 'icon' => 'rocket'],
    ['id' => 'shield', 'name' => 'Manyetik Kalkan', 'cost' => 8, 'desc' => 'Tuzaklara ve altın çalma hamlelerine karşı 2 tur korur.', 'icon' => 'shield'],
    ['id' => 'magnet', 'name' => 'Altın Mıknatısı', 'cost' => 10, 'desc' => "Bütün rakiplerden 4'er altın çeker!", 'icon' => 'magnet'],
    ['id' => 'banana', 'name' => 'Muz Kabuğu', 'cost' => 5, 'desc' => 'Bulunduğun karoya tuzak kur; üstüne basan 3 adım geri kayar!', 'icon' => 'banana'],
    ['id' => 'swap_wand', 'name' => 'Takas Asası', 'cost' => 15, 'desc' => 'İstediğin bir rakiple haritadaki yerlerini takas et!', 'icon' => 'refresh-cw'],
    ['id' => 'ghost_cloak', 'name' => 'Hayalet Pelerin', 'cost' => 9, 'desc' => '2 tur boyunca hiçbir tuzaktan veya cezadan etkilenmezsin!', 'icon' => 'shield'],
    ['id' => 'lucky_die', 'name' => 'Şanslı Altın Zar', 'cost' => 14, 'desc' => 'Sıradaki zarda 1-6 arasında istediğin sayıyı sen seçersin!', 'icon' => 'dices']
];

// File Locking Room Manager
function getRoomFilePath($roomId) {
    global $roomsDir;
    $cleanId = preg_replace('/[^A-Za-z0-9_-]/', '', strtoupper($roomId));
    if (empty($cleanId)) return null;
    return $roomsDir . DIRECTORY_SEPARATOR . $cleanId . '.json';
}

function loadRoom($roomId, &$fp = null, $lockType = LOCK_SH) {
    $path = getRoomFilePath($roomId);
    if (!$path || !file_exists($path)) return null;

    $fp = fopen($path, 'c+');
    if (!$fp) return null;

    if (!flock($fp, $lockType)) {
        fclose($fp);
        return null;
    }

    $size = filesize($path);
    $content = $size > 0 ? fread($fp, $size) : '';
    if (empty($content)) {
        return null;
    }

    $room = json_decode($content, true);
    return is_array($room) ? $room : null;
}

function saveRoomAndUnlock(&$room, &$fp) {
    if (!$fp) return false;
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($room, JSON_UNESCAPED_UNICODE));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    $fp = null;
    return true;
}

function addRoomLog(&$room, $text) {
    if (!isset($room['log']) || !is_array($room['log'])) $room['log'] = [];
    $room['log'][] = [
        'id' => substr(md5(microtime(true) . mt_rand()), 0, 6),
        'time' => date('H:i:s'),
        'text' => $text
    ];
    if (count($room['log']) > 30) {
        array_shift($room['log']);
    }
}

// -----------------------------------------------------------------------------
// ROUTER & ACTIONS
// -----------------------------------------------------------------------------

$action = isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : '');
$data = getRequestData();
if (empty($action) && isset($data['action'])) {
    $action = $data['action'];
}

// Health Check
if ($action === 'health' || empty($action)) {
    sendJson([
        'status' => 'ok',
        'php' => true,
        'version' => PHP_VERSION,
        'storage' => $storageWritable,
        'time' => time(),
        'message' => 'PartyCraft: Wonder Board Online Engine Aktif!'
    ]);
}

// 1. Create Room
if ($action === 'create_room') {
    if (!$storageWritable) {
        sendError('Sunucu depolama klasörüne yazılamıyor. Lütfen "rooms" klasör izinlerini kontrol edin.');
    }

    // Generate unique 6-character room code
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $roomId = '';
    for ($i = 0; $i < 6; $i++) {
        $roomId .= $alphabet[mt_rand(0, strlen($alphabet) - 1)];
    }

    $theme = !empty($data['mapTheme']) ? $data['mapTheme'] : 'istanbul';
    $rounds = !empty($data['rounds']) ? max(5, min(30, intval($data['rounds']))) : 10;
    $password = !empty($data['password']) ? trim($data['password']) : null;

    $sessionId = !empty($data['sessionId']) ? $data['sessionId'] : ('s_' . substr(md5(uniqid()), 0, 10));
    $playerName = !empty($data['playerName']) ? mb_substr(trim($data['playerName']), 0, 16) : 'Oyuncu 1';
    $avatar = !empty($data['avatar']) ? $data['avatar'] : 'builder';
    $hat = !empty($data['hat']) ? $data['hat'] : 'none';
    $color = !empty($data['color']) ? $data['color'] : '#3B82F6';
    $diceSkin = !empty($data['diceSkin']) ? $data['diceSkin'] : 'default';
    $level = !empty($data['level']) ? intval($data['level']) : 1;
    $title = !empty($data['title']) ? $data['title'] : 'Acemi Gezgin';

    $hostPlayer = [
        'id' => 'p_' . substr(md5(uniqid()), 0, 6),
        'sessionId' => $sessionId,
        'name' => $playerName,
        'avatar' => $avatar,
        'hat' => $hat,
        'diceSkin' => $diceSkin,
        'level' => $level,
        'title' => $title,
        'color' => $color,
        'position' => 0,
        'coins' => 15,
        'stars' => 0,
        'inventory' => [],
        'shieldActive' => 0,
        'jailedTurns' => 0,
        'frozenTurns' => 0,
        'reverseNext' => false,
        'doubleDiceActive' => false,
        'isBot' => false,
        'disconnected' => false,
        'lastSeen' => time()
    ];

    $board = generateBoardForTheme($theme);

    $room = [
        'id' => $roomId,
        'createdAt' => time(),
        'updatedAt' => time(),
        'hostSessionId' => $sessionId,
        'password' => $password,
        'state' => 'lobby',
        'mapTheme' => $theme,
        'totalRounds' => $rounds,
        'currentRound' => 1,
        'turnIndex' => 0,
        'activeStarTile' => [7, 15, 23, 31][mt_rand(0, 3)],
        'trapsOnBoard' => [],
        'board' => $board,
        'players' => [$hostPlayer],
        'log' => [],
        'lastAction' => null
    ];

    addRoomLog($room, "🏰 {$playerName} odayı kurdu! Kod: {$roomId}");

    $path = getRoomFilePath($roomId);
    $fp = fopen($path, 'w');
    if ($fp && flock($fp, LOCK_EX)) {
        fwrite($fp, json_encode($room, JSON_UNESCAPED_UNICODE));
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);
    } else {
        sendError('Oda dosyası oluşturulamadı.');
    }

    sendJson([
        'type' => 'room_created',
        'roomId' => $roomId,
        'sessionId' => $sessionId,
        'player' => $hostPlayer,
        'state' => $room
    ]);
}

// 2. Join Room
if ($action === 'join_room') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);

    if (!$room) {
        sendError("\"{$roomId}\" kodlu oda bulunamadı veya süresi doldu!");
    }

    if (!empty($room['password'])) {
        $givenPass = isset($data['password']) ? trim($data['password']) : '';
        if ($givenPass !== $room['password']) {
            flock($fp, LOCK_UN);
            fclose($fp);
            sendError('Oda şifresi hatalı!');
        }
    }

    $sessionId = !empty($data['sessionId']) ? $data['sessionId'] : ('s_' . substr(md5(uniqid()), 0, 10));
    $existingIndex = -1;
    foreach ($room['players'] as $idx => $p) {
        if ($p['sessionId'] === $sessionId) {
            $existingIndex = $idx;
            break;
        }
    }

    if ($existingIndex !== -1) {
        // Reconnecting existing player!
        $room['players'][$existingIndex]['disconnected'] = false;
        $room['players'][$existingIndex]['lastSeen'] = time();
        if (!empty($data['playerName'])) $room['players'][$existingIndex]['name'] = mb_substr(trim($data['playerName']), 0, 16);
        if (!empty($data['avatar'])) $room['players'][$existingIndex]['avatar'] = $data['avatar'];
        if (!empty($data['hat'])) $room['players'][$existingIndex]['hat'] = $data['hat'];
        if (!empty($data['color'])) $room['players'][$existingIndex]['color'] = $data['color'];

        addRoomLog($room, "🔄 {$room['players'][$existingIndex]['name']} odaya tekrar bağlandı!");
        $player = $room['players'][$existingIndex];
    } else {
        // New Player Joining
        if ($room['state'] !== 'lobby') {
            flock($fp, LOCK_UN);
            fclose($fp);
            sendError('Bu oda şu anda oynanıyor, yeni oyuncu katılamaz!');
        }

        if (count($room['players']) >= 4) {
            flock($fp, LOCK_UN);
            fclose($fp);
            sendError('Oda dolu! (Maksimum 4 oyuncu)');
        }

        $colors = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#06B6D4'];
        $playerColor = !empty($data['color']) ? $data['color'] : $colors[count($room['players']) % count($colors)];

        $player = [
            'id' => 'p_' . substr(md5(uniqid()), 0, 6),
            'sessionId' => $sessionId,
            'name' => !empty($data['playerName']) ? mb_substr(trim($data['playerName']), 0, 16) : ('Oyuncu ' . (count($room['players']) + 1)),
            'avatar' => !empty($data['avatar']) ? $data['avatar'] : 'builder',
            'hat' => !empty($data['hat']) ? $data['hat'] : 'none',
            'diceSkin' => !empty($data['diceSkin']) ? $data['diceSkin'] : 'default',
            'level' => !empty($data['level']) ? intval($data['level']) : 1,
            'title' => !empty($data['title']) ? $data['title'] : 'Acemi Gezgin',
            'color' => $playerColor,
            'position' => 0,
            'coins' => 15,
            'stars' => 0,
            'inventory' => [],
            'shieldActive' => 0,
            'jailedTurns' => 0,
            'frozenTurns' => 0,
            'reverseNext' => false,
            'doubleDiceActive' => false,
            'isBot' => false,
            'disconnected' => false,
            'lastSeen' => time()
        ];

        $room['players'][] = $player;
        addRoomLog($room, "👋 {$player['name']} partiye katıldı!");
    }

    $room['updatedAt'] = time();
    saveRoomAndUnlock($room, $fp);

    sendJson([
        'type' => 'room_joined',
        'roomId' => $roomId,
        'sessionId' => $sessionId,
        'player' => $player,
        'state' => $room
    ]);
}

// 3. Get State (Periodic Polling & Heartbeat)
if ($action === 'get_state') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $sessionId = !empty($data['sessionId']) ? $data['sessionId'] : '';

    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);
    if (!$room) {
        sendError('Oda bulunamadı', 404);
    }

    $now = time();
    $stateChanged = false;

    // Heartbeat update for caller
    foreach ($room['players'] as &$p) {
        if ($p['sessionId'] === $sessionId) {
            $p['lastSeen'] = $now;
            if ($p['disconnected']) {
                $p['disconnected'] = false;
                $stateChanged = true;
            }
        } else if (!$p['isBot']) {
            // Check disconnect for others if absent for 20s
            if (($now - (isset($p['lastSeen']) ? $p['lastSeen'] : $now)) > 20) {
                if (!$p['disconnected']) {
                    $p['disconnected'] = true;
                    $stateChanged = true;
                }
            }
        }
    }

    // Auto-advance bot turn or disconnected player turn after 3 seconds of inactivity
    if ($room['state'] === 'playing' && !empty($room['players'])) {
        $activePlayer = &$room['players'][$room['turnIndex'] % count($room['players'])];
        $isBot = !empty($activePlayer['isBot']);
        $isAfk = !empty($activePlayer['disconnected']);

        // Check if turn should be played by server bot
        if ($isBot || $isAfk) {
            $turnStart = isset($room['turnStartedAt']) ? $room['turnStartedAt'] : 0;
            if ($now - $turnStart >= 2) {
                // Execute server-side turn for bot/disconnected player
                $room['turnStartedAt'] = $now;
                
                // Roll die
                $die = mt_rand(1, 6);
                $oldPos = $activePlayer['position'];
                $newPos = ($oldPos + $die) % count($room['board']);
                $activePlayer['position'] = $newPos;

                addRoomLog($room, "🤖 {$activePlayer['name']} zar attı: [{$die}] ve {$newPos}. karoya ilerledi.");

                // Process tile
                $tile = $room['board'][$newPos];
                if ($tile['type'] === 'coin') {
                    $amt = isset($tile['amount']) ? $tile['amount'] : 4;
                    $activePlayer['coins'] += $amt;
                } else if ($tile['type'] === 'star' && $activePlayer['coins'] >= 20) {
                    $activePlayer['coins'] -= 20;
                    $activePlayer['stars'] += 1;
                    addRoomLog($room, "⭐ {$activePlayer['name']} 20 altına bir Yıldız satın aldı!");
                    $room['activeStarTile'] = [7, 15, 23, 31][mt_rand(0, 3)];
                } else if ($tile['type'] === 'trap') {
                    $pen = isset($tile['penalty']) ? $tile['penalty'] : 4;
                    $activePlayer['coins'] = max(0, $activePlayer['coins'] - $pen);
                }

                // Advance turn
                $room['turnIndex']++;
                if ($room['turnIndex'] >= count($room['players'])) {
                    $room['turnIndex'] = 0;
                    $room['currentRound']++;
                    if ($room['currentRound'] > $room['totalRounds']) {
                        $room['state'] = 'gameover';
                        addRoomLog($room, "🏆 PARTİ TAMAMLANDI!");
                    } else {
                        $minigamePool = [
                            ['id' => 'coin_catch', 'title' => 'Gökten Altın Yağmuru', 'desc' => 'Düşen altınları sepete topla, bombalardan kaç!', 'duration' => 15],
                            ['id' => 'reflex_pop', 'title' => 'Hızlı Parmak / Refleks', 'desc' => 'Yeşil sinyal geldiğinde ilk tıklayan kazanır!', 'duration' => 10],
                            ['id' => 'balloon_mash', 'title' => 'Lego Balon Şişirme', 'desc' => 'En hızlı tıkla, balonunu ilk patlatan sen ol!', 'duration' => 12],
                            ['id' => 'lucky_chests', 'title' => 'Hazine Sandığı Kumarı', 'desc' => '3 gizemli sandıktan birini seç! Ya büyük ödül ya da tuzak!', 'duration' => 11],
                            ['id' => 'memory_matrix', 'title' => 'Parti Hafızası & Hızlı Renkler', 'desc' => 'Yanan renk dizisini hafızanda tut ve hatasız tekrarla!', 'duration' => 14],
                            ['id' => 'timing_hammer', 'title' => 'Güç Çekici & Hassas Zamanlama', 'desc' => 'Tam ortadaki 100 puanlık altın zili tuttur!', 'duration' => 12]
                        ];
                        $chosen = $minigamePool[array_rand($minigamePool)];
                        $room['minigame'] = $chosen;
                        addRoomLog($room, "🎮 " . ($room['currentRound'] - 1) . ". Tur bitti! Mini-Oyun: {$chosen['title']}");
                    }
                }
                $stateChanged = true;
            }
        }
    }

    if ($stateChanged) {
        $room['updatedAt'] = $now;
    }

    saveRoomAndUnlock($room, $fp);

    sendJson([
        'type' => 'state_update',
        'roomId' => $roomId,
        'state' => $room['state'],
        'mapTheme' => $room['mapTheme'],
        'totalRounds' => $room['totalRounds'],
        'currentRound' => $room['currentRound'],
        'turnIndex' => $room['turnIndex'],
        'activeStarTile' => $room['activeStarTile'],
        'trapsOnBoard' => $room['trapsOnBoard'],
        'board' => $room['board'],
        'players' => $room['players'],
        'log' => $room['log'],
        'lastAction' => $room['lastAction'],
        'minigame' => isset($room['minigame']) ? $room['minigame'] : null
    ]);
}

// 4. Start Game
if ($action === 'start_game') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $sessionId = !empty($data['sessionId']) ? $data['sessionId'] : '';

    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);
    if (!$room) sendError('Oda bulunamadı');

    // Auto-fill with bots up to 4 players so the game is always fun and full
    while (count($room['players']) < 4) {
        $template = $BOT_TEMPLATES[count($room['players']) % count($BOT_TEMPLATES)];
        $botHats = ['crown', 'wizard', 'pirate', 'cat_ears', 'party_hat', 'visor', 'detective', 'viking'];
        $room['players'][] = [
            'id' => 'bot_' . substr(md5(uniqid()), 0, 6),
            'sessionId' => 'bot_sess_' . substr(md5(uniqid()), 0, 8),
            'name' => '[BOT] ' . $template['name'],
            'avatar' => $template['avatar'],
            'hat' => $botHats[mt_rand(0, count($botHats) - 1)],
            'diceSkin' => 'neon',
            'level' => mt_rand(2, 8),
            'title' => $template['title'],
            'color' => $template['color'],
            'position' => 0,
            'coins' => 15,
            'stars' => 0,
            'inventory' => ['double_dice'],
            'shieldActive' => 0,
            'jailedTurns' => 0,
            'frozenTurns' => 0,
            'reverseNext' => false,
            'doubleDiceActive' => false,
            'isBot' => true,
            'disconnected' => false,
            'lastSeen' => time()
        ];
    }

    $room['state'] = 'playing';
    $room['currentRound'] = 1;
    $room['turnIndex'] = 0;
    $room['turnStartedAt'] = time();
    $room['activeStarTile'] = [7, 15, 23, 31][mt_rand(0, 3)];

    addRoomLog($room, "🚀 Parti başladı! Toplam {$room['totalRounds']} tur oynanacak. Yıldız kaidesi {$room['activeStarTile']}. karoda!");

    $room['updatedAt'] = time();
    saveRoomAndUnlock($room, $fp);

    sendJson([
        'type' => 'state_update',
        'roomId' => $roomId,
        'state' => 'playing',
        'room' => $room
    ]);
}

// 5. Add Bot
if ($action === 'add_bot') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);
    if (!$room) sendError('Oda bulunamadı');

    if (count($room['players']) < 4) {
        $template = $BOT_TEMPLATES[count($room['players']) % count($BOT_TEMPLATES)];
        $botHats = ['crown', 'wizard', 'pirate', 'cat_ears', 'party_hat', 'visor', 'detective', 'viking'];
        $bot = [
            'id' => 'bot_' . substr(md5(uniqid()), 0, 6),
            'sessionId' => 'bot_sess_' . substr(md5(uniqid()), 0, 8),
            'name' => '[BOT] ' . $template['name'],
            'avatar' => $template['avatar'],
            'hat' => $botHats[mt_rand(0, count($botHats) - 1)],
            'diceSkin' => 'neon',
            'level' => mt_rand(2, 8),
            'title' => $template['title'],
            'color' => $template['color'],
            'position' => 0,
            'coins' => 15,
            'stars' => 0,
            'inventory' => ['double_dice'],
            'shieldActive' => 0,
            'jailedTurns' => 0,
            'frozenTurns' => 0,
            'reverseNext' => false,
            'doubleDiceActive' => false,
            'isBot' => true,
            'disconnected' => false,
            'lastSeen' => time()
        ];
        $room['players'][] = $bot;
        addRoomLog($room, "🤖 {$bot['name']} odaya eklendi!");
        $room['updatedAt'] = time();
    }

    saveRoomAndUnlock($room, $fp);
    sendJson(['type' => 'state_update', 'players' => $room['players']]);
}

// 6. Switch Map
if ($action === 'switch_map') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $mapTheme = !empty($data['mapTheme']) ? $data['mapTheme'] : 'istanbul';

    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);
    if (!$room) sendError('Oda bulunamadı');

    $room['mapTheme'] = $mapTheme;
    $room['board'] = generateBoardForTheme($mapTheme);
    addRoomLog($room, "🗺️ Harita seçildi: " . strtoupper($mapTheme));

    $room['updatedAt'] = time();
    saveRoomAndUnlock($room, $fp);
    sendJson(['type' => 'state_update', 'mapTheme' => $mapTheme]);
}

// 7. Roll Dice
if ($action === 'roll_dice') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $sessionId = !empty($data['sessionId']) ? $data['sessionId'] : '';

    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);
    if (!$room) sendError('Oda bulunamadı');

    $player = &$room['players'][$room['turnIndex'] % count($room['players'])];
    if ($player['sessionId'] !== $sessionId) {
        flock($fp, LOCK_UN);
        fclose($fp);
        sendError('Sıra sende değil!');
    }

    // Check jail
    if ($player['jailedTurns'] > 0) {
        if ($player['coins'] >= 5) {
            $player['coins'] -= 5;
            $player['jailedTurns'] = 0;
            addRoomLog($room, "🔑 {$player['name']} 5 altın kefalet ödeyerek serbest kaldı!");
        } else {
            $player['jailedTurns']--;
            addRoomLog($room, "⛓️ {$player['name']} Kodes cezasında, turu pas geçti!");
            $room['turnIndex']++;
            saveRoomAndUnlock($room, $fp);
            sendJson(['type' => 'turn_skipped']);
        }
    }

    $die1 = !empty($player['fixedRollNext']) ? intval($player['fixedRollNext']) : mt_rand(1, 6);
    $wasFixed = !empty($player['fixedRollNext']);
    unset($player['fixedRollNext']);
    $die2 = null;
    $totalRoll = $die1;

    if (!empty($player['doubleDiceActive'])) {
        $die2 = mt_rand(1, 6);
        $totalRoll = $die1 + $die2;
        $player['doubleDiceActive'] = false;
        addRoomLog($room, "🎲🎲 {$player['name']} ÇİFT ZAR attı: [{$die1}] + [{$die2}] = {$totalRoll} adım!");
    } else {
        if ($wasFixed) {
            addRoomLog($room, "🎯 {$player['name']} Şanslı Altın Zarını attı: [{$die1}]!");
        } else {
            addRoomLog($room, "🎲 {$player['name']} zar attı: [{$die1}]!");
        }
    }

    $isReverse = !empty($player['reverseNext']);
    $player['reverseNext'] = false;
    $effectiveSteps = $isReverse ? -$totalRoll : $totalRoll;

    $oldPos = $player['position'];
    $boardLen = count($room['board']);
    $newPos = ($oldPos + $effectiveSteps + $boardLen) % $boardLen;
    $player['position'] = $newPos;

    // Passing start
    if (!$isReverse && ($oldPos + $totalRoll >= $boardLen)) {
        $player['coins'] += 10;
        addRoomLog($room, "💰 {$player['name']} Başlangıçtan geçti ve +10 Altın kazandı!");
    }

    // Landed tile action
    $tile = $room['board'][$newPos];
    $tileEvent = null;

    if ($tile['type'] === 'coin') {
        $amt = isset($tile['amount']) ? $tile['amount'] : 4;
        $player['coins'] += $amt;
        addRoomLog($room, "🪙 {$player['name']}, {$tile['title']} karosundan +{$amt} Altın topladı!");
    } else if ($tile['type'] === 'star') {
        if ($player['coins'] >= 20) {
            $player['coins'] -= 20;
            $player['stars'] += 1;
            addRoomLog($room, "⭐ TEBRİKLER! {$player['name']} 20 Altına 1 YILDIZ satın aldı!");
            $room['activeStarTile'] = [7, 15, 23, 31][mt_rand(0, 3)];
        } else {
            addRoomLog($room, "⭐ {$player['name']} Yıldız kaidesine geldi ama 20 altını yoktu!");
        }
    } else if ($tile['type'] === 'trap') {
        $pen = isset($tile['penalty']) ? $tile['penalty'] : 4;
        $player['coins'] = max(0, $player['coins'] - $pen);
        addRoomLog($room, "🔥 TUZAK! {$player['name']} {$pen} altın kaybetti!");
    } else if ($tile['type'] === 'jail') {
        $player['jailedTurns'] = 1;
        addRoomLog($room, "🔒 {$player['name']} Kodese düştü!");
    } else if ($tile['type'] === 'freeze') {
        $player['frozenTurns'] = 1;
        addRoomLog($room, "🧊 {$player['name']} donduruldu!");
    } else if ($tile['type'] === 'reverse') {
        $player['reverseNext'] = true;
        addRoomLog($room, "🔄 {$player['name']} bir sonraki zarda geriye doğru yürüyecek!");
    }

    $room['lastAction'] = [
        'type' => 'dice_rolled',
        'playerId' => $player['id'],
        'playerName' => $player['name'],
        'die1' => $die1,
        'die2' => $die2,
        'totalRoll' => $totalRoll,
        'targetTile' => $newPos
    ];

    // Advance Turn
    $room['turnIndex']++;
    if ($room['turnIndex'] >= count($room['players'])) {
        $room['turnIndex'] = 0;
        $room['currentRound']++;
        if ($room['currentRound'] > $room['totalRounds']) {
            $room['state'] = 'gameover';
            addRoomLog($room, "🏆 PARTİ TAMAMLANDI! Tebrikler kazananlar!");
        } else {
            $minigamePool = [
                ['id' => 'coin_catch', 'title' => 'Gökten Altın Yağmuru', 'desc' => 'Düşen altınları sepete topla, bombalardan kaç!', 'duration' => 15],
                ['id' => 'reflex_pop', 'title' => 'Hızlı Parmak / Refleks', 'desc' => 'Yeşil sinyal geldiğinde ilk tıklayan kazanır!', 'duration' => 10],
                ['id' => 'balloon_mash', 'title' => 'Lego Balon Şişirme', 'desc' => 'En hızlı tıkla, balonunu ilk patlatan sen ol!', 'duration' => 12],
                ['id' => 'lucky_chests', 'title' => 'Hazine Sandığı Kumarı', 'desc' => '3 gizemli sandıktan birini seç! Ya büyük ödül ya da tuzak!', 'duration' => 11],
                ['id' => 'memory_matrix', 'title' => 'Parti Hafızası & Hızlı Renkler', 'desc' => 'Yanan renk dizisini hafızanda tut ve hatasız tekrarla!', 'duration' => 14],
                ['id' => 'timing_hammer', 'title' => 'Güç Çekici & Hassas Zamanlama', 'desc' => 'Tam ortadaki 100 puanlık altın zili tuttur!', 'duration' => 12]
            ];
            $chosen = $minigamePool[array_rand($minigamePool)];
            $room['minigame'] = $chosen;
            addRoomLog($room, "🎮 " . ($room['currentRound'] - 1) . ". Tur bitti! Mini-Oyun: {$chosen['title']}");
        }
    }
    $room['turnStartedAt'] = time();
    $room['updatedAt'] = time();

    saveRoomAndUnlock($room, $fp);

    sendJson([
        'type' => 'dice_rolled',
        'die1' => $die1,
        'die2' => $die2,
        'totalRoll' => $totalRoll,
        'newPosition' => $newPos,
        'state' => $room
    ]);
}

// 8. Buy Item
if ($action === 'buy_item') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $sessionId = !empty($data['sessionId']) ? $data['sessionId'] : '';
    $itemId = !empty($data['itemId']) ? $data['itemId'] : '';

    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);
    if (!$room) sendError('Oda bulunamadı');

    $item = null;
    foreach ($SHOP_ITEMS as $it) {
        if ($it['id'] === $itemId) { $item = $it; break; }
    }

    if ($item) {
        foreach ($room['players'] as &$p) {
            if ($p['sessionId'] === $sessionId && $p['coins'] >= $item['cost']) {
                $p['coins'] -= $item['cost'];
                $p['inventory'][] = $item['id'];
                addRoomLog($room, "🛍️ {$p['name']} {$item['name']} satın aldı!");
                break;
            }
        }
    }

    $room['updatedAt'] = time();
    saveRoomAndUnlock($room, $fp);
    sendJson(['type' => 'state_update', 'room' => $room]);
}

// 9. Send Emote & Quick Chat
if ($action === 'send_emote' || $action === 'send_quick_chat') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $sessionId = !empty($data['sessionId']) ? $data['sessionId'] : '';

    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);
    if (!$room) sendError('Oda bulunamadı');

    $player = null;
    foreach ($room['players'] as $p) {
        if ($p['sessionId'] === $sessionId) { $player = $p; break; }
    }

    if ($player) {
        if ($action === 'send_emote') {
            $emoteId = !empty($data['emoteId']) ? $data['emoteId'] : 'gg';
            $room['lastAction'] = ['type' => 'player_emote', 'playerId' => $player['id'], 'emoteId' => $emoteId];
        } else {
            $text = !empty($data['text']) ? mb_substr(strip_tags($data['text']), 0, 80) : '';
            $room['lastAction'] = ['type' => 'player_chat', 'playerId' => $player['id'], 'playerName' => $player['name'], 'text' => $text];
            addRoomLog($room, "💬 {$player['name']}: {$text}");
        }
        $room['updatedAt'] = time();
    }

    saveRoomAndUnlock($room, $fp);
    sendJson(['type' => 'success']);
}

// 10b. Leave Room (Any Player Anytime)
if ($action === 'leave_room') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $sessionId = !empty($data['sessionId']) ? $data['sessionId'] : '';

    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);
    if ($room) {
        $leftName = '';
        if ($room['state'] === 'lobby') {
            $newPlayers = [];
            foreach ($room['players'] as $p) {
                if ($p['sessionId'] === $sessionId || $p['id'] === $sessionId) {
                    $leftName = $p['name'];
                } else {
                    $newPlayers[] = $p;
                }
            }
            $room['players'] = $newPlayers;
            if (!empty($newPlayers) && $room['hostSessionId'] === $sessionId) {
                $room['hostSessionId'] = $newPlayers[0]['sessionId'];
            }
        } else {
            // In active game: convert to smart bot so match continues smoothly
            foreach ($room['players'] as &$p) {
                if ($p['sessionId'] === $sessionId || $p['id'] === $sessionId) {
                    $leftName = $p['name'];
                    $p['isBot'] = true;
                    $p['name'] .= ' (Bot)';
                }
            }
        }
        if ($leftName) {
            addRoomLog($room, '🚪 ' . $leftName . ' partiden ayrıldı.');
        }
        saveRoom($roomId, $room, $fp);
    }
    if ($fp) {
        flock($fp, LOCK_UN);
        fclose($fp);
    }
    sendJson(['type' => 'success', 'message' => 'left']);
}

// 10. Kick Player (Host Only)
if ($action === 'kick_player') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $sessionId = !empty($data['sessionId']) ? $data['sessionId'] : '';
    $targetId = !empty($data['targetPlayerId']) ? $data['targetPlayerId'] : '';

    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);
    if (!$room) sendError('Oda bulunamadı');

    if ($room['hostSessionId'] !== $sessionId) {
        flock($fp, LOCK_UN);
        fclose($fp);
        sendError('Yalnızca oda sahibi oyuncu çıkarabilir!');
    }

    $kickedName = '';
    $newPlayers = [];
    foreach ($room['players'] as $p) {
        if ($p['id'] === $targetId) {
            $kickedName = $p['name'];
        } else {
            $newPlayers[] = $p;
        }
    }

    if (!empty($kickedName)) {
        $room['players'] = $newPlayers;
        addRoomLog($room, "🚪 Oda sahibi, {$kickedName} adlı oyuncuyu odadan çıkardı.");
        $room['updatedAt'] = time();
    }

    saveRoomAndUnlock($room, $fp);
    sendJson(['type' => 'state_update', 'players' => $room['players']]);
}

// 11. Use Item
if ($action === 'use_item') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $sessionId = !empty($data['sessionId']) ? $data['sessionId'] : '';
    $itemId = !empty($data['itemId']) ? $data['itemId'] : '';
    $targetId = !empty($data['targetPlayerId']) ? $data['targetPlayerId'] : null;

    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);
    if (!$room) sendError('Oda bulunamadı');

    $player = null;
    foreach ($room['players'] as &$p) {
        if ($p['sessionId'] === $sessionId) { $player = &$p; break; }
    }

    if ($player && in_array($itemId, $player['inventory'])) {
        $idx = array_search($itemId, $player['inventory']);
        array_splice($player['inventory'], $idx, 1);

        if ($itemId === 'double_dice') {
            $player['doubleDiceActive'] = true;
            addRoomLog($room, "🎲🎲 {$player['name']} Çift Zar kullandı!");
        } else if ($itemId === 'rocket') {
            $player['position'] = ($player['position'] + 7) % count($room['board']);
            addRoomLog($room, "🚀 {$player['name']} Süper Roketle 7 adım ileri fırladı!");
        } else if ($itemId === 'shield') {
            $player['shieldActive'] = 2;
            addRoomLog($room, "🛡️ {$player['name']} Manyetik Kalkan kuşandı!");
        } else if ($itemId === 'magnet') {
            $stolenTotal = 0;
            foreach ($room['players'] as &$opp) {
                if ($opp['id'] !== $player['id'] && empty($opp['shieldActive'])) {
                    $amt = min(4, $opp['coins']);
                    $opp['coins'] -= $amt;
                    $stolenTotal += $amt;
                }
            }
            $player['coins'] += $stolenTotal;
            addRoomLog($room, "🧲 {$player['name']} Altın Mıknatısıyla rakiplerden {$stolenTotal} altın çekti!");
        } else if ($itemId === 'banana') {
            $room['trapsOnBoard'][] = ['tileIndex' => $player['position'], 'ownerId' => $player['id']];
            addRoomLog($room, "🍌 {$player['name']} {$player['position']}. karoya Muz Kabuğu tuzağı kurdu!");
        } else if ($itemId === 'swap_wand') {
            $targetOpp = null;
            foreach ($room['players'] as &$opp) {
                if ($targetId && $opp['id'] === $targetId) { $targetOpp = &$opp; break; }
                if (!$targetId && $opp['id'] !== $player['id']) { $targetOpp = &$opp; break; }
            }
            if ($targetOpp) {
                $tmp = $player['position'];
                $player['position'] = $targetOpp['position'];
                $targetOpp['position'] = $tmp;
                addRoomLog($room, "🪄 {$player['name']} Takas Asası ile {$targetOpp['name']} ile yer değiştirdi!");
            }
        } else if ($itemId === 'ghost_cloak') {
            $player['ghostCloakActive'] = 2;
            addRoomLog($room, "👻 {$player['name']} Hayalet Pelerin kuşandı! 2 tur cezalardan muaf!");
        } else if ($itemId === 'lucky_die') {
            $fixed = intval($targetId) ?: 6;
            $player['fixedRollNext'] = min(6, max(1, $fixed));
            addRoomLog($room, "🎯 {$player['name']} Şanslı Altın Zar ayarladı [{$player['fixedRollNext']}]!");
        }

        $room['updatedAt'] = time();
    }

    saveRoomAndUnlock($room, $fp);
    sendJson(['type' => 'state_update', 'room' => $room]);
}

// 12. Close Shop
if ($action === 'close_shop') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);
    if ($room) {
        $room['updatedAt'] = time();
        saveRoomAndUnlock($room, $fp);
    }
    sendJson(['type' => 'success']);
}

// 13. Minigame Score
if ($action === 'minigame_score') {
    $roomId = !empty($data['roomId']) ? trim($data['roomId']) : '';
    $sessionId = !empty($data['sessionId']) ? $data['sessionId'] : '';
    $score = isset($data['score']) ? intval($data['score']) : 0;

    $fp = null;
    $room = loadRoom($roomId, $fp, LOCK_EX);
    if ($room) {
        foreach ($room['players'] as &$p) {
            if ($p['sessionId'] === $sessionId) {
                $reward = min(15, max(3, intval($score / 2)));
                $p['coins'] += $reward;
                addRoomLog($room, "🎮 {$p['name']} mini oyundan {$score} puan aldı ve +{$reward} Altın kazandı!");
                break;
            }
        }
        $room['updatedAt'] = time();
        saveRoomAndUnlock($room, $fp);
    }
    sendJson(['type' => 'success']);
}

// Unknown Action Fallback
sendError('Geçersiz işlem isteği.');

    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>PartyCraft: Wonder Board | Lego Parti & Masa Oyunu</title>
  
  <!-- Modern Clean Typography -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800;900&display=swap" rel="stylesheet">
  
  <!-- Stylesheets -->
  <style>
/* =================== BOARD CSS =================== */
/* ==========================================================================
   PartyCraft: Wonder Board - Board & Special Effects Styling
   ========================================================================== */

/* ----------------------------------------------------
   3D TUMBLING DICE ROLLING OVERLAY
   ---------------------------------------------------- */
.dice-roll-modal {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
}

.dice-cubes-container {
  display: flex;
  gap: 24px;
  perspective: 600px;
}

.dice-cube {
  width: 72px;
  height: 72px;
  background: white;
  border-radius: 14px;
  border: 3px solid #CBD5E1;
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15), inset 0 2px 4px rgba(255, 255, 255, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 32px;
  font-weight: 900;
  color: #1E293B;
  transition: transform 0.2s ease;
}

.dice-cube.rolling {
  animation: diceTumble 0.9s cubic-bezier(0.25, 1, 0.5, 1);
}

.dice-cube.landed {
  transform: scale(1.1) rotate(0deg);
  border-color: #3B82F6;
  color: #1D4ED8;
  box-shadow: 0 8px 16px rgba(59, 130, 246, 0.3);
}

@keyframes diceTumble {
  0% { transform: translateY(-40px) rotateX(0deg) rotateY(0deg) scale(0.8); }
  25% { transform: translateY(15px) rotateX(180deg) rotateY(90deg) scale(1.15); }
  50% { transform: translateY(-15px) rotateX(360deg) rotateY(270deg) scale(0.95); }
  75% { transform: translateY(5px) rotateX(540deg) rotateY(450deg) scale(1.05); }
  100% { transform: translateY(0) rotateX(720deg) rotateY(720deg) scale(1); }
}

.dice-result-text {
  font-size: 20px;
  font-weight: 800;
  color: #1E293B;
  text-align: center;
}

/* Mystery Roulette styles consolidated in style.css */

/* ----------------------------------------------------
   MINI-GAMES STYLING
   ---------------------------------------------------- */
.minigame-card {
  background: white;
  border-radius: 20px;
  padding: 24px;
  width: 100%;
  max-width: 480px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.25);
  border: 3px solid #F1F5F9;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.minigame-header h2 {
  font-size: 20px;
  font-weight: 900;
  color: #1E293B;
}

.minigame-header p {
  font-size: 13px;
  color: #64748B;
  margin-top: 4px;
}

.minigame-stats {
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
}

.badge-time,
.badge-score {
  font-weight: 800;
  font-size: 14px;
  padding: 6px 14px;
  border-radius: 10px;
  background: #F1F5F9;
  color: #1E293B;
}

.badge-score {
  background: #FEF9C3;
  color: #854D0E;
}

/* Mini-Game 1: Coin Catch Arena */
.coin-catch-arena {
  width: 100%;
  height: 260px;
  background: linear-gradient(180deg, #E0F2FE 0%, #BAE6FD 100%);
  border-radius: 14px;
  position: relative;
  overflow: hidden;
  border: 2px solid #7DD3FC;
}

.catch-basket {
  position: absolute;
  bottom: 12px;
  font-size: 34px;
  user-select: none;
  pointer-events: none;
  transition: transform 0.1s ease;
}

.falling-item {
  position: absolute;
  font-size: 26px;
  user-select: none;
  pointer-events: none;
}

.touch-controls-row {
  display: flex;
  gap: 12px;
}

.touch-btn {
  flex: 1;
  padding: 14px;
  border: none;
  border-radius: 12px;
  background: #3B82F6;
  color: white;
  font-size: 14px;
  font-weight: 800;
  cursor: pointer;
  box-shadow: 0 4px 0 #1D4ED8;
}

.touch-btn:active {
  transform: translateY(3px);
  box-shadow: 0 1px 0 #1D4ED8;
}

/* Mini-Game 2: Reflex Duel Pad */
.reflex-pad {
  height: 200px;
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  cursor: pointer;
  transition: all 0.2s ease;
  user-select: none;
}

.reflex-pad.wait-state {
  background: #FEE2E2;
  border: 3px dashed #EF4444;
}

.reflex-pad.ready-state {
  background: #DCFCE7;
  border: 4px solid #10B981;
  animation: pulseReady 0.4s infinite alternate;
}

@keyframes pulseReady {
  from { transform: scale(0.98); }
  to { transform: scale(1.02); }
}

.reflex-pad.success-state {
  background: #FEF08A;
  border: 4px solid #EAB308;
}

.reflex-pad.error-state {
  background: #F87171;
  border: 4px solid #B91C1C;
  color: white;
}

.reflex-icon {
  font-size: 48px;
}

.reflex-msg {
  font-size: 22px;
  font-weight: 900;
}

.reflex-sub {
  font-size: 12px;
  color: #64748B;
}

/* Mini-Game 3: Balloon Mash Arena */
.balloon-arena {
  height: 180px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.lego-balloon {
  font-size: 54px;
  transition: transform 0.08s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.mash-btn {
  width: 100%;
  padding: 16px;
  font-size: 18px;
  font-weight: 900;
  color: white;
  background: linear-gradient(135deg, #EC4899, #DB2777);
  border: none;
  border-radius: 14px;
  box-shadow: 0 5px 0 #9D174D;
  cursor: pointer;
}

.mash-btn:active {
  transform: translateY(4px);
  box-shadow: 0 1px 0 #9D174D;
}


/* =================== STYLE CSS =================== */
/* ==========================================================================
   PartyCraft: Wonder Board - Modern UI/UX Design System
   Inspired by Lego Party, Mario Party & ui-ux-pro-max principles
   ========================================================================== */

:root {
  --font-main: 'Outfit', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
  --bg-gradient: linear-gradient(135deg, #EFF6FF 0%, #F5F3FF 50%, #FFF1F2 100%);
  --surface-card: #FFFFFF;
  --surface-card-trans: rgba(255, 255, 255, 0.92);
  --border-color: #E2E8F0;
  
  --lego-red: #EF4444;
  --lego-blue: #3B82F6;
  --lego-yellow: #FBBF24;
  --lego-green: #10B981;
  --lego-purple: #8B5CF6;
  --lego-pink: #EC4899;
  --text-dark: #0F172A;
  --text-muted: #64748B;
  
  --shadow-sm: 0 4px 6px -1px rgba(0, 0, 0, 0.07), 0 2px 4px -2px rgba(0, 0, 0, 0.05);
  --shadow-md: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.08);
  --shadow-clay: 0 8px 0px rgba(0, 0, 0, 0.12), 0 16px 24px rgba(0, 0, 0, 0.08);
  --radius-lg: 22px;
  --radius-md: 16px;
  --radius-sm: 10px;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
}

body {
  font-family: var(--font-main);
  background: var(--bg-gradient);
  color: var(--text-dark);
  min-height: 100vh;
  overflow-x: hidden;
  position: relative;
}

/* Screen visibility utility */
.screen {
  width: 100%;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  transition: opacity 0.3s ease;
}

.hidden {
  display: none !important;
}

/* ==========================================================================
   HOME SCREEN
   ========================================================================== */

.home-container {
  max-width: 960px;
  margin: 0 auto;
  padding: 24px 16px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 28px;
}

.home-hero {
  text-align: center;
  position: relative;
}

.hero-badge {
  display: inline-block;
  background: #FEF08A;
  color: #854D0E;
  font-weight: 800;
  font-size: 13px;
  padding: 6px 16px;
  border-radius: 20px;
  margin-bottom: 12px;
  box-shadow: 0 2px 8px rgba(234, 179, 8, 0.25);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.hero-title {
  font-size: clamp(34px, 7vw, 56px);
  font-weight: 900;
  color: #1E293B;
  line-height: 1.1;
  text-shadow: 0 3px 0 #CBD5E1;
}

.hero-title span {
  color: var(--lego-red);
}

.hero-subtitle {
  font-size: 17px;
  color: var(--text-muted);
  margin-top: 8px;
}

/* ==========================================================================
   INTERACTIVE CHARACTER STUDIO (Home Screen)
   ========================================================================== */

.char-studio-card {
  background: var(--surface-card);
  border-radius: var(--radius-lg);
  padding: 24px;
  box-shadow: 0 16px 36px -10px rgba(15, 23, 42, 0.12), 0 0 0 1px rgba(226, 232, 240, 0.8), inset 0 2px 4px rgba(255, 255, 255, 0.9);
  border: 3px solid #E2E8F0;
  width: 100%;
  max-width: 720px;
  box-sizing: border-box;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  gap: 18px;
  position: relative;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.studio-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  box-sizing: border-box;
  border-bottom: 2px dashed #E2E8F0;
  padding-bottom: 12px;
}

.studio-badge {
  font-size: 13px;
  font-weight: 900;
  letter-spacing: 0.5px;
  color: #4338CA;
  background: #EEF2FF;
  padding: 5px 14px;
  border-radius: 12px;
  box-shadow: inset 0 1px 2px rgba(255, 255, 255, 0.8), 0 2px 4px rgba(67, 56, 202, 0.08);
}

.studio-main-row {
  display: flex;
  gap: 24px;
  align-items: flex-start;
  width: 100%;
  max-width: 100%;
  min-width: 0;
  box-sizing: border-box;
  overflow: hidden;
}

@media (max-width: 640px) {
  .studio-main-row {
    flex-direction: column;
    align-items: center;
  }
}

.studio-preview-col {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  min-width: 120px;
  flex-shrink: 0;
}

.studio-avatar-glow {
  width: 96px;
  height: 96px;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 30%, #FFFFFF, #F1F5F9);
  border: 4px solid var(--lego-blue);
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  box-shadow: 0 8px 24px rgba(59, 130, 246, 0.28), inset 0 2px 6px rgba(0, 0, 0, 0.08);
  transition: border-color 0.25s, box-shadow 0.25s;
}

.studio-avatar-box {
  width: 80px;
  height: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
  filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.12));
}

.studio-hat-badge {
  position: absolute;
  top: -6px;
  right: -4px;
  width: 32px;
  height: 32px;
  background: #FFFFFF;
  border: 2px solid #CBD5E1;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  box-shadow: 0 3px 8px rgba(0,0,0,0.18);
  animation: pulseHat 2s infinite ease-in-out;
}

@keyframes pulseHat {
  0%, 100% { transform: scale(1) rotate(0deg); }
  50% { transform: scale(1.1) rotate(5deg); }
}

.studio-xp-pill {
  font-size: 11px;
  font-weight: 800;
  color: #64748B;
  background: #F1F5F9;
  padding: 3px 10px;
  border-radius: 10px;
  border: 1px solid #E2E8F0;
}

.studio-controls-col {
  flex: 1 1 0;
  min-width: 0;
  max-width: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 12px;
  box-sizing: border-box;
  overflow: hidden;
}

.studio-input-group {
  display: flex;
  flex-direction: column;
  gap: 4px;
  width: 100%;
  min-width: 0;
  max-width: 100%;
  box-sizing: border-box;
}

.studio-label {
  font-size: 11px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  color: #64748B;
  display: flex;
  align-items: center;
  gap: 4px;
}

.studio-text-input {
  width: 100%;
  max-width: 280px;
  box-sizing: border-box;
  padding: 10px 14px;
  font-family: var(--font-main);
  font-size: 15px;
  font-weight: 800;
  color: #1E293B;
  background: #F8FAFC;
  border: 2px solid #CBD5E1;
  border-radius: var(--radius-sm);
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s, background 0.2s;
}

.studio-text-input:focus {
  background: #FFFFFF;
  border-color: #3B82F6;
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
}

.studio-chips-carousel {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  max-width: 100%;
  width: 100%;
  min-width: 0;
  box-sizing: border-box;
  padding: 2px 0 4px 0;
}

.studio-chips-carousel::-webkit-scrollbar {
  display: none;
}

.studio-chip-btn {
  padding: 6px 12px;
  border-radius: 12px;
  border: 2px solid #E2E8F0;
  background: #FFFFFF;
  font-family: var(--font-main);
  font-size: 12px;
  font-weight: 800;
  color: #475569;
  cursor: pointer;
  white-space: nowrap;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: all 0.15s cubic-bezier(0.4, 0, 0.2, 1);
  flex-shrink: 0;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
}

.studio-chip-btn:hover {
  border-color: #94A3B8;
  background: #F8FAFC;
  transform: translateY(-1px);
}

.studio-chip-btn.active {
  border-color: #3B82F6;
  background: linear-gradient(135deg, #EFF6FF, #DBEAFE);
  color: #1D4ED8;
  box-shadow: 0 3px 8px rgba(59, 130, 246, 0.25);
  transform: translateY(-1px);
}

.studio-colors-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  max-width: 100%;
  width: 100%;
  box-sizing: border-box;
  padding: 4px 0 6px 0;
}

.studio-color-circle {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  cursor: pointer;
  border: 3px solid #FFFFFF;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
  transition: transform 0.18s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.18s;
  flex-shrink: 0;
}

.studio-color-circle:hover {
  transform: scale(1.18);
}

.studio-color-circle.active {
  transform: scale(1.25);
  box-shadow: 0 0 0 3px #1E293B, 0 4px 8px rgba(0,0,0,0.3);
}

/* Profile Summary Clay Card */
.profile-card {
  background: var(--surface-card);
  border-radius: var(--radius-lg);
  padding: 20px 24px;
  box-shadow: var(--shadow-clay);
  border: 3px solid #F1F5F9;
  width: 100%;
  max-width: 580px;
  display: flex;
  align-items: center;
  gap: 20px;
  position: relative;
}

.profile-avatar-circle {
  width: 74px;
  height: 74px;
  border-radius: 50%;
  background: #F8FAFC;
  border: 3px solid var(--lego-blue);
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: inset 0 2px 6px rgba(0, 0, 0, 0.1);
  flex-shrink: 0;
  overflow: hidden;
}

.profile-details {
  flex: 1;
}

.profile-header-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.profile-name {
  font-size: 20px;
  font-weight: 800;
  color: var(--text-dark);
}

.profile-level-badge {
  background: var(--lego-purple);
  color: white;
  font-weight: 800;
  font-size: 12px;
  padding: 4px 10px;
  border-radius: 12px;
}

.profile-title-text {
  font-size: 13px;
  color: var(--text-muted);
  font-weight: 600;
  margin-top: 2px;
}

.xp-bar-container {
  margin-top: 10px;
}

.xp-bar-bg {
  width: 100%;
  height: 12px;
  background: #E2E8F0;
  border-radius: 6px;
  overflow: hidden;
  box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.15);
}

.xp-bar-fill {
  height: 100%;
  width: 0%;
  background: linear-gradient(90deg, #FBBF24, #F59E0B);
  border-radius: 6px;
  transition: width 0.5s cubic-bezier(0.4, 0, 0.2, 1);
}

.xp-label-row {
  display: flex;
  justify-content: space-between;
  font-size: 11px;
  color: var(--text-muted);
  font-weight: 700;
  margin-top: 4px;
}

/* Home Action Grid (Top 2 Cards) */
.home-actions-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
  width: 100%;
  max-width: 720px;
}

@media (max-width: 640px) {
  .home-actions-grid {
    grid-template-columns: 1fr;
  }
}

/* Secondary Actions Grid (Botlarla Oyna, Nasıl Oynanır, Ayarlar) */
.home-secondary-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
  width: 100%;
  max-width: 720px;
}

@media (max-width: 640px) {
  .home-secondary-grid {
    grid-template-columns: 1fr;
  }
}

.action-card-btn {
  background: var(--surface-card);
  border-radius: var(--radius-md);
  padding: 20px 16px;
  box-shadow: var(--shadow-clay);
  border: 3px solid #E2E8F0;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 8px;
  transition: all 0.18s cubic-bezier(0.34, 1.56, 0.64, 1);
  box-sizing: border-box;
}

.action-card-btn:hover {
  transform: translateY(-4px);
  border-color: var(--lego-blue);
}

.action-card-btn:active {
  transform: translateY(2px);
  box-shadow: 0 3px 0 rgba(0, 0, 0, 0.12);
}

.action-card-btn.primary {
  background: linear-gradient(145deg, #3B82F6, #2563EB);
  color: white;
  border-color: #1D4ED8;
}

.action-card-btn.emerald {
  background: linear-gradient(145deg, #10B981, #059669);
  color: white;
  border-color: #047857;
}

.action-card-btn.primary .action-title,
.action-card-btn.primary .action-desc,
.action-card-btn.emerald .action-title,
.action-card-btn.emerald .action-desc {
  color: white;
}

.action-icon {
  font-size: 34px;
}

.action-title {
  font-size: 17px;
  font-weight: 800;
}

.action-desc {
  font-size: 12px;
  color: var(--text-muted);
  line-height: 1.4;
}

/* Server Status Indicator Pill */
.server-status-pill {
  font-size: 12px;
  font-weight: 800;
  padding: 6px 16px;
  border-radius: 20px;
  background: #F1F5F9;
  color: #475569;
  border: 1px solid #CBD5E1;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-top: -6px;
  margin-bottom: 4px;
  transition: all 0.2s ease;
}

.server-status-pill.online {
  background: #ECFDF5;
  color: #065F46;
  border-color: #A7F3D0;
}

.server-status-pill.offline {
  background: #FEF3C7;
  color: #92400E;
  border-color: #FDE68A;
}

/* Lobby Share Link Bar */
.lobby-share-url {
  width: 100%;
  padding: 8px 12px;
  font-size: 13px;
  font-weight: 700;
  color: #1E293B;
  background: #F8FAFC;
  border: 2px dashed #CBD5E1;
  border-radius: 8px;
  margin-top: 10px;
  box-sizing: border-box;
  text-align: center;
  font-family: monospace;
}

.btn-kick-player {
  background: #FEE2E2;
  color: #DC2626;
  border: 1px solid #FCA5A5;
  border-radius: 50%;
  width: 24px;
  height: 24px;
  font-size: 13px;
  font-weight: 900;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  margin-left: auto;
  transition: all 0.15s;
}

.btn-kick-player:hover {
  background: #EF4444;
  color: white;
  transform: scale(1.1);
}

/* Settings Toggle Rows */
.settings-list {
  display: flex;
  flex-direction: column;
  gap: 14px;
  margin: 16px 0;
}

.settings-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 14px;
  background: #F8FAFC;
  border: 1px solid #E2E8F0;
  border-radius: var(--radius-sm);
}

.settings-item-label {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.settings-item-title {
  font-size: 14px;
  font-weight: 800;
  color: #1E293B;
}

.settings-item-sub {
  font-size: 12px;
  color: #64748B;
}

.switch-toggle {
  position: relative;
  display: inline-block;
  width: 46px;
  height: 26px;
}

.switch-toggle input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider-round {
  position: absolute;
  cursor: pointer;
  top: 0; left: 0; right: 0; bottom: 0;
  background-color: #CBD5E1;
  transition: .3s cubic-bezier(0.4, 0, 0.2, 1);
  border-radius: 26px;
}

.slider-round:before {
  position: absolute;
  content: "";
  height: 20px;
  width: 20px;
  left: 3px;
  bottom: 3px;
  background-color: white;
  transition: .3s cubic-bezier(0.4, 0, 0.2, 1);
  border-radius: 50%;
  box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

input:checked + .slider-round {
  background-color: #10B981;
}

input:checked + .slider-round:before {
  transform: translateX(20px);
}

/* Rules / How To Play Modal Styles */
.rules-container {
  max-height: 420px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding-right: 4px;
  margin: 14px 0;
  text-align: left;
}

.rules-card {
  background: #F8FAFC;
  border: 1px solid #E2E8F0;
  border-radius: 12px;
  padding: 12px 14px;
}

.rules-card-title {
  font-size: 14px;
  font-weight: 800;
  color: #1E293B;
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 6px;
}

.rules-card-body {
  font-size: 12px;
  line-height: 1.5;
  color: #475569;
}

/* Join Room Card */
.join-room-card {
  background: var(--surface-card);
  border-radius: var(--radius-md);
  padding: 18px 22px;
  box-shadow: var(--shadow-clay);
  border: 3px solid #E2E8F0;
  width: 100%;
  max-width: 480px;
  display: flex;
  gap: 12px;
}

.join-room-input {
  flex: 1;
  padding: 12px 16px;
  font-size: 16px;
  font-weight: 800;
  text-transform: uppercase;
  border: 2px solid #CBD5E1;
  border-radius: var(--radius-sm);
  outline: none;
  font-family: var(--font-main);
  text-align: center;
  letter-spacing: 2px;
}

.join-room-input:focus {
  border-color: var(--lego-blue);
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
}

.btn-pill {
  padding: 12px 24px;
  font-weight: 800;
  font-size: 15px;
  border-radius: var(--radius-sm);
  border: none;
  cursor: pointer;
  background: var(--lego-green);
  color: white;
  box-shadow: 0 4px 0 #059669;
  transition: transform 0.1s ease, box-shadow 0.1s ease;
  font-family: var(--font-main);
}

.btn-pill:active {
  transform: translateY(3px);
  box-shadow: 0 1px 0 #059669;
}

/* Floating Audio / Wardrobe Home Buttons */
.home-float-bar {
  display: flex;
  gap: 12px;
  margin-top: 8px;
}

.btn-icon-round {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  border: 2px solid #CBD5E1;
  background: white;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: var(--shadow-sm);
  transition: all 0.15s ease;
}

.btn-icon-round:active {
  transform: scale(0.92);
}

.btn-icon-round.active {
  background: var(--lego-blue);
  color: white;
  border-color: #1D4ED8;
}

/* ==========================================================================
   LOBBY SCREEN
   ========================================================================== */

.lobby-container {
  max-width: 840px;
  margin: 0 auto;
  padding: 24px 16px;
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.lobby-header-card {
  background: var(--surface-card);
  border-radius: var(--radius-lg);
  padding: 24px;
  box-shadow: var(--shadow-clay);
  border: 3px solid #F1F5F9;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
}

.room-code-tag {
  font-size: 32px;
  font-weight: 900;
  color: var(--lego-blue);
  letter-spacing: 3px;
}

.lobby-qr-box {
  width: 110px;
  height: 110px;
  border-radius: 12px;
  background: #F8FAFC;
  padding: 6px;
  border: 2px dashed #CBD5E1;
}

.lobby-qr-box img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.lobby-players-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 14px;
}

.lobby-player-card {
  background: var(--surface-card);
  border-radius: var(--radius-md);
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 14px;
  box-shadow: var(--shadow-sm);
  border: 2px solid #E2E8F0;
}

.lobby-player-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: #F1F5F9;
  overflow: hidden;
}

.lobby-player-info {
  flex: 1;
}

.lobby-player-name {
  font-weight: 800;
  font-size: 16px;
}

.lobby-player-title {
  font-size: 12px;
  color: var(--text-muted);
}

.lobby-player-badge {
  font-size: 11px;
  font-weight: 700;
  background: #E0E7FF;
  color: #3730A3;
  padding: 3px 8px;
  border-radius: 8px;
}

.lobby-controls-bar {
  display: flex;
  gap: 14px;
  justify-content: flex-end;
}

/* ==========================================================================
   GAME SCREEN
   ========================================================================== */

.game-screen {
  height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: #0B0F19;
}

/* Top Game HUD Bar */
.game-hud-top {
  height: 52px;
  background: rgba(15, 23, 42, 0.88);
  backdrop-filter: blur(16px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.12);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  z-index: 10;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
  color: #FFFFFF;
}

.hud-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.hud-round-pill {
  background: rgba(245, 158, 11, 0.2);
  color: #FBBF24;
  border: 1px solid rgba(245, 158, 11, 0.5);
  font-weight: 800;
  font-size: 13px;
  padding: 5px 12px;
  border-radius: 12px;
}

.hud-active-turn-box {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  font-weight: 800;
  color: #F8FAFC;
}

.hud-turn-avatar {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  border: 2px solid #38BDF8;
  background: #1E293B;
}
  background: #F8FAFC;
}

.hud-right-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.btn-hud-leave {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #FEE2E2;
  color: #DC2626;
  border: 1.5px solid #FCA5A5;
  border-radius: 20px;
  padding: 6px 14px;
  font-family: var(--font-main);
  font-size: 13px;
  font-weight: 800;
  cursor: pointer;
  box-shadow: 0 2px 0 #F87171;
  transition: all 0.15s ease;
}

.btn-hud-leave:hover {
  background: #EF4444;
  color: #FFFFFF;
  border-color: #DC2626;
  transform: translateY(-1px);
}

.btn-hud-leave:active {
  transform: translateY(1px);
  box-shadow: none;
}

/* ==========================================================================
   TURN NOTIFICATION BANNER (Top Screen Unmissable Alert)
   ========================================================================== */

.hud-turn-alert-banner {
  display: none !important;
}

/* 4 Cities Selection Grid in Modal */
.map-selection-grid.four-cities {
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
}

.map-card-box .map-sub {
  font-size: 11px;
  color: #64748B;
  font-weight: 600;
  margin-top: 2px;
}

/* Players HUD Carousel (Floating Glass Capsules over canvas) */
.players-hud-carousel {
  position: absolute;
  top: 58px;
  left: 14px;
  display: flex;
  gap: 8px;
  padding: 4px 0;
  overflow-x: auto;
  background: transparent;
  border-bottom: none;
  scrollbar-width: none;
  z-index: 8;
  pointer-events: auto;
}

.players-hud-carousel::-webkit-scrollbar {
  display: none;
}

.player-hud-card {
  flex-shrink: 0;
  background: rgba(15, 23, 42, 0.82);
  backdrop-filter: blur(14px);
  border-radius: 20px;
  padding: 5px 12px;
  display: flex;
  align-items: center;
  gap: 8px;
  border: 1.5px solid rgba(255, 255, 255, 0.15);
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35);
  color: #FFFFFF;
  transition: all 0.2s ease;
}

.player-hud-card.active-turn {
  border-color: #F59E0B;
  background: rgba(30, 41, 59, 0.95);
  box-shadow: 0 0 16px rgba(245, 158, 11, 0.45);
  transform: translateY(-2px);
}

.player-hud-card .player-hud-name {
  color: #F8FAFC;
  font-weight: 700;
  font-size: 12px;
}

.player-hud-card .hud-stat-pill {
  color: #FDE047;
  font-weight: 800;
  font-size: 12px;
}

.hud-avatar-box {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  position: relative;
}

.hud-shield-badge,
.hud-bot-badge {
  position: absolute;
  bottom: -4px;
  right: -4px;
  font-size: 11px;
}

.hud-pname {
  font-size: 13px;
  font-weight: 800;
}

.hud-scores {
  display: flex;
  gap: 8px;
  font-size: 12px;
  font-weight: 700;
}

.hud-star {
  color: #D97706;
}

.hud-coin {
  color: #2563EB;
}

/* Board Arena Canvas */
.board-arena-container {
  flex: 1;
  position: relative;
  overflow: hidden;
  background: #0B0F19;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: grab;
}

.board-arena-container:active {
  cursor: grabbing;
}

#board-canvas {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

/* Bottom Floating Mobile Control Dock */
.game-bottom-dock {
  position: absolute;
  bottom: 16px;
  left: 50%;
  transform: translateX(-50%);
  width: calc(100% - 32px);
  max-width: 660px;
  background: rgba(15, 23, 42, 0.85);
  backdrop-filter: blur(18px);
  border-radius: 36px;
  padding: 8px 16px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.14);
  display: flex;
  flex-direction: column;
  gap: 0;
  z-index: 20;
}

.dock-status-bar {
  display: none !important;
}

.dock-buttons-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.dock-secondary-btn.speed-btn {
  background: rgba(245, 158, 11, 0.15);
  color: #FBBF24;
  border-color: rgba(245, 158, 11, 0.4);
  font-weight: 900;
  min-width: 68px;
}

.dock-secondary-btn.speed-btn:hover {
  background: rgba(245, 158, 11, 0.3);
  border-color: #F59E0B;
}

/* Big Juicy "ZAR AT" Roll Button */
.btn-roll-dice {
  flex: 2;
  padding: 14px 20px;
  font-size: 18px;
  font-weight: 900;
  color: white;
  background: linear-gradient(135deg, #EF4444, #DC2626);
  border: none;
  border-radius: var(--radius-md);
  box-shadow: 0 5px 0 #991B1B, 0 8px 16px rgba(239, 68, 68, 0.35);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  transition: all 0.15s ease;
}

.btn-roll-dice:disabled {
  opacity: 0.55;
  cursor: not-allowed;
  box-shadow: none;
  transform: none;
}

.btn-roll-dice:not(:disabled):active {
  transform: translateY(4px);
  box-shadow: 0 1px 0 #991B1B;
}

.pulse-turn {
  animation: turnPulse 1.4s infinite alternate ease-in-out;
}

@keyframes turnPulse {
  0% { transform: scale(1); box-shadow: 0 5px 0 #991B1B, 0 8px 16px rgba(239, 68, 68, 0.35); }
  100% { transform: scale(1.04); box-shadow: 0 5px 0 #991B1B, 0 14px 24px rgba(239, 68, 68, 0.55); }
}

.dock-secondary-btn {
  flex: 1;
  padding: 14px 10px;
  border-radius: var(--radius-md);
  border: 2px solid #E2E8F0;
  background: white;
  font-size: 13px;
  font-weight: 800;
  color: #1E293B;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  cursor: pointer;
  box-shadow: var(--shadow-sm);
  position: relative;
}

.dock-secondary-btn:active {
  transform: translateY(2px);
}

.btn-badge {
  position: absolute;
  top: -6px;
  right: -6px;
  background: var(--lego-red);
  color: white;
  font-size: 11px;
  font-weight: 800;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

/* Event Feed HUD (Corner Ticker) */
.hud-event-feed {
  position: absolute;
  top: 130px;
  right: 16px;
  width: 260px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  pointer-events: none;
  z-index: 15;
}

.hud-log-item {
  background: rgba(15, 23, 42, 0.85);
  backdrop-filter: blur(6px);
  color: white;
  padding: 6px 12px;
  border-radius: 8px;
  font-size: 12px;
  line-height: 1.3;
  animation: slideInRight 0.3s ease;
}

.log-time {
  color: #94A3B8;
  font-size: 10px;
  margin-right: 4px;
}

@keyframes slideInRight {
  from { opacity: 0; transform: translateX(20px); }
  to { opacity: 1; transform: translateX(0); }
}

/* ==========================================================================
   MODALS & OVERLAYS
   ========================================================================== */

.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(15, 23, 42, 0.6);
  backdrop-filter: blur(8px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 100;
  padding: 16px;
  animation: fadeIn 0.2s ease;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.modal-card {
  background: var(--surface-card);
  border-radius: var(--radius-lg);
  padding: 24px;
  width: 100%;
  max-width: 520px;
  box-shadow: var(--shadow-clay);
  border: 3px solid #F1F5F9;
  max-height: 90vh;
  overflow-y: auto;
}

/* ==========================================================================
   3D SINGLE DIE ROLLER MODAL
   ========================================================================== */
.dice-roll-modal {
  max-width: 360px;
  text-align: center;
  background: radial-gradient(circle at 50% 20%, #FFFFFF, #F8FAFC);
  border: 4px solid #E2E8F0;
  box-shadow: 0 24px 48px -12px rgba(15, 23, 42, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.9);
  padding: 28px 24px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 18px;
}

.dice-roller-title {
  font-size: 13px;
  font-weight: 900;
  letter-spacing: 0.8px;
  text-transform: uppercase;
  color: #4338CA;
  background: #EEF2FF;
  padding: 6px 16px;
  border-radius: 14px;
}

.dice-single-wrapper {
  position: relative;
  width: 110px;
  height: 110px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.single-dice-box {
  width: 86px;
  height: 86px;
  background: #FFFFFF;
  border-radius: 20px;
  border: 3px solid #CBD5E1;
  box-shadow: 0 14px 28px rgba(15, 23, 42, 0.18), inset 0 2px 4px rgba(255, 255, 255, 0.9), inset 0 -4px 6px rgba(0, 0, 0, 0.08);
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  transition: transform 0.2s ease;
}

.single-dice-box.rolling {
  animation: rollTumble 0.5s infinite ease-in-out;
}

.single-dice-box.landed {
  animation: dicePopLand 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
}

@keyframes rollTumble {
  0% { transform: rotate(0deg) scale(0.9) translateY(0); }
  25% { transform: rotate(-25deg) scale(1.08) translateY(-14px); }
  50% { transform: rotate(20deg) scale(0.95) translateY(-6px); }
  75% { transform: rotate(-15deg) scale(1.05) translateY(-12px); }
  100% { transform: rotate(0deg) scale(0.9) translateY(0); }
}

@keyframes dicePopLand {
  0% { transform: scale(0.8) translateY(-10px); }
  60% { transform: scale(1.22) translateY(2px); }
  100% { transform: scale(1) translateY(0); }
}

.dice-pip-face {
  width: 62px;
  height: 62px;
  position: relative;
}

.pip {
  position: absolute;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 35%, #DC2626, #991B1B);
  box-shadow: inset 0 1px 2px rgba(255, 255, 255, 0.6), 0 2px 4px rgba(0, 0, 0, 0.25);
}

.pip-center { top: 24px; left: 24px; }
.pip-top-left { top: 4px; left: 4px; }
.pip-top-right { top: 4px; right: 4px; }
.pip-mid-left { top: 24px; left: 4px; }
.pip-mid-right { top: 24px; right: 4px; }
.pip-bottom-left { bottom: 4px; left: 4px; }
.pip-bottom-right { bottom: 4px; right: 4px; }

.dice-result-badge {
  font-size: 17px;
  font-weight: 900;
  color: #1E293B;
  background: #F1F5F9;
  border: 2px solid #CBD5E1;
  padding: 8px 20px;
  border-radius: 16px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 18px;
}

.modal-title {
  font-size: 20px;
  font-weight: 800;
}

.modal-close-btn {
  background: #F1F5F9;
  border: none;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  cursor: pointer;
  font-size: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* Wardrobe Customization Modal */
.wardrobe-tabs-section {
  margin-bottom: 18px;
}

.wardrobe-section-label {
  font-size: 14px;
  font-weight: 800;
  color: #475569;
  margin-bottom: 8px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.wardrobe-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 10px;
}

.wardrobe-item {
  border: 2px solid #E2E8F0;
  border-radius: 12px;
  padding: 10px 6px;
  text-align: center;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  transition: all 0.15s ease;
}

.wardrobe-item.selected {
  border-color: var(--lego-blue);
  background: #EFF6FF;
  box-shadow: 0 4px 8px rgba(59, 130, 246, 0.2);
}

.wardrobe-item.locked {
  opacity: 0.45;
  filter: grayscale(0.8);
  cursor: not-allowed;
}

.wardrobe-avatar-preview {
  width: 44px;
  height: 44px;
}

.wardrobe-dice-preview {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
}

.wardrobe-item-name {
  font-size: 11px;
  font-weight: 700;
  color: #1E293B;
}

.wardrobe-item-tag {
  font-size: 10px;
  font-weight: 800;
  color: var(--lego-blue);
}

/* Shop Modal Items */
.shop-items-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 12px;
}

.shop-item-card {
  background: #F8FAFC;
  border: 2px solid #E2E8F0;
  border-radius: 14px;
  padding: 14px;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 8px;
  box-sizing: border-box;
  overflow: hidden;
}

.shop-item-card.disabled {
  opacity: 0.5;
}

.shop-item-icon {
  font-size: 28px;
  color: var(--lego-yellow);
}

.shop-item-name {
  font-weight: 800;
  font-size: 13.5px;
  line-height: 1.25;
  color: #1E293B;
  word-break: break-word;
  max-width: 100%;
}

.shop-item-desc {
  font-size: 11px;
  color: #64748B;
  line-height: 1.35;
  word-break: break-word;
  max-width: 100%;
}

.shop-buy-btn {
  width: 100%;
  padding: 8px 10px;
  background: var(--lego-yellow);
  color: #78350F;
  border: none;
  border-radius: 8px;
  font-weight: 800;
  font-size: 12px;
  cursor: pointer;
  box-shadow: 0 2px 0 #D97706;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  box-sizing: border-box;
}

.shop-buy-btn:disabled {
  background: #CBD5E1;
  color: #64748B;
  box-shadow: none;
  cursor: not-allowed;
}

/* Inventory Modal */
.inventory-items-grid {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.inventory-item-card {
  background: #F8FAFC;
  border: 2px solid #E2E8F0;
  border-radius: 14px;
  padding: 12px 14px;
  display: flex;
  align-items: center;
  gap: 12px;
  box-sizing: border-box;
  overflow: hidden;
}

.inv-icon {
  font-size: 28px;
  flex-shrink: 0;
}

.inv-info {
  flex: 1;
  min-width: 0; /* Prevents text overflowing flex container */
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.inv-name {
  font-weight: 800;
  font-size: 14px;
  color: #1E293B;
  word-break: break-word;
  line-height: 1.25;
}

.inv-desc {
  font-size: 11.5px;
  color: #64748B;
  line-height: 1.35;
  word-break: break-word;
}

.inv-use-btn {
  padding: 8px 18px;
  background: var(--lego-green);
  color: white;
  border: none;
  border-radius: 10px;
  font-weight: 800;
  font-size: 12.5px;
  cursor: pointer;
  box-shadow: 0 2px 0 #047857;
  flex-shrink: 0;
  white-space: nowrap;
}
  cursor: pointer;
  box-shadow: 0 2px 0 #059669;
}

.inv-use-btn:disabled {
  background: #CBD5E1;
  cursor: not-allowed;
  box-shadow: none;
}

/* Emote Radial / Grid Picker */
.emotes-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
}

.emote-bubble-btn {
  background: #F8FAFC;
  border: 2px solid #E2E8F0;
  border-radius: 14px;
  padding: 12px 6px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  cursor: pointer;
  transition: transform 0.15s ease;
}

.emote-bubble-btn:active {
  transform: scale(0.9);
}

.em-char {
  font-size: 28px;
}

.em-label {
  font-size: 11px;
  font-weight: 700;
  color: #475569;
}

/* Floating Emoji Reactions */
.floating-emote-bubble {
  position: fixed;
  bottom: 120px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 54px;
  z-index: 150;
  animation: floatUpFade 2.2s forwards cubic-bezier(0.2, 0.8, 0.2, 1);
  pointer-events: none;
}

@keyframes floatUpFade {
  0% { opacity: 0; transform: translate(-50%, 20px) scale(0.5); }
  20% { opacity: 1; transform: translate(-50%, -20px) scale(1.2); }
  70% { opacity: 1; transform: translate(-50%, -80px) scale(1); }
  100% { opacity: 0; transform: translate(-50%, -140px) scale(0.8); }
}

/* Victory Podium Modal */
.podium-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-top: 16px;
}

.podium-rank-card {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 14px;
  border-radius: 14px;
  background: #F8FAFC;
  border: 2px solid #E2E8F0;
}

.podium-rank-card.rank-1 {
  background: #FEF9C3;
  border-color: #EAB308;
  box-shadow: 0 4px 12px rgba(234, 179, 8, 0.25);
}

.podium-badge {
  font-weight: 900;
  font-size: 13px;
  width: 90px;
}

.podium-avatar {
  width: 44px;
  height: 44px;
}

.podium-pname {
  font-weight: 800;
  font-size: 15px;
  flex: 1;
}

.podium-score {
  font-weight: 700;
  font-size: 13px;
  color: #475569;
}

/* Confetti particles */
.confetti-piece {
  position: fixed;
  width: 10px;
  height: 14px;
  top: -20px;
  z-index: 99;
  pointer-events: none;
  animation: confettiFall linear infinite;
}

@keyframes confettiFall {
  0% { transform: translateY(0) rotate(0deg); opacity: 1; }
  100% { transform: translateY(105vh) rotate(720deg); opacity: 0.2; }
}

/* Toast Notifications */
.toast-container {
  position: fixed;
  top: 76px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  flex-direction: column;
  gap: 8px;
  z-index: 200;
  pointer-events: none;
}

.toast {
  background: rgba(15, 23, 42, 0.9);
  color: white;
  padding: 10px 20px;
  border-radius: 20px;
  font-size: 13px;
  font-weight: 700;
  box-shadow: var(--shadow-md);
  animation: toastPop 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
  text-align: center;
}

.toast-success { background: #059669; }
.toast-error { background: #DC2626; }

@keyframes toastPop {
  from { transform: scale(0.8); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}

.toast.fade-out {
  opacity: 0;
  transform: translateY(-10px);
  transition: all 0.4s ease;
}

/* Status icons under player HUD */
.hud-badges-row {
  display: flex;
  gap: 3px;
  position: absolute;
  bottom: -6px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(15, 23, 42, 0.75);
  border-radius: 8px;
  padding: 1px 4px;
}

.status-icon {
  font-size: 11px;
}

/* Floating Camera Controls on Board Arena */
.floating-cam-controls {
  position: absolute;
  bottom: 95px;
  left: 20px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  z-index: 12;
}

.cam-btn {
  width: 36px;
  height: 36px;
  border-radius: 12px;
  background: rgba(15, 23, 42, 0.85);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: #FFFFFF;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.35);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  font-weight: 900;
  cursor: pointer;
  color: #1E293B;
  transition: transform 0.1s ease;
}

.cam-btn:active {
  transform: scale(0.9);
}

/* Floating Speech Bubble Pop for Quick Chat */
.speech-bubble-pop {
  position: absolute;
  top: -46px;
  left: 50%;
  transform: translateX(-50%);
  background: #1E293B;
  color: white;
  font-size: 12px;
  font-weight: 700;
  padding: 6px 12px;
  border-radius: 14px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
  white-space: nowrap;
  pointer-events: none;
  z-index: 30;
  animation: speechPop 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.speech-bubble-pop::after {
  content: '';
  position: absolute;
  bottom: -6px;
  left: 50%;
  transform: translateX(-50%);
  border-width: 6px 6px 0;
  border-style: solid;
  border-color: #1E293B transparent transparent;
}

@keyframes speechPop {
  from { opacity: 0; transform: translate(-50%, 10px) scale(0.7); }
  to { opacity: 1; transform: translate(-50%, 0) scale(1); }
}

/* Tile Inspector Popover */
.tile-inspector-card {
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
}

.ti-title {
  font-size: 20px;
  font-weight: 900;
}

.ti-desc {
  font-size: 14px;
  color: #475569;
  line-height: 1.4;
}

.ti-steps-badge {
  display: inline-block;
  background: #EFF6FF;
  color: #2563EB;
  font-weight: 800;
  font-size: 13px;
  padding: 6px 14px;
  border-radius: 10px;
  border: 1px solid #BFDBFE;
}

.ti-players-list {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  justify-content: center;
  margin-top: 6px;
}

.ti-player-pill {
  padding: 4px 10px;
  border-radius: 10px;
  border: 2px solid;
  font-size: 12px;
  font-weight: 800;
  background: #F8FAFC;
}

/* Trade Modals */
.trade-form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  margin-top: 12px;
}

.trade-col {
  background: #F8FAFC;
  padding: 14px;
  border-radius: 14px;
  border: 2px solid #E2E8F0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.trade-col-title {
  font-weight: 800;
  font-size: 13px;
  color: #1E293B;
  text-transform: uppercase;
}

.trade-input-row {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.trade-input-row label {
  font-size: 11px;
  font-weight: 700;
  color: #64748B;
}

.trade-select, .trade-number-input {
  padding: 8px 10px;
  border-radius: 8px;
  border: 1.5px solid #CBD5E1;
  font-family: var(--font-main);
  font-weight: 700;
  outline: none;
}

/* Incoming Trade Modal */
.incoming-trade-card {
  text-align: center;
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.inc-trade-boxes {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  align-items: center;
  gap: 10px;
  background: #F8FAFC;
  padding: 16px;
  border-radius: 14px;
  border: 2px solid #E2E8F0;
}

.inc-box {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.inc-box-label {
  font-size: 11px;
  font-weight: 800;
  color: #64748B;
  text-transform: uppercase;
}

.inc-box-val {
  font-size: 14px;
  font-weight: 900;
  color: #1E293B;
}

/* Map Selection in Create Room */
.map-selection-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  margin-bottom: 18px;
}

.map-card-label {
  cursor: pointer;
}

.map-card-label input {
  display: none;
}

.map-card-box {
  background: #F8FAFC;
  border: 2px solid #E2E8F0;
  border-radius: 12px;
  padding: 12px 6px;
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  transition: all 0.15s ease;
}

.map-card-label input:checked + .map-card-box {
  border-color: var(--lego-blue);
  background: #EFF6FF;
  box-shadow: 0 4px 10px rgba(59, 130, 246, 0.2);
}

.map-icon {
  font-size: 26px;
}

.map-name {
  font-size: 12px;
  font-weight: 800;
  color: #1E293B;
}

/* Lobby Map Switcher */
.lobby-map-switcher {
  display: flex;
  gap: 8px;
  margin-top: 8px;
}

.lobby-map-btn {
  padding: 6px 12px;
  border-radius: 8px;
  border: 2px solid #CBD5E1;
  background: white;
  font-size: 12px;
  font-weight: 800;
  cursor: pointer;
}

.lobby-map-btn.active {
  background: var(--lego-blue);
  color: white;
  border-color: #1D4ED8;
}

/* Quick Chat Presets */
.chat-presets-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.chat-preset-btn {
  padding: 12px 16px;
  border-radius: 12px;
  border: 2px solid #E2E8F0;
  background: #F8FAFC;
  font-size: 14px;
  font-weight: 800;
  text-align: left;
  cursor: pointer;
  transition: background 0.15s ease;
}

.chat-preset-btn:hover {
  background: #EFF6FF;
  border-color: var(--lego-blue);
}

/* ==========================================================================
   ROUND PROGRESS TRACKER & FINAL ROUND BANNER (Item 12)
   ========================================================================== */

.hud-round-card {
  display: flex;
  flex-direction: column;
  gap: 4px;
  background: #FFFFFF;
  border: 2px solid #E2E8F0;
  border-radius: var(--radius-sm);
  padding: 6px 14px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
  min-width: 140px;
}

.hud-round-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.hud-round-title {
  font-size: 13px;
  font-weight: 900;
  color: #1E293B;
}

.hud-round-sub {
  font-size: 11px;
  font-weight: 800;
  color: #64748B;
  background: #F1F5F9;
  padding: 2px 8px;
  border-radius: 8px;
}

.hud-round-sub.final-pulse {
  background: #FEF3C7;
  color: #B45309;
  animation: pulseGold 1.5s infinite;
}

@keyframes pulseGold {
  0%, 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.4); }
  50% { transform: scale(1.05); box-shadow: 0 0 0 6px rgba(245, 158, 11, 0); }
}

.hud-round-bar {
  width: 100%;
  height: 6px;
  background: #E2E8F0;
  border-radius: 4px;
  overflow: hidden;
}

.hud-round-fill {
  height: 100%;
  background: linear-gradient(90deg, #3B82F6, #10B981, #F59E0B);
  border-radius: 4px;
  transition: width 0.6s cubic-bezier(0.4, 0, 0.2, 1);
}

.final-round-banner {
  background: linear-gradient(135deg, #F59E0B, #DC2626);
  border: 2px solid #FDE047;
  border-radius: 14px;
  padding: 10px 20px;
  text-align: center;
  color: #FFFFFF;
  margin: 8px auto 0 auto;
  max-width: 480px;
  box-shadow: 0 8px 24px rgba(220, 38, 38, 0.35);
  animation: finalBannerPop 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
}

@keyframes finalBannerPop {
  0% { transform: scale(0.85); opacity: 0; }
  100% { transform: scale(1); opacity: 1; }
}

.final-banner-glow {
  font-size: 16px;
  font-weight: 900;
  letter-spacing: 0.8px;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

.final-banner-sub {
  font-size: 12px;
  font-weight: 700;
  opacity: 0.95;
  margin-top: 2px;
}

/* ==========================================================================
   PROMINENT TILE EVENT CARD OVERLAY & PENALTIES (Items 3, 7, 11)
   ========================================================================== */

.tile-event-overlay {
  position: fixed;
  inset: 0;
  z-index: 1800;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(15, 23, 42, 0.55);
  backdrop-filter: blur(4px);
  pointer-events: none;
  animation: fadeIn 0.2s ease-out;
}

.tile-event-card {
  background: #FFFFFF;
  border-radius: 24px;
  padding: 24px 32px;
  max-width: 420px;
  width: 90%;
  text-align: center;
  box-shadow: 0 24px 48px -12px rgba(15, 23, 42, 0.35);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  animation: popEventCard 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
}

@keyframes popEventCard {
  0% { transform: scale(0.6) translateY(20px); opacity: 0; }
  100% { transform: scale(1) translateY(0); opacity: 1; }
}

.tile-event-card.penalty-mode {
  border: 4px solid #EF4444;
  background: linear-gradient(180deg, #FEF2F2, #FFFFFF);
  box-shadow: 0 24px 48px rgba(239, 68, 68, 0.32);
}

.tile-event-card.reward-mode {
  border: 4px solid #10B981;
  background: linear-gradient(180deg, #ECFDF5, #FFFFFF);
  box-shadow: 0 24px 48px rgba(16, 185, 129, 0.28);
}

.tile-event-card.neutral-mode {
  border: 4px solid #3B82F6;
  background: linear-gradient(180deg, #EFF6FF, #FFFFFF);
  box-shadow: 0 24px 48px rgba(59, 130, 246, 0.25);
}

.tile-event-avatar {
  width: 68px;
  height: 68px;
  border-radius: 50%;
  background: #F8FAFC;
  border: 3px solid #CBD5E1;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.tile-event-icon {
  font-size: 44px;
  line-height: 1;
  filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.15));
  animation: pulseIcon 1.2s infinite ease-in-out;
}

@keyframes pulseIcon {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.15); }
}

.tile-event-title {
  font-size: 20px;
  font-weight: 900;
  color: #1E293B;
  letter-spacing: -0.3px;
}

.tile-event-desc {
  font-size: 14px;
  font-weight: 700;
  color: #475569;
  line-height: 1.4;
}

/* Screen shake for comedic disaster / penalty impact */
.screen-shake-anim {
  animation: shake 0.4s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
}

@keyframes shake {
  10%, 90% { transform: translate3d(-3px, 0, 0); }
  20%, 80% { transform: translate3d(5px, 0, 0); }
  30%, 50%, 70% { transform: translate3d(-6px, 0, 0); }
  40%, 60% { transform: translate3d(6px, 0, 0); }
}

/* ==========================================================================
   INTERACTIVE WHEEL OF FORTUNE (Item 16)
   ========================================================================== */

.mystery-roulette-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
  max-width: 400px;
  width: 100%;
  box-sizing: border-box;
  text-align: center;
  padding: 24px 20px;
}

.roulette-wheel-wrapper {
  position: relative;
  width: 260px;
  height: 260px;
  margin: 16px auto 10px auto;
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
}

.roulette-pointer-holder {
  position: absolute;
  top: -4px;
  left: 50%;
  transform: translateX(-50%);
  transform-origin: 14px 9px;
  width: 28px;
  height: 36px;
  z-index: 15;
  pointer-events: none;
  filter: drop-shadow(0 3px 6px rgba(0, 0, 0, 0.35));
  transition: transform 0.05s ease;
}

.roulette-pointer-svg {
  display: block;
}

.roulette-arrow {
  position: absolute;
  top: -4px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 26px;
  z-index: 10;
  pointer-events: none;
}

.roulette-canvas-disc {
  border-radius: 50%;
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.25), inset 0 0 0 5px #FFFFFF, 0 0 0 2px #CBD5E1;
  display: block;
}

.roulette-center-stud {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 35%, #FFFFFF, #E2E8F0);
  border: 3px solid #F59E0B;
  box-shadow: 0 4px 10px rgba(0,0,0,0.2);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
  pointer-events: none;
}

.mystery-result-box {
  background: #FEF3C7;
  color: #92400E;
  font-size: 15px;
  font-weight: 800;
  padding: 10px 20px;
  border-radius: 14px;
  border: 2px solid #FCD34D;
  width: 100%;
  box-sizing: border-box;
}

/* ==========================================================================
   LANGUAGE SELECTOR
   ========================================================================== */
.lang-selector-bar {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  margin-bottom: 6px;
}

.lang-btn, .lang-pill-btn {
  background: #F1F5F9;
  border: 1.5px solid #CBD5E1;
  color: #475569;
  font-family: var(--font-main);
  font-size: 13px;
  font-weight: 800;
  padding: 6px 14px;
  border-radius: 20px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.lang-btn:hover, .lang-pill-btn:hover {
  background: #E2E8F0;
  color: #1E293B;
  transform: translateY(-1px);
}

.lang-btn.active, .lang-pill-btn.active {
  background: #3B82F6;
  border-color: #2563EB;
  color: #FFFFFF;
  box-shadow: 0 3px 8px rgba(37, 99, 235, 0.35);
}

.settings-lang-toggle {
  display: flex;
  gap: 8px;
}
  border: 2px solid #FCD34D;
  width: 100%;
  box-sizing: border-box;
}

/* ==========================================================================
   MINI-GAME STAKES & NEW MINI-GAMES STYLING (Items 1, 14, 15)
   ========================================================================== */

.mg-stakes-badge {
  background: linear-gradient(135deg, #EEF2FF, #E0E7FF);
  border: 2px solid #818CF8;
  color: #3730A3;
  font-size: 12px;
  font-weight: 900;
  padding: 6px 14px;
  border-radius: 12px;
  margin-bottom: 8px;
  display: inline-block;
  box-shadow: 0 2px 6px rgba(99, 102, 241, 0.15);
}

.lucky-chests-row {
  display: flex;
  gap: 16px;
  justify-content: center;
  margin: 20px 0;
  width: 100%;
}

.lucky-chest-box {
  flex: 1;
  background: #F8FAFC;
  border: 3px solid #E2E8F0;
  border-radius: 18px;
  padding: 16px 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  touch-action: none;
  user-select: none;
  transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1), border-color 0.2s, background 0.2s, box-shadow 0.2s;
}

.lucky-chest-box:hover {
  transform: translateY(-4px) scale(1.05);
  border-color: #F59E0B;
  background: #FFFBEB;
  box-shadow: 0 8px 20px rgba(245, 158, 11, 0.2);
}

.lucky-chest-box.selected {
  border-color: #10B981;
  background: #ECFDF5;
  transform: scale(1.08);
  box-shadow: 0 12px 28px rgba(16, 185, 129, 0.3);
}

.chest-icon {
  font-size: 48px;
  line-height: 1;
  filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.15));
}

.chest-label {
  font-size: 12px;
  font-weight: 800;
  color: #1E293B;
}

.memory-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  max-width: 280px;
  margin: 16px auto;
}

.mem-pad {
  height: 90px;
  border-radius: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 36px;
  cursor: pointer;
  touch-action: none;
  user-select: none;
  border: 3px solid rgba(0, 0, 0, 0.1);
  transition: transform 0.1s, filter 0.15s, box-shadow 0.15s;
}

.pad-red { background: #EF4444; box-shadow: 0 6px 0 #B91C1C; }
.pad-blue { background: #3B82F6; box-shadow: 0 6px 0 #1D4ED8; }
.pad-green { background: #10B981; box-shadow: 0 6px 0 #047857; }
.pad-yellow { background: #FBBF24; box-shadow: 0 6px 0 #D97706; }

.mem-pad:active, .mem-pad.flash {
  transform: translateY(4px);
  filter: brightness(1.35);
  box-shadow: 0 2px 0 rgba(0, 0, 0, 0.2);
}

.mem-status {
  font-size: 14px;
  font-weight: 800;
  color: #64748B;
  margin-top: 10px;
}

/* Responsive adjustments */
@media (max-width: 640px) {
  .home-actions-grid {
    grid-template-columns: 1fr;
  }
  .trade-form-grid {
    grid-template-columns: 1fr;
  }
  .map-selection-grid {
    grid-template-columns: 1fr;
  }
  .game-bottom-dock {
    bottom: 8px;
    width: calc(100% - 16px);
    padding: 10px 12px;
  }
  .btn-roll-dice {
    font-size: 16px;
    padding: 12px 14px;
  }
  .lucky-chests-row {
    gap: 8px;
  }
  .lucky-chest-box {
    padding: 12px 6px;
  }
  .chest-icon {
    font-size: 38px;
  }
}

/* ==========================================================================
   LUCKY DIE & SWAP WAND INTERACTIVE MODALS
   ========================================================================== */
.lucky-die-btn {
  background: #F8FAFC;
  border: 2px solid #E2E8F0;
  border-radius: 14px;
  padding: 14px 10px;
  font-size: 22px;
  font-weight: 900;
  color: #1E293B;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  transition: all 0.18s cubic-bezier(0.34, 1.56, 0.64, 1);
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
}
.lucky-die-btn:hover {
  background: #FEF3C7;
  border-color: #F59E0B;
  color: #B45309;
  transform: translateY(-3px) scale(1.05);
  box-shadow: 0 8px 16px -2px rgba(245, 158, 11, 0.25);
}
.lucky-die-btn span.die-dot {
  font-size: 11px;
  font-weight: 800;
  color: #64748B;
}

.swap-wand-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 14px;
  background: #F8FAFC;
  border: 2px solid #E2E8F0;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.18s ease;
}
.swap-wand-card:hover {
  background: #EFF6FF;
  border-color: #3B82F6;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(59, 130, 246, 0.15);
}
.swap-wand-avatar {
  font-size: 24px;
  margin-right: 10px;
}
.swap-wand-info {
  flex: 1;
  text-align: left;
  min-width: 0;
}
.swap-wand-name {
  font-weight: 800;
  font-size: 14px;
  color: #1E293B;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.swap-wand-sub {
  font-size: 11px;
  color: #64748B;
}
.swap-wand-action-btn {
  background: #8B5CF6;
  color: #FFFFFF;
  border: none;
  font-size: 12px;
  font-weight: 800;
  padding: 6px 12px;
  border-radius: 8px;
  pointer-events: none;
  flex-shrink: 0;
}

  </style>
</head>
<body>

  <!-- ======================================================================
       1. HOME / START SCREEN (Redesigned with Live Character Customizer)
       ====================================================================== -->
  <div id="screen-home" class="screen">
    <div class="home-container">
      
      <!-- Top Language Selector Bar -->
      <div class="lang-selector-bar">
        <button type="button" class="lang-btn active" data-lang="tr">🇹🇷 TR</button>
        <button type="button" class="lang-btn" data-lang="en">🇬🇧 EN</button>
        <button type="button" class="lang-btn" data-lang="de">🇩🇪 DE</button>
        <button type="button" class="lang-btn" data-lang="es">🇪🇸 ES</button>
        <button type="button" class="lang-btn" data-lang="fr">🇫🇷 FR</button>
      </div>

      <!-- Hero Header -->
      <header class="home-hero">
        <div class="hero-badge" data-i18n="hero_badge">🎲 Çok Oyunculu Dünya Turu Masa Oyunu</div>
        <h1 class="hero-title" data-i18n="hero_title">Parti <span>Dünyası</span></h1>
        <p class="hero-subtitle" data-i18n="hero_subtitle">İstanbul, Tokyo, Paris ve New York sokaklarında zar at, yarış ve eğlen!</p>
      </header>

      <!-- Interactive Character Studio Card -->
      <div class="char-studio-card">
        <div class="studio-header">
          <span class="studio-badge" data-i18n="studio_badge">✨ KARAKTERİNİ TASARLA</span>
          <span class="profile-level-badge" id="profile-level">Lv. 1</span>
        </div>

        <div class="studio-main-row">
          <!-- Dynamic Live Character Token Box -->
          <div class="studio-preview-col">
            <div class="studio-avatar-glow" id="studio-avatar-glow">
              <div class="studio-avatar-box" id="profile-avatar-box">
                <!-- Dynamic SVG Avatar -->
              </div>
              <div class="studio-hat-badge" id="studio-hat-badge" title="Seçili Şapka">👑</div>
            </div>
            <div class="profile-title-text" id="profile-title">Acemi Gezgin</div>
            <div class="studio-xp-pill" id="profile-xp-text">0 / 140 XP</div>
          </div>

          <!-- Customizer Controls -->
          <div class="studio-controls-col">
            <!-- Name Input Field -->
            <div class="studio-input-group">
              <label class="studio-label" data-i18n="studio_name_label">Karakter Adın:</label>
              <input type="text" id="home-name-input" class="studio-text-input" placeholder="Adını yaz..." data-i18n-placeholder="studio_name_placeholder" maxlength="14">
            </div>

            <!-- Archetype Selector -->
            <div class="studio-input-group">
              <label class="studio-label" data-i18n="studio_model_label">Karakter Modeli:</label>
              <div class="studio-chips-carousel" id="home-avatar-chips">
                <!-- Injected dynamically -->
              </div>
            </div>

            <!-- Hat / Accessory Selector -->
            <div class="studio-input-group">
              <label class="studio-label" data-i18n="studio_hat_label">Şapka & Başlık:</label>
              <div class="studio-chips-carousel" id="home-hat-chips">
                <!-- Injected dynamically -->
              </div>
            </div>

            <!-- Color Palette Selector -->
            <div class="studio-input-group">
              <label class="studio-label" data-i18n="studio_color_label">Gövde & Çerçeve Rengi:</label>
              <div class="studio-colors-row" id="home-color-chips">
                <!-- Injected dynamically -->
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Server Status Badge -->
      <div id="server-status-pill" class="server-status-pill">
        <span class="status-dot">●</span> <span id="server-status-text" data-i18n="server_status_checking">Sunucu Durumu: Bağlantı kontrol ediliyor...</span>
      </div>

      <!-- Main Play Action Cards (5 Choices) -->
      <div class="home-actions-grid">
        <div class="action-card-btn primary" id="btn-quick-play">
          <div class="action-icon">⚡</div>
          <div class="action-title" data-i18n="btn_quick_play">Hızlı Oyna</div>
          <div class="action-desc" data-i18n="btn_quick_play_desc">Beklemeden hemen 3 akıllı bot ile İstanbul haritasında partiye başla!</div>
        </div>

        <div class="action-card-btn emerald" id="btn-play-friends">
          <div class="action-icon">🌐</div>
          <div class="action-title" data-i18n="btn_play_friends">Arkadaşlarınla Oyna</div>
          <div class="action-desc" data-i18n="btn_play_friends_desc">Tek tıkla oda kur, davet bağlantısı veya QR kod ile arkadaşlarını çağır!</div>
        </div>
      </div>

      <!-- Secondary 3-Card Menu Row -->
      <div class="home-secondary-grid">
        <div class="action-card-btn" id="btn-play-bots">
          <div class="action-icon">🤖</div>
          <div class="action-title" data-i18n="btn_play_bots">Botlarla Oyna</div>
          <div class="action-desc" data-i18n="btn_play_bots_desc">1 ila 3 bot seç ve antrenman yap!</div>
        </div>

        <div class="action-card-btn" id="btn-how-to-play">
          <div class="action-icon">📖</div>
          <div class="action-title" data-i18n="btn_how_to_play">Nasıl Oynanır</div>
          <div class="action-desc" data-i18n="btn_how_to_play_desc">Oyun kuralları, karolar ve taktikler</div>
        </div>

        <div class="action-card-btn" id="btn-settings">
          <div class="action-icon">⚙️</div>
          <div class="action-title" data-i18n="btn_settings">Ayarlar</div>
          <div class="action-desc" data-i18n="btn_settings_desc">Ses, müzik, dil ve grafik ayarları</div>
        </div>
      </div>

      <!-- Join Room Section -->
      <div class="join-room-card">
        <input type="text" id="input-room-code" class="join-room-input" placeholder="ODA KODU (ÖRN: ABCD)" data-i18n-placeholder="room_code_placeholder" maxlength="8">
        <button class="btn-pill" id="btn-join-room" data-i18n="btn_join_room">Odaya Katıl</button>
      </div>

      <!-- Auxiliary Bar (Wardrobe / Music) -->
      <div class="home-float-bar">
        <button class="btn-icon-round" id="btn-open-wardrobe" title="Tüm Gardırop & Ödüller">
          <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="2" fill="none"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
        </button>
        <button class="btn-icon-round" id="btn-home-music" title="Müzik Aç/Kapat">
          <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="2" fill="none"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="22" x2="16" y1="9" y2="15"/><line x1="16" x2="22" y1="9" y2="15"/></svg>
        </button>
      </div>

    </div>
  </div>

  <!-- ======================================================================
       2. LOBBY SCREEN
       ====================================================================== -->
  <div id="screen-lobby" class="screen hidden">
    <div class="lobby-container">
      
      <div class="lobby-header-card">
        <div style="flex: 1; min-width: 0;">
          <div style="font-size: 13px; font-weight: 800; color: #64748B;">ODA KODU</div>
          <div class="room-code-tag" id="lobby-room-code">----</div>
          <div id="lobby-map-badge" style="font-weight: 800; font-size: 13px; color: #4338CA; margin-top: 2px;">
            🗺️ Harita: İstanbul - Boğazın İncisi
          </div>
          
          <div class="lobby-map-switcher">
            <button class="lobby-map-btn active" data-theme="istanbul">🇹🇷 İstanbul</button>
            <button class="lobby-map-btn" data-theme="tokyo">🇯🇵 Tokyo</button>
            <button class="lobby-map-btn" data-theme="paris">🇫🇷 Paris</button>
            <button class="lobby-map-btn" data-theme="newyork">🇺🇸 New York</button>
          </div>

          <input type="text" id="lobby-share-url" class="lobby-share-url" readonly value="" onclick="this.select()" title="Tıkla ve kopyala">

          <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px;">
            <button class="btn-pill" id="btn-copy-link" style="background: #3B82F6; box-shadow: 0 4px 0 #1D4ED8;">
              📋 Bağlantıyı Kopyala
            </button>
            <button class="btn-pill" id="btn-show-qr" style="background: #6366F1; box-shadow: 0 4px 0 #4F46E5;">
              📱 QR Kodu Göster
            </button>
          </div>
        </div>

        <div class="lobby-qr-box" id="lobby-qr-container">
          <div id="lobby-qr-svg"></div>
          <div style="font-size: 11px; font-weight: 800; color: #64748B; margin-top: 4px; text-align: center;">Telefonunla Tara</div>
        </div>
      </div>

      <h3 style="font-size: 18px; font-weight: 800; color: #1E293B;">Oyuncular (<span id="lobby-player-count">...</span>/4)</h3>
      <div class="lobby-players-grid" id="lobby-players-list">
        <!-- Rendered dynamically -->
      </div>

      <div class="lobby-controls-bar">
        <button class="btn-pill" id="btn-lobby-leave" style="background: #64748B; box-shadow: 0 4px 0 #475569;">
          🚪 Odadan Ayrıl
        </button>
        <button class="btn-pill" id="btn-lobby-add-bot" style="background: #8B5CF6; box-shadow: 0 4px 0 #6D28D9;">
          🤖 Bot Ekle
        </button>
        <button class="btn-pill" id="btn-lobby-start" style="background: #10B981; box-shadow: 0 4px 0 #059669; font-size: 17px; padding: 14px 28px;">
          🚀 Partiyi Başlat!
        </button>
      </div>

    </div>
  </div>

  <!-- ======================================================================
       3. IN-GAME BOARD SCREEN
       ====================================================================== -->
  <div id="screen-game" class="screen game-screen hidden">
    
    <!-- Top HUD Navigation -->
    <header class="game-hud-top">
      <div class="hud-left">
        <!-- Round Progress Tracker Widget -->
        <div class="hud-round-card" id="hud-round-card">
          <div class="hud-round-top">
            <span class="hud-round-title" id="hud-round">Tur 1 / 10</span>
            <span class="hud-round-sub" id="hud-round-remaining">9 Tur Kaldı</span>
          </div>
          <div class="hud-round-bar"><div class="hud-round-fill" id="hud-round-fill" style="width: 10%;"></div></div>
        </div>

        <div id="hud-map-name" class="hud-round-pill" style="background:#E0E7FF; color:#3730A3;">İstanbul</div>
        <div class="hud-active-turn-box">
          <div class="hud-turn-avatar" id="hud-turn-avatar"></div>
          <span id="hud-turn-name">Oyuncu Sırası</span>
        </div>
      </div>

      <div class="hud-right-actions">
        <button class="btn-icon-round" id="btn-hud-qr" title="Arkadaşına QR Göster" style="width:38px;height:38px;">
          <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none"><rect width="5" height="5" x="3" y="3" rx="1"/><rect width="5" height="5" x="16" y="3" rx="1"/><rect width="5" height="5" x="3" y="16" rx="1"/><path d="M21 16h-3a2 2 0 0 0-2 2v3"/><path d="M21 21v.01"/></svg>
        </button>
        <button class="btn-icon-round" id="btn-hud-music" title="Müzik" style="width:38px;height:38px;">
          <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="22" x2="16" y1="9" y2="15"/><line x1="16" x2="22" y1="9" y2="15"/></svg>
        </button>
        <button class="btn-hud-leave" id="btn-hud-leave" title="Oyundan Ayrıl">
          <span>🚪</span> <span>Ayrıl</span>
        </button>
      </div>
    </header>

    <!-- Unmissable High-Visibility Turn Alert Banner (Disabled for clean minimal HUD) -->
    <div id="hud-turn-alert-banner" class="hud-turn-alert-banner" style="display:none;">
      <div class="turn-banner-icon" id="turn-banner-icon">🎲</div>
      <div class="turn-banner-text">
        <div class="turn-banner-title" id="turn-banner-title">Parti Yükleniyor...</div>
        <div class="turn-banner-sub" id="turn-banner-sub">Zar atmak veya eşya kullanmak için sıranı bekle.</div>
      </div>
    </div>

    <!-- Golden Final Round Celebration Banner -->
    <div id="final-round-banner" class="final-round-banner hidden">
      <div class="final-banner-glow">🚨 FİNAL TURU! 🚨</div>
      <div class="final-banner-sub">Bu son tur! Şampiyon bu turun sonunda taç giyecek!</div>
    </div>

    <!-- Prominent Broadcasted Tile Event Card / Modal -->
    <div id="tile-event-overlay" class="tile-event-overlay hidden">
      <div class="tile-event-card" id="tile-event-card">
        <div class="tile-event-avatar" id="tile-event-avatar"></div>
        <div class="tile-event-icon" id="tile-event-icon">💥</div>
        <div class="tile-event-title" id="tile-event-title">TUZAK!</div>
        <div class="tile-event-desc" id="tile-event-desc">Dikenli tuzağa düştün ve 5 altın kaybettin!</div>
      </div>
    </div>

    <!-- Players Scoreboard Bar -->
    <div class="players-hud-carousel" id="players-carousel">
      <!-- Player cards injected here -->
    </div>

    <!-- Interactive Board Map Canvas -->
    <main class="board-arena-container">
      <canvas id="board-canvas"></canvas>

      <!-- Floating Camera Controls -->
      <div class="floating-cam-controls">
        <button class="cam-btn" id="btn-cam-zoom-in" title="Yakınlaştır">+</button>
        <button class="cam-btn" id="btn-cam-zoom-out" title="Uzaklaştır">-</button>
        <button class="cam-btn" id="btn-reset-cam" title="Kamerayı Ortala">⟲</button>
      </div>
    </main>

    <!-- Event Feed Corner Ticker -->
    <div class="hud-event-feed" id="hud-event-feed"></div>

    <!-- Bottom Floating Mobile Dock -->
    <footer class="game-bottom-dock">
      <div class="dock-status-bar" id="dock-status-text" style="display:none;"></div>
      <div class="dock-buttons-row">
        <button class="dock-secondary-btn" id="btn-open-inventory" title="Çantam">
          <span>🎒</span> <span class="dock-btn-label">Çantam</span>
          <span class="btn-badge" id="inventory-badge">0</span>
        </button>

        <button class="dock-secondary-btn" id="btn-open-trade" title="Takas">
          <span>🤝</span> <span class="dock-btn-label">Takas</span>
        </button>

        <button class="btn-roll-dice pulse-turn" id="btn-roll-dice">
          <span>🎲</span> ZAR AT! (SPACE)
        </button>

        <button class="dock-secondary-btn speed-btn" id="btn-toggle-speed" title="Oyun Hızı">
          <span>⚡</span> <span id="speed-label">1x</span>
        </button>

        <button class="dock-secondary-btn" id="btn-open-chat" title="Sohbet">
          <span>🗨️</span>
        </button>

        <button class="dock-secondary-btn" id="btn-open-emotes" title="İfade">
          <span>💬</span>
        </button>
      </div>
    </footer>

  </div>

  <!-- ======================================================================
       MODALS & OVERLAYS
       ====================================================================== -->

  <!-- 3D Tumbling Single Die Roll Animation Modal -->
  <div id="dice-roll-overlay" class="modal-overlay hidden">
    <div class="modal-card dice-roll-modal">
      <div class="dice-roller-title" id="dice-roller-name">🎲 ZAR ATILIYOR</div>
      <div class="dice-single-wrapper">
        <div class="single-dice-box rolling" id="dice-cube-1">
          <div class="dice-pip-face" id="dice-pip-face">
            <span class="pip"></span>
          </div>
        </div>
      </div>
      <div class="dice-result-badge" id="dice-result-value">Zar dönüyor...</div>
    </div>
  </div>

  <!-- Create Room Settings Modal -->
  <div id="modal-create-room" class="modal-overlay hidden">
    <div class="modal-card">
      <div class="modal-header">
        <h3 class="modal-title">Oda & Harita Ayarları</h3>
        <button class="modal-close-btn" onclick="document.getElementById('modal-create-room').classList.add('hidden')">✕</button>
      </div>
      
      <div style="font-size: 13px; font-weight: 800; color: #475569; margin-bottom: 8px;">1. DÜNYA ŞEHRİNİ SEÇ:</div>
      <div class="map-selection-grid four-cities">
        <label class="map-card-label">
          <input type="radio" name="map-theme-select" value="istanbul" checked>
          <div class="map-card-box">
            <div class="map-icon">🇹🇷</div>
            <div class="map-name">İstanbul</div>
            <div class="map-sub">Boğaz & Galata</div>
          </div>
        </label>
        <label class="map-card-label">
          <input type="radio" name="map-theme-select" value="tokyo">
          <div class="map-card-box">
            <div class="map-icon">🇯🇵</div>
            <div class="map-name">Tokyo</div>
            <div class="map-sub">Neon & Skytree</div>
          </div>
        </label>
        <label class="map-card-label">
          <input type="radio" name="map-theme-select" value="paris">
          <div class="map-card-box">
            <div class="map-icon">🇫🇷</div>
            <div class="map-name">Paris</div>
            <div class="map-sub">Eyfel & Sen Nehri</div>
          </div>
        </label>
        <label class="map-card-label">
          <input type="radio" name="map-theme-select" value="newyork">
          <div class="map-card-box">
            <div class="map-icon">🇺🇸</div>
            <div class="map-name">New York</div>
            <div class="map-sub">Empire & Özgürlük</div>
          </div>
        </label>
      </div>

      <div style="font-size: 13px; font-weight: 800; color: #475569; margin-bottom: 8px;">2. TUR SAYISI:</div>
      <div style="display: flex; flex-direction: column; gap: 8px; margin-bottom: 20px;">
        <label style="display:flex; align-items:center; gap: 10px; font-weight:700; cursor:pointer;">
          <input type="radio" name="round-select" value="5">
          <span>⚡ Hızlı Parti (5 Tur • ~5 Dakika)</span>
        </label>
        <label style="display:flex; align-items:center; gap: 10px; font-weight:700; cursor:pointer;">
          <input type="radio" name="round-select" value="10" checked>
          <span>🏆 Standart Parti (10 Tur • ~10-12 Dakika)</span>
        </label>
        <label style="display:flex; align-items:center; gap: 10px; font-weight:700; cursor:pointer;">
          <input type="radio" name="round-select" value="15">
          <span>🔥 Destansı Parti (15 Tur • ~18 Dakika)</span>
        </label>
      </div>

      <button class="btn-pill" id="btn-confirm-create" style="width: 100%;">🏰 Odayı Kur & Lobiye Geç</button>
    </div>
  </div>

  <!-- Interactive Tile Inspector Modal -->
  <div id="modal-tile-inspector" class="modal-overlay hidden">
    <div class="modal-card tile-inspector-card">
      <h3 class="ti-title" id="ti-tile-title">Karo Detayı</h3>
      <p class="ti-desc" id="ti-tile-desc">Açıklama</p>
      <div class="ti-steps-badge" id="ti-tile-steps">0 adım mesafede</div>
      
      <div style="width: 100%; text-align: left; margin-top: 10px;">
        <div style="font-size: 12px; font-weight: 800; color: #64748B;">BU KARODAKİ OYUNCULAR:</div>
        <div class="ti-players-list" id="ti-players-here"></div>
      </div>

      <button class="btn-pill" id="btn-close-tile-inspector" style="width: 100%; margin-top: 10px;">Anladım</button>
    </div>
  </div>

  <!-- Trade Propose Modal -->
  <div id="modal-trade" class="modal-overlay hidden">
    <div class="modal-card">
      <div class="modal-header">
        <h3 class="modal-title">🤝 Oyuncular Arası Takas</h3>
        <button class="modal-close-btn" id="btn-close-trade">✕</button>
      </div>
      <p style="font-size: 13px; color: #64748B;">Bir rakip seç ve takas teklifini hazırla:</p>

      <div style="margin: 12px 0;">
        <label style="font-size: 12px; font-weight: 800; color: #475569;">Hedef Oyuncu:</label>
        <select id="trade-target-player" class="trade-select" style="width: 100%; margin-top: 4px;"></select>
      </div>

      <div class="trade-form-grid">
        <!-- My Offer -->
        <div class="trade-col">
          <div class="trade-col-title">Senin Teklifin</div>
          <div class="trade-input-row">
            <label>Altın:</label>
            <input type="number" id="trade-offer-coins" class="trade-number-input" min="0" value="0">
          </div>
          <div class="trade-input-row">
            <label>Eşya:</label>
            <select id="trade-offer-item" class="trade-select"></select>
          </div>
        </div>

        <!-- My Request -->
        <div class="trade-col">
          <div class="trade-col-title">Ondan İstediğin</div>
          <div class="trade-input-row">
            <label>Altın:</label>
            <input type="number" id="trade-request-coins" class="trade-number-input" min="0" value="0">
          </div>
          <div class="trade-input-row">
            <label>Eşya:</label>
            <select id="trade-request-item" class="trade-select"></select>
          </div>
        </div>
      </div>

      <button class="btn-pill" id="btn-send-trade-offer" style="width: 100%; margin-top: 18px;">
        Teklifi Gönder
      </button>
    </div>
  </div>

  <!-- Incoming Trade Offer Modal -->
  <div id="modal-incoming-trade" class="modal-overlay hidden">
    <div class="modal-card incoming-trade-card">
      <h3 style="font-size: 22px; font-weight: 900; color: #1E293B;">🤝 Gelen Takas Teklifi!</h3>
      <p><strong id="inc-sender-name">Oyuncu</strong> seninle bir takas yapmak istiyor:</p>

      <div class="inc-trade-boxes">
        <div class="inc-box">
          <div class="inc-box-label">Sana Teklifi</div>
          <div class="inc-box-val" id="inc-offer-details">-</div>
        </div>
        <div style="font-size: 20px;">⇄</div>
        <div class="inc-box">
          <div class="inc-box-label">Senden İstediği</div>
          <div class="inc-box-val" id="inc-request-details">-</div>
        </div>
      </div>

      <div style="display: flex; gap: 12px; margin-top: 10px;">
        <button class="btn-pill" id="btn-decline-trade" style="flex:1; background: #EF4444; box-shadow: 0 4px 0 #B91C1C;">
          Reddet
        </button>
        <button class="btn-pill" id="btn-accept-trade" style="flex:1; background: #10B981; box-shadow: 0 4px 0 #059669;">
          Kabul Et
        </button>
      </div>
    </div>
  </div>

  <!-- Quick Tactical Chat Modal -->
  <div id="modal-quick-chat" class="modal-overlay hidden">
    <div class="modal-card" style="max-width: 400px;">
      <div class="modal-header">
        <h3 class="modal-title">🗨️ Hızlı Sohbet & Taktik</h3>
        <button class="modal-close-btn" id="btn-close-quick-chat">✕</button>
      </div>
      <div class="chat-presets-list" id="quick-chat-options"></div>
    </div>
  </div>

  <!-- Wardrobe Customization Modal -->
  <div id="modal-wardrobe" class="modal-overlay hidden">
    <div class="modal-card">
      <div class="modal-header">
        <h3 class="modal-title">Gardırop & Seviye Ödülleri</h3>
        <button class="modal-close-btn" onclick="document.getElementById('modal-wardrobe').classList.add('hidden')">✕</button>
      </div>

      <!-- Player Name Input -->
      <div class="wardrobe-tabs-section">
        <div class="wardrobe-section-label">Oyuncu Adın</div>
        <input type="text" id="wardrobe-name-input" class="join-room-input" style="width: 100%; text-align: left;" maxlength="14">
      </div>

      <!-- Titles Dropdown -->
      <div class="wardrobe-tabs-section">
        <div class="wardrobe-section-label">Unvanın</div>
        <select id="wardrobe-titles" style="width:100%; padding:10px; border-radius:10px; border:2px solid #CBD5E1; font-weight:700;"></select>
      </div>

      <!-- Avatars -->
      <div class="wardrobe-tabs-section">
        <div class="wardrobe-section-label">Açılan Karakterler</div>
        <div class="wardrobe-grid" id="wardrobe-avatars"></div>
      </div>

      <!-- Dice Skins -->
      <div class="wardrobe-tabs-section">
        <div class="wardrobe-section-label">Açılan Zar Temaları</div>
        <div class="wardrobe-grid" id="wardrobe-dice"></div>
      </div>

      <button class="btn-pill" id="btn-save-wardrobe" style="width: 100%;">Kaydet & Kuşan</button>
    </div>
  </div>

  <!-- Shop Modal -->
  <div id="modal-shop" class="modal-overlay hidden">
    <div class="modal-card">
      <div class="modal-header">
        <h3 class="modal-title">🛍️ Parti Eşya Dükkanı</h3>
        <button class="modal-close-btn" id="btn-close-shop">✕</button>
      </div>
      <div class="shop-items-grid" id="shop-items-grid"></div>
    </div>
  </div>

  <!-- Inventory Modal -->
  <div id="modal-inventory" class="modal-overlay hidden">
    <div class="modal-card">
      <div class="modal-header">
        <h3 class="modal-title">🎒 Çantan & Eşyaların</h3>
        <button class="modal-close-btn" id="btn-close-inventory">✕</button>
      </div>
      <div class="inventory-items-grid" id="inventory-items-grid"></div>
    </div>
  </div>

  <!-- Lucky Die Picker Modal -->
  <div id="modal-lucky-die" class="modal-overlay hidden">
    <div class="modal-card" style="max-width: 360px; text-align: center;">
      <div class="modal-header">
        <h3 class="modal-title">🎯 Şanslı Zarını Seç</h3>
        <button class="modal-close-btn" id="btn-close-lucky-die">✕</button>
      </div>
      <p style="font-size: 13px; color: #64748B; margin-bottom: 16px;">Sıradaki zar atışında gelmesini istediğin kesin sayıyı belirle:</p>
      <div class="lucky-die-grid" id="lucky-die-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 8px;">
        <!-- 1 to 6 injected dynamically -->
      </div>
    </div>
  </div>

  <!-- Swap Wand Target Picker Modal -->
  <div id="modal-swap-wand" class="modal-overlay hidden">
    <div class="modal-card" style="max-width: 380px;">
      <div class="modal-header">
        <h3 class="modal-title">🪄 Takas Asası - Hedef Seç</h3>
        <button class="modal-close-btn" id="btn-close-swap-wand">✕</button>
      </div>
      <p style="font-size: 13px; color: #64748B; margin-bottom: 14px;">Konumunu anında takas etmek istediğin rakip oyuncuyu seç:</p>
      <div class="swap-wand-list" id="swap-wand-list" style="display: flex; flex-direction: column; gap: 8px;">
        <!-- Rival player cards injected dynamically -->
      </div>
    </div>
  </div>

  <!-- Mystery Roulette Modal -->
  <div id="modal-mystery" class="modal-overlay hidden">
    <div class="modal-card mystery-roulette-container">
      <h3 style="font-weight: 900; font-size: 20px;" data-i18n="roulette_title">🎡 Şans Çarkı!</h3>
      <p id="mystery-player-text" style="color:#64748B; font-size:13px;">...</p>
      <div class="roulette-wheel-wrapper">
        <div class="roulette-pointer-holder" id="roulette-pointer">
          <svg width="28" height="36" viewBox="0 0 28 36" fill="none" class="roulette-pointer-svg">
            <defs>
              <filter id="pointer-shadow" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="2" stdDeviation="2" flood-color="#000000" flood-opacity="0.35"/>
              </filter>
            </defs>
            <g filter="url(#pointer-shadow)">
              <circle cx="14" cy="9" r="7" fill="#F59E0B" stroke="#B45309" stroke-width="2"/>
              <circle cx="14" cy="9" r="3.5" fill="#FEF3C7"/>
              <path d="M7 11 L21 11 L14 32 Z" fill="#DC2626" stroke="#991B1B" stroke-width="1.5" stroke-linejoin="round"/>
              <path d="M12 12 L14 28 L14 12 Z" fill="#FCA5A5" opacity="0.6"/>
            </g>
          </svg>
        </div>
        <canvas id="roulette-canvas" width="260" height="260" class="roulette-canvas-disc"></canvas>
        <div class="roulette-center-stud">🎲</div>
      </div>
      <div class="mystery-result-box" id="mystery-event-result" data-i18n="roulette_spinning">Çark dönüyor...</div>
    </div>
  </div>

  <!-- Emotes Modal -->
  <div id="modal-emotes" class="modal-overlay hidden">
    <div class="modal-card" style="max-width:380px;">
      <div class="modal-header">
        <h3 class="modal-title">💬 İfade Gönder</h3>
        <button class="modal-close-btn" id="btn-close-emotes">✕</button>
      </div>
      <div class="emotes-grid" id="emotes-grid"></div>
    </div>
  </div>

  <!-- Scannable LAN QR Modal -->
  <div id="modal-qr" class="modal-overlay hidden">
    <div class="modal-card text-center" style="max-width:360px; text-align:center;">
      <div class="modal-header">
        <h3 class="modal-title">📱 Mobilden Katıl</h3>
        <button class="modal-close-btn" id="btn-close-qr">✕</button>
      </div>
      <p style="font-size: 13px; color: #64748B; margin-bottom: 12px;">Aynı Wi-Fi ağındaki telefonun kamerasını buraya tut:</p>
      <div style="width:200px; height:200px; margin: 0 auto; background:#F8FAFC; padding:8px; border-radius:14px; border:2px dashed #CBD5E1;">
        <img id="lan-qr-image" src="" alt="LAN QR" style="width:100%; height:100%; object-fit:contain;">
      </div>
      <div id="lan-qr-link-text" style="font-size:11px; color:#94A3B8; word-break:break-all; margin: 12px 0;"></div>
      <button class="btn-pill" id="btn-copy-lan-link" style="width:100%;">Bağlantıyı Kopyala</button>
    </div>
  </div>

  <!-- Mini-Game Fullscreen Overlay -->
  <div id="minigame-overlay" class="modal-overlay hidden">
    <!-- Active mini-game renders here dynamically -->
  </div>

  <!-- Game Over Victory Podium Modal -->
  <div id="modal-gameover" class="modal-overlay hidden">
    <div class="modal-card text-center" style="max-width: 500px; text-align:center;">
      <h2 style="font-size: 26px; font-weight: 900; color: #1E293B;">🎉 PARTİ ŞAMPİYONU!</h2>
      <div id="go-level-up" class="hidden" style="background:#FEF9C3; color:#854D0E; font-weight:800; padding:10px; border-radius:10px; margin:10px 0;"></div>
      <div class="go-xp-section" id="go-xp-section" style="margin: 8px 0 16px 0;">
        <div id="go-xp-reward" style="font-weight:900; color:#2563EB; font-size:16px;"></div>
        <div class="go-xp-bar-wrap" style="width:100%; height:12px; background:#E2E8F0; border-radius:6px; overflow:hidden; margin:8px 0; border: 1px solid #CBD5E1;">
          <div class="go-xp-bar-fill" id="go-xp-bar-fill" style="width:0%; height:100%; background:linear-gradient(90deg, #3B82F6, #10B981); transition:width 1.2s cubic-bezier(0.34, 1.56, 0.64, 1);"></div>
        </div>
        <div id="go-xp-detail" style="font-size:12px; font-weight:800; color:#64748B;"></div>
      </div>

      <div class="podium-list" id="go-podium-list">
        <!-- Ranks injected dynamically -->
      </div>

      <button class="btn-pill" id="btn-back-home" style="width: 100%; margin-top: 20px; padding: 14px;">
        Ana Menüye Dön
      </button>
    </div>
  </div>

  <!-- How to Play Rules Modal -->
  <div id="modal-how-to-play" class="modal-overlay hidden">
    <div class="modal-card" style="max-width: 540px;">
      <div class="modal-header">
        <h3 class="modal-title">📖 Nasıl Oynanır?</h3>
        <button class="modal-close-btn" id="btn-close-how-to-play">✕</button>
      </div>

      <div class="rules-container">
        <div class="rules-card">
          <div class="rules-card-title">🎯 Oyunun Amacı</div>
          <div class="rules-card-body">
            Belirlenen tur sayısı bitmeden önce en çok <strong>Yıldız (⭐)</strong> ve <strong>Altın (🪙)</strong> toplayan oyuncu partinin şampiyonu olur! 1 Yıldız, 20 altın değerindedir ve liderlikte en büyük önceliğe sahiptir.
          </div>
        </div>

        <div class="rules-card">
          <div class="rules-card-title">🎲 Sıra ve Hareket</div>
          <div class="rules-card-body">
            Sıra sana geldiğinde <strong>Zar At</strong> butonuna bas veya klavyeden <strong>SPACE</strong> tuşunu kullan. Zardaki sayı kadar saat yönünde ilerlersin. Başlangıç karosundan her geçişte <strong>+10 Altın</strong> ödülü kazanırsın!
          </div>
        </div>

        <div class="rules-card">
          <div class="rules-card-title">🗺️ Özel Karolar ve Etkileri</div>
          <div class="rules-card-body">
            • <strong>⭐ Yıldız Kaidesi:</strong> 20 altının varsa 1 Yıldız satın alırsın. Yıldız alındığında kaide haritada başka bir şehre/bölgeye ışınlanır!<br>
            • <strong>🪙 Altın Karosu:</strong> Üzerine bastığında sana +4 ile +8 altın kazandırır.<br>
            • <strong>🔥 Tuzaklar:</strong> Dikkat! Altın düşürürsün veya kodes cezası alırsın.<br>
            • <strong>🏦 Merkez Bankası:</strong> Havuzda biriken tüm altınları ilk basan oyuncu tek seferde silip süpürür!<br>
            • <strong>⚔️ Düello:</strong> Lider veya rakip oyuncularla altın mücadelesi.<br>
            • <strong>🛍️ Eşya Dükkanı:</strong> Çantana güçlü taktik eşyaları satın alabileceğin pazar yeri!
          </div>
        </div>

        <div class="rules-card">
          <div class="rules-card-title">🎒 Taktik Eşyaları</div>
          <div class="rules-card-body">
            • <strong>🎲🎲 Çift Zar (7🪙):</strong> Bir sonraki turda 2 zar birden atarsın (2-12 adım).<br>
            • <strong>🚀 Süper Roket (12🪙):</strong> Hedefine doğru direkt 7 adım uçar!<br>
            • <strong>🛡️ Manyetik Kalkan (8🪙):</strong> Tuzaklara ve altın çalma hamlelerine karşı 2 tur korur.<br>
            • <strong>🧲 Altın Mıknatısı (10🪙):</strong> Bütün rakiplerden 4'er altın çeker!<br>
            • <strong>🍌 Muz Kabuğu (5🪙):</strong> Bulunduğun karoya tuzak kur; basan 3 adım geri kayar!<br>
            • <strong>🪄 Takas Asası (15🪙):</strong> İstediğin bir rakiple haritadaki yerlerini takas et!
          </div>
        </div>

        <div class="rules-card">
          <div class="rules-card-title">🎮 Mini Oyunlar</div>
          <div class="rules-card-body">
            Özel anlarda başlayan refleks ve beceri mini oyunlarında (Altın Yağmuru, Zıplayan Balon, Hızlı Çekiç, Hafıza Kartları, Bomba Paslaşma) en yüksek skoru yaparak ekstra altınları kap!
          </div>
        </div>
      </div>

      <button class="btn-pill" id="btn-ok-how-to-play" style="width: 100%; margin-top: 6px;">Harika, Anladım!</button>
    </div>
  </div>

  <!-- Settings Modal -->
  <div id="modal-settings" class="modal-overlay hidden">
    <div class="modal-card" style="max-width: 440px;">
      <div class="modal-header">
        <h3 class="modal-title" data-i18n="settings_title">⚙️ Oyun Ayarları</h3>
        <button class="modal-close-btn" id="btn-close-settings">✕</button>
      </div>

      <div class="settings-list">
        <!-- Language Option -->
        <div class="settings-item">
          <div class="settings-item-label">
            <span class="settings-item-title" data-i18n="settings_lang_title">🌐 Dil / Language</span>
            <span class="settings-item-sub" data-i18n="settings_lang_sub">Arayüz ve oyun metinleri dili</span>
          </div>
          <div class="settings-lang-toggle">
            <button type="button" class="lang-pill-btn active" data-lang="tr">🇹🇷 TR</button>
            <button type="button" class="lang-pill-btn" data-lang="en">🇬🇧 EN</button>
            <button type="button" class="lang-pill-btn" data-lang="de">🇩🇪 DE</button>
            <button type="button" class="lang-pill-btn" data-lang="es">🇪🇸 ES</button>
            <button type="button" class="lang-pill-btn" data-lang="fr">🇫🇷 FR</button>
          </div>
        </div>

        <div class="settings-item">
          <div class="settings-item-label">
            <span class="settings-item-title" data-i18n="settings_sfx_title">🔊 Ses Efektleri</span>
            <span class="settings-item-sub" data-i18n="settings_sfx_sub">Zar, adım, buton ve olay sesleri</span>
          </div>
          <label class="switch-toggle">
            <input type="checkbox" id="setting-sfx" checked>
            <span class="slider-round"></span>
          </label>
        </div>

        <div class="settings-item">
          <div class="settings-item-label">
            <span class="settings-item-title" data-i18n="settings_music_title">🎵 Arka Plan Müziği</span>
            <span class="settings-item-sub" data-i18n="settings_music_sub">Web Audio sentezleyici parti müziği</span>
          </div>
          <label class="switch-toggle">
            <input type="checkbox" id="setting-music">
            <span class="slider-round"></span>
          </label>
        </div>

        <div class="settings-item">
          <div class="settings-item-label">
            <span class="settings-item-title" data-i18n="settings_dice_title">🎲 3D Zar Animasyonları</span>
            <span class="settings-item-sub" data-i18n="settings_dice_sub">Kapatılırsa zar sonucu beklemeden gelir</span>
          </div>
          <label class="switch-toggle">
            <input type="checkbox" id="setting-dice3d" checked>
            <span class="slider-round"></span>
          </label>
        </div>

        <div class="settings-item">
          <div class="settings-item-label">
            <span class="settings-item-title" data-i18n="settings_lowpower_title">⚡ Düşük Güç / Pil Tasarrufu</span>
            <span class="settings-item-sub" data-i18n="settings_lowpower_sub">Eski telefonlar için hafif grafik modu</span>
          </div>
          <label class="switch-toggle">
            <input type="checkbox" id="setting-lowpower">
            <span class="slider-round"></span>
          </label>
        </div>
      </div>

      <div style="border-top: 1px dashed #E2E8F0; padding-top: 14px; display: flex; flex-direction: column; gap: 8px;">
        <button class="btn-pill" id="btn-reset-profile" data-i18n="btn_reset_profile" style="background: #FEE2E2; color: #DC2626; box-shadow: 0 4px 0 #FCA5A5; font-size: 13px;">
          🔄 Oyuncu Profilini & Verilerini Sıfırla
        </button>
        <button class="btn-pill" id="btn-save-settings" data-i18n="btn_save_settings" style="width: 100%;">
          Ayarları Kaydet
        </button>
          Ayarları Kaydet
        </button>
      </div>
    </div>
  </div>

  <!-- Confirm Leave Game Modal -->
  <div id="modal-confirm-leave" class="modal-overlay hidden">
    <div class="modal-card" style="max-width: 400px; text-align: center;">
      <div style="font-size: 48px; margin-bottom: 8px;">🚪</div>
      <h3 class="modal-title" style="margin-bottom: 8px;" data-i18n="leave_modal_title">Oyundan Ayrıl</h3>
      <p style="color: #64748B; font-size: 13px; line-height: 1.5; margin-bottom: 20px;" data-i18n="leave_modal_desc">
        Mevcut oyundan ayrılmak ve ana menüye dönmek istediğinize emin misiniz? Çok oyunculu odada yerinizi bir bot devralacaktır.
      </p>
      <div style="display: flex; gap: 10px; justify-content: center;">
        <button class="btn-pill" id="btn-cancel-leave" data-i18n="btn_leave_cancel" style="background: #E2E8F0; color: #475569; box-shadow: 0 4px 0 #CBD5E1;">
          İptal / Oyuna Dön
        </button>
        <button class="btn-pill" id="btn-confirm-leave" data-i18n="btn_leave_confirm" style="background: #EF4444; color: white; box-shadow: 0 4px 0 #DC2626;">
          Evet, Ayrıl
        </button>
      </div>
    </div>
  </div>

  <!-- Floating Confetti Container -->
  <div id="confetti-container"></div>

  <!-- Toast Notification Container -->
  <div class="toast-container" id="toast-container"></div>

  <!-- Scripts -->
  <script>
/* =================== 1. ICONS =================== */
// Crisp vector Lucide-style SVG icon registry
const LucideIcons = {
  dices: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <rect width="12" height="12" x="2" y="10" rx="2" ry="2"/>
    <path d="m17.92 14 3.5-3.5a2.24 2.24 0 0 0 0-3.16l-4.76-4.76a2.24 2.24 0 0 0-3.16 0L10 6.08"/>
    <path d="M6 14h.01"/><path d="M10 18h.01"/>
    <path d="M14 6h.01"/><path d="M18 10h.01"/>
  </svg>`,
  
  star: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="currentColor" stroke-linecap="round" stroke-linejoin="round">
    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
  </svg>`,

  coins: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="8" cy="8" r="6"/>
    <path d="M18.09 10.37A6 6 0 1 1 10.34 18"/>
    <path d="M7 6h1v4H7"/>
    <path d="m16.71 13.88.7.71-2.82 2.82"/>
  </svg>`,

  trophy: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/>
    <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/>
    <path d="M4 22h16"/>
    <path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/>
    <path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/>
    <path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>
  </svg>`,

  rocket: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/>
    <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/>
    <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/>
    <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>
  </svg>`,

  shield: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>
  </svg>`,

  magnet: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="m6 15-4-4 6.75-6.77a7.78 7.78 0 0 1 11 11L13 22l-4-4 6.39-6.36a2.14 2.14 0 0 0-3-3.04L6 15z"/>
    <path d="m5 8 4 4"/>
    <path d="m12 15 4 4"/>
  </svg>`,

  banana: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="M4 13c3.5-2 8-2 10 2 1.5 3 2.5 5 6 6-1.5-6-4.5-12-10-15-3-1.6-6-1-8 2-.6.9-1 2.3-1 4 0 1.2.5 2.1 3 1"/>
  </svg>`,

  "refresh-cw": `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/>
    <path d="M21 3v5h-5"/>
    <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/>
    <path d="M8 16H3v5"/>
  </svg>`,

  sparkles: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/>
    <path d="M5 3v4"/>
    <path d="M19 17v4"/>
    <path d="M3 5h4"/>
    <path d="M17 19h4"/>
  </svg>`,

  flag: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/>
    <line x1="4" x2="4" y1="22" y2="15"/>
  </svg>`,

  flame: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>
  </svg>`,

  "shopping-bag": `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/>
    <path d="M3 6h18"/>
    <path d="M16 10a4 4 0 0 1-8 0"/>
  </svg>`,

  swords: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5"/>
    <line x1="13" x2="19" y1="19" y2="13"/>
    <line x1="16" x2="20" y1="16" y2="20"/>
    <line x1="19" x2="21" y1="21" y2="19"/>
    <polyline points="14.5 6.5 18 3 21 3 21 6 17.5 9.5"/>
    <line x1="5" x2="11" y1="14" y2="20"/>
  </svg>`,

  zap: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
  </svg>`,

  "undo-2": `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="M9 14 4 9l5-5"/>
    <path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5v0a5.5 5.5 0 0 1-5.5 5.5H11"/>
  </svg>`,

  users: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
    <circle cx="9" cy="7" r="4"/>
    <path d="M22 21v-2a4 4 0 0 0-3-3.87"/>
    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
  </svg>`,

  bot: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <rect width="18" height="12" x="3" y="6" rx="2"/>
    <path d="M9 13v.01"/><path d="M15 13v.01"/>
    <path d="M12 6V2"/><circle cx="12" cy="2" r="1"/>
    <path d="M2 12h1"/><path d="M21 12h1"/>
  </svg>`,

  qr: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <rect width="5" height="5" x="3" y="3" rx="1"/>
    <rect width="5" height="5" x="16" y="3" rx="1"/>
    <rect width="5" height="5" x="3" y="16" rx="1"/>
    <path d="M21 16h-3a2 2 0 0 0-2 2v3"/>
    <path d="M21 21v.01"/>
    <path d="M12 7v3a2 2 0 0 1-2 2H7"/>
    <path d="M3 12h.01"/><path d="M12 3h.01"/><path d="M12 16v.01"/><path d="M16 12h1"/><path d="M21 12v.01"/><path d="M12 21v-1"/>
  </svg>`,

  volume2: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
    <path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>
    <path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>
  </svg>`,

  volumeX: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
    <line x1="22" x2="16" y1="9" y2="15"/>
    <line x1="16" x2="22" y1="9" y2="15"/>
  </svg>`,

  check: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>`,

  copy: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <rect width="14" height="14" x="8" y="8" rx="2" ry="2"/>
    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>
  </svg>`,

  award: `<svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="12" cy="8" r="6"/>
    <path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>
  </svg>`
};

function getIcon(name, fallback = '') {
  return LucideIcons[name] || fallback;
}


/* =================== 1.5. I18N (MULTI-LANGUAGE) =================== */
// ============================================================================
// PartyCraft: Wonder Board - Internationalization (i18n) Engine
// Supports: Turkish (tr), English (en), German (de), Spanish (es), French (fr)
// Dynamic live switching without page reload & automatic localStorage persistence
// ============================================================================

const I18N_DATA = {
  tr: {
    hero_badge: '🎲 Çok Oyunculu Dünya Turu Masa Oyunu',
    hero_title: 'Parti <span>Dünyası</span>',
    hero_subtitle: 'İstanbul, Tokyo, Paris ve New York sokaklarında zar at, yarış ve eğlen!',
    studio_badge: '✨ KARAKTERİNİ TASARLA',
    studio_name_label: 'Karakter Adın:',
    studio_name_placeholder: 'Adını yaz...',
    studio_model_label: 'Karakter Modeli:',
    studio_hat_label: 'Şapka & Başlık:',
    studio_color_label: 'Gövde & Çerçeve Rengi:',
    btn_quick_play: 'Hızlı Oyna',
    btn_quick_play_desc: 'Beklemeden hemen 3 akıllı bot ile İstanbul haritasında partiye başla!',
    btn_play_friends: 'Arkadaşlarınla Oyna',
    btn_play_friends_desc: 'Tek tıkla oda kur, davet bağlantısı veya QR kod ile arkadaşlarını çağır!',
    btn_play_bots: 'Botlarla Oyna',
    btn_play_bots_desc: '1 ila 3 bot seç ve antrenman yap!',
    btn_how_to_play: 'Nasıl Oynanır',
    btn_how_to_play_desc: 'Oyun kuralları, karolar ve taktikler',
    btn_settings: 'Ayarlar',
    btn_settings_desc: 'Ses, müzik, dil ve grafik ayarları',
    room_code_placeholder: 'ODA KODU (ÖRN: ABCD)',
    btn_join_room: 'Odaya Katıl',
    server_status_checking: 'Sunucu Durumu: Bağlantı kontrol ediliyor...',
    server_status_php: 'Sunucu Durumu: PHP & Çok Oyunculu Çevrimiçi Hazır',
    server_status_node: 'Sunucu Durumu: Node.js WebSocket Çevrimiçi Hazır',
    server_status_offline: 'Sunucu Durumu: Çevrimdışı Mod (Botlar & Yerel Oyun Hazır)',

    // Lobby
    lobby_room_title: 'Oda Kodu:',
    lobby_players_title: 'Oyuncular',
    lobby_share_title: 'Arkadaşını Çağır (Davet Bağlantısı):',
    btn_copy_link: '📋 Kopyala',
    btn_copied: '✅ Kopyalandı!',
    btn_show_qr: '📱 QR Kodu Göster',
    btn_add_bot: '🤖 Bot Ekle',
    btn_leave_room: '🚪 Odadan Ayrıl',
    lobby_city_title: 'Oyun Şehri / Haritası:',
    lobby_rounds_title: 'Tur Sayısı:',
    btn_start_game: '🎉 Partiyi Başlat!',
    lobby_waiting_host: 'Oda sahibinin oyunu başlatması bekleniyor...',

    // HUD & In-game
    hud_your_turn: 'Sıra Sende! Zarı at ve ilerle',
    hud_turn_prefix: 'Sıra: ',
    hud_turn_waiting: 'Oyuncu Sırası',
    hud_round_prefix: 'Tur: ',
    btn_roll_dice: '🎲 ZAR AT',
    btn_bag: '🎒 Çantam',
    btn_trade: '🤝 Takas',
    btn_chat: '💬 Sohbet',
    btn_hud_leave: 'Odadan Ayrıl',

    // Modals
    roulette_title: '🎡 Şans Çarkı!',
    roulette_spinning: 'Çark dönüyor...',
    roulette_player_at: 'Şans Karosunda!',
    roulette_won: 'Tebrikler, Büyük Ödül Kazandın!',

    leave_modal_title: 'Oyundan Ayrıl',
    leave_modal_desc: 'Mevcut oyundan ayrılmak ve ana menüye dönmek istediğinize emin misiniz? Çok oyunculu odada yerinizi bir bot devralacaktır.',
    btn_leave_confirm: '🚪 Evet, Odadan Ayrıl',
    btn_leave_cancel: 'İptal / Oyuna Dön',

    settings_title: '⚙️ Oyun Ayarları',
    settings_lang_title: '🌐 Dil / Language',
    settings_lang_sub: 'Arayüz ve oyun metinleri dili',
    settings_sfx_title: '🔊 Ses Efektleri',
    settings_sfx_sub: 'Zar, adım, altın ve zafer sesleri',
    settings_music_title: '🎵 Arka Plan Müziği',
    settings_music_sub: 'Web Audio sentezleyici parti müziği',
    settings_dice_title: '🎲 3D Zar Animasyonları',
    settings_dice_sub: 'Kapatılırsa zar sonucu beklemeden gelir',
    settings_lowpower_title: '⚡ Düşük Güç / Pil Tasarrufu',
    settings_lowpower_sub: 'Eski cihazlar için hafif grafik modu',
    btn_reset_profile: '🔄 Oyuncu Profilini & Verilerini Sıfırla',
    btn_save_settings: 'Ayarları Kaydet',

    rules_title: '📖 Parti Dünyası — Nasıl Oynanır?',
    rules_goal_title: '🎯 Oyunun Amacı',
    rules_goal_body: 'Belirlenen tur sayısı bitmeden önce en çok <strong>Yıldız (⭐)</strong> ve <strong>Altın (🪙)</strong> toplayan oyuncu partinin şampiyonu olur! 1 Yıldız, 20 altın değerindedir ve liderlikte en büyük önceliğe sahiptir.',
    rules_turn_title: '🎲 Sıra ve Hareket',
    rules_turn_body: 'Sıra sana geldiğinde <strong>Zar At</strong> butonuna bas veya klavyeden <strong>SPACE</strong> tuşunu kullan. Zardaki sayı kadar saat yönünde ilerlersin. Başlangıç karosundan her geçişte <strong>+10 Altın</strong> ödülü kazanırsın!',
    rules_tiles_title: '🗺️ Özel Karolar ve Etkileri',
    rules_items_title: '🎒 Taktik Eşyaları',
    rules_close_btn: 'Harika, Oyuna Dön!',

    // Tiles
    tile_start: 'Başlangıç (+10 🪙)',
    tile_coin: 'Altın Karosu',
    tile_star: 'Yıldız Kaidesi',
    tile_mystery: 'Şans Çarkı',
    tile_trap: 'Tuzak Karosu',
    tile_shop: 'Eşya Dükkanı',
    tile_bank: 'Merkez Bankası',
    tile_jail: 'Karakol / Kodes',
    tile_duel: 'Düello Alanı',

    // Titles
    title_novice: 'Acemi Gezgin',
    title_dice: 'Zar Cambazı',
    title_star: 'Yıldız Avcısı',
    title_board: 'Karelerin Efendisi',
    title_party: 'Parti Efsanesi'
  },

  en: {
    hero_badge: '🎲 Multiplayer World Tour Board Game',
    hero_title: 'Party<span>Craft</span>',
    hero_subtitle: 'Roll dice, race, and celebrate across the iconic streets of Istanbul, Tokyo, Paris & New York!',
    studio_badge: '✨ DESIGN YOUR CHARACTER',
    studio_name_label: 'Character Name:',
    studio_name_placeholder: 'Enter your name...',
    studio_model_label: 'Character Model:',
    studio_hat_label: 'Hat & Headwear:',
    studio_color_label: 'Body & Ring Color:',
    btn_quick_play: 'Quick Play',
    btn_quick_play_desc: 'Instantly jump into Istanbul with 3 smart AI bots, zero waiting!',
    btn_play_friends: 'Play with Friends',
    btn_play_friends_desc: 'Host a room in 1 click, invite friends via direct link or QR code!',
    btn_play_bots: 'Play with Bots',
    btn_play_bots_desc: 'Choose 1 to 3 bots and practice offline!',
    btn_how_to_play: 'How to Play',
    btn_how_to_play_desc: 'Board rules, special tiles and pro tips',
    btn_settings: 'Settings',
    btn_settings_desc: 'Audio, music, language and graphics',
    room_code_placeholder: 'ROOM CODE (E.G. ABCD)',
    btn_join_room: 'Join Room',
    server_status_checking: 'Server Status: Checking connection...',
    server_status_php: 'Server Status: PHP Multiplayer Online Ready',
    server_status_node: 'Server Status: Node.js WebSocket Online Ready',
    server_status_offline: 'Server Status: Offline Mode (Local & Bots Ready)',

    // Lobby
    lobby_room_title: 'Room Code:',
    lobby_players_title: 'Players',
    lobby_share_title: 'Invite Friends (Direct Link):',
    btn_copy_link: '📋 Copy Link',
    btn_copied: '✅ Copied!',
    btn_show_qr: '📱 Show QR Code',
    btn_add_bot: '🤖 Add Bot',
    btn_leave_room: '🚪 Leave Room',
    lobby_city_title: 'City / Map Theme:',
    lobby_rounds_title: 'Rounds Count:',
    btn_start_game: '🎉 Start Party!',
    lobby_waiting_host: 'Waiting for room host to start...',

    // HUD & In-game
    hud_your_turn: 'Your Turn! Roll the dice & advance',
    hud_turn_prefix: 'Turn: ',
    hud_turn_waiting: 'Player Turn',
    hud_round_prefix: 'Round: ',
    btn_roll_dice: '🎲 ROLL DICE',
    btn_bag: '🎒 Inventory',
    btn_trade: '🤝 Trade',
    btn_chat: '💬 Chat',
    btn_hud_leave: 'Leave Match',

    // Modals
    roulette_title: '🎡 Fortune Wheel!',
    roulette_spinning: 'Spinning the wheel...',
    roulette_player_at: 'is on Fortune Tile!',
    roulette_won: 'Congratulations, Big Prize Won!',

    leave_modal_title: 'Leave Match',
    leave_modal_desc: 'Are you sure you want to exit the current match and return to the main menu? In multiplayer games, an AI bot will take over your spot.',
    btn_leave_confirm: '🚪 Yes, Leave Room',
    btn_leave_cancel: 'Cancel / Keep Playing',

    settings_title: '⚙️ Game Settings',
    settings_lang_title: '🌐 Language / Dil',
    settings_lang_sub: 'Interface and gameplay language',
    settings_sfx_title: '🔊 Sound Effects',
    settings_sfx_sub: 'Dice, footstep, coin and fanfare sounds',
    settings_music_title: '🎵 Background Music',
    settings_music_sub: 'Synthesized Web Audio party soundtrack',
    settings_dice_title: '🎲 3D Dice Animations',
    settings_dice_sub: 'Turn off for instant dice results',
    settings_lowpower_title: '⚡ Power Saver / Lite Mode',
    settings_lowpower_sub: 'Lightweight graphics for older mobile devices',
    btn_reset_profile: '🔄 Reset Player Profile & Data',
    btn_save_settings: 'Save Settings',

    rules_title: '📖 PartyCraft — How to Play',
    rules_goal_title: '🎯 Objective',
    rules_goal_body: 'Collect the most <strong>Stars (⭐)</strong> and <strong>Coins (🪙)</strong> before all rounds finish! 1 Star equals 20 Coins and holds highest priority on the leaderboard.',
    rules_turn_title: '🎲 Movement & Turns',
    rules_turn_body: 'On your turn, press <strong>ROLL DICE</strong> or tap <strong>SPACE</strong>. Move clockwise along the scenic board circuit. Every time you pass Start, you earn <strong>+10 Coins</strong>!',
    rules_tiles_title: '🗺️ Special Tiles & Hazards',
    rules_items_title: '🎒 Tactical Items',
    rules_close_btn: 'Got it, Back to Game!',

    // Tiles
    tile_start: 'Start (+10 🪙)',
    tile_coin: 'Coin Tile',
    tile_star: 'Star Pedestal',
    tile_mystery: 'Fortune Wheel',
    tile_trap: 'Trap Tile',
    tile_shop: 'Item Shop',
    tile_bank: 'Central Bank',
    tile_jail: 'Police / Jail',
    tile_duel: 'Duel Arena',

    // Titles
    title_novice: 'Novice Explorer',
    title_dice: 'Dice Acrobat',
    title_star: 'Star Hunter',
    title_board: 'Master of Tiles',
    title_party: 'Party Legend'
  },

  de: {
    hero_badge: '🎲 Mehrspieler-Weltreise-Brettspiel',
    hero_title: 'Party<span>Craft</span>',
    hero_subtitle: 'Würfle, rase und feiere in den Straßen von Istanbul, Tokio, Paris und New York!',
    studio_badge: '✨ GESTALTE DEINE FIGUR',
    studio_name_label: 'Name:',
    studio_name_placeholder: 'Name eingeben...',
    studio_model_label: 'Charaktermodell:',
    studio_hat_label: 'Hut & Kopfbedeckung:',
    studio_color_label: 'Körper- & Ringfarbe:',
    btn_quick_play: 'Schnellspiel',
    btn_quick_play_desc: 'Starte sofort mit 3 cleveren KI-Bots in Istanbul ohne Wartezeit!',
    btn_play_friends: 'Mit Freunden spielen',
    btn_play_friends_desc: 'Erstelle einen Raum mit 1 Klick, lade Freunde per Link oder QR-Code ein!',
    btn_play_bots: 'Gegen Bots spielen',
    btn_play_bots_desc: 'Wähle 1 bis 3 Bots und übe offline!',
    btn_how_to_play: 'Spielanleitung',
    btn_how_to_play_desc: 'Spielregeln, Felder und Taktiken',
    btn_settings: 'Einstellungen',
    btn_settings_desc: 'Audio, Musik, Sprache und Grafik',
    room_code_placeholder: 'RAUMCODE (Z.B. ABCD)',
    btn_join_room: 'Raum beitreten',
    server_status_checking: 'Serverstatus: Verbindung wird geprüft...',
    server_status_php: 'Serverstatus: PHP-Mehrspieler online bereit',
    server_status_node: 'Serverstatus: Node.js WebSocket online bereit',
    server_status_offline: 'Serverstatus: Offline-Modus (Bots & Lokales Spiel)',

    // Lobby
    lobby_room_title: 'Raumcode:',
    lobby_players_title: 'Spieler',
    lobby_share_title: 'Freunde einladen (Direktlink):',
    btn_copy_link: '📋 Link kopieren',
    btn_copied: '✅ Kopiert!',
    btn_show_qr: '📱 QR-Code anzeigen',
    btn_add_bot: '🤖 Bot hinzufügen',
    btn_leave_room: '🚪 Raum verlassen',
    lobby_city_title: 'Stadt / Kartenthema:',
    lobby_rounds_title: 'Rundenzahl:',
    btn_start_game: '🎉 Party starten!',
    lobby_waiting_host: 'Warten auf den Raumleiter...',

    // HUD & In-game
    hud_your_turn: 'Du bist dran! Würfle und ziehe vorwärts',
    hud_turn_prefix: 'Zug: ',
    hud_turn_waiting: 'Spielerzug',
    hud_round_prefix: 'Runde: ',
    btn_roll_dice: '🎲 WÜRFELN',
    btn_bag: '🎒 Inventar',
    btn_trade: '🤝 Handeln',
    btn_chat: '💬 Chat',
    btn_hud_leave: 'Spiel verlassen',

    // Modals
    roulette_title: '🎡 Glücksrad!',
    roulette_spinning: 'Das Rad dreht sich...',
    roulette_player_at: 'ist auf dem Glücksfeld!',
    roulette_won: 'Herzlichen Glückwunsch, Großer Preis gewonnen!',

    leave_modal_title: 'Spiel verlassen',
    leave_modal_desc: 'Möchtest du das Spiel wirklich verlassen und zum Hauptmenü zurückkehren? In Mehrspieler-Räumen übernimmt ein KI-Bot deinen Platz.',
    btn_leave_confirm: '🚪 Ja, Raum verlassen',
    btn_leave_cancel: 'Abbrechen / Weiterspielen',

    settings_title: '⚙️ Spieleinstellungen',
    settings_lang_title: '🌐 Sprache / Language',
    settings_lang_sub: 'Sprache für Menüs und Spieltexte',
    settings_sfx_title: '🔊 Soundeffekte',
    settings_sfx_sub: 'Würfel-, Schritt- und Münzgeräusche',
    settings_music_title: '🎵 Hintergrundmusik',
    settings_music_sub: 'Synthetisierter Web-Audio Partysoundtrack',
    settings_dice_title: '🎲 3D-Würfelanimationen',
    settings_dice_sub: 'Ausschalten für sofortige Würfelergebnisse',
    settings_lowpower_title: '⚡ Energiesparmodus',
    settings_lowpower_sub: 'Schonende Grafik für ältere Mobilgeräte',
    btn_reset_profile: '🔄 Profil & Fortschritt zurücksetzen',
    btn_save_settings: 'Einstellungen speichern',

    rules_title: '📖 PartyCraft — Spielanleitung',
    rules_goal_title: '🎯 Spielziel',
    rules_goal_body: 'Sammle vor Rundenende die meisten <strong>Sterne (⭐)</strong> und <strong>Münzen (🪙)</strong>! 1 Stern = 20 Münzen und hat oberste Priorität in der Rangliste.',
    rules_turn_title: '🎲 Zug & Bewegung',
    rules_turn_body: 'Wenn du an der Reihe bist, drücke <strong>WÜRFELN</strong> oder die Leertaste. Ziehe im Uhrzeigersinn über den Kurs. Jede Runde über Start bringt <strong>+10 Münzen</strong>!',
    rules_tiles_title: '🗺️ Sonderfelder & Gefahren',
    rules_items_title: '🎒 Taktische Gegenstände',
    rules_close_btn: 'Alles klar, zurück zum Spiel!',

    // Tiles
    tile_start: 'Start (+10 🪙)',
    tile_coin: 'Münzfeld',
    tile_star: 'Stern-Podest',
    tile_mystery: 'Glücksrad',
    tile_trap: 'Falle',
    tile_shop: 'Objektladen',
    tile_bank: 'Zentralbank',
    tile_jail: 'Gefängnis / Wache',
    tile_duel: 'Duell-Arena',

    // Titles
    title_novice: 'Neuer Entdecker',
    title_dice: 'Würfel-Akrobat',
    title_star: 'Sternenjäger',
    title_board: 'Meister der Felder',
    title_party: 'Party-Legende'
  },

  es: {
    hero_badge: '🎲 Juego de Mesa Multijugador Vuelta al Mundo',
    hero_title: 'Party<span>Craft</span>',
    hero_subtitle: '¡Tira los dados, compite y festeja por las calles de Estambul, Tokio, París y Nueva York!',
    studio_badge: '✨ DISEÑA TU PERSONAJE',
    studio_name_label: 'Nombre:',
    studio_name_placeholder: 'Escribe tu nombre...',
    studio_model_label: 'Modelo de Personaje:',
    studio_hat_label: 'Sombrero / Accesorio:',
    studio_color_label: 'Color del Cuerpo:',
    btn_quick_play: 'Partida Rápida',
    btn_quick_play_desc: '¡Empieza de inmediato con 3 bots inteligentes en Estambul sin esperas!',
    btn_play_friends: 'Jugar con Amigos',
    btn_play_friends_desc: '¡Crea una sala en 1 clic, invita amigos por enlace directo o código QR!',
    btn_play_bots: 'Jugar contra Bots',
    btn_play_bots_desc: '¡Elige de 1 a 3 bots y practica sin conexión!',
    btn_how_to_play: 'Cómo Jugar',
    btn_how_to_play_desc: 'Reglas del juego, casillas y tácticas',
    btn_settings: 'Ajustes',
    btn_settings_desc: 'Sonido, música, idioma y gráficos',
    room_code_placeholder: 'CÓDIGO DE SALA (EJ: ABCD)',
    btn_join_room: 'Unirse a Sala',
    server_status_checking: 'Estado del Servidor: Comprobando conexión...',
    server_status_php: 'Estado del Servidor: Multijugador PHP en línea listo',
    server_status_node: 'Estado del Servidor: WebSocket Node.js en línea listo',
    server_status_offline: 'Estado del Servidor: Modo Sin Conexión (Bots y juego local)',

    // Lobby
    lobby_room_title: 'Código de Sala:',
    lobby_players_title: 'Jugadores',
    lobby_share_title: 'Invitar Amigos (Enlace directo):',
    btn_copy_link: '📋 Copiar Enlace',
    btn_copied: '✅ ¡Copiado!',
    btn_show_qr: '📱 Ver Código QR',
    btn_add_bot: '🤖 Añadir Bot',
    btn_leave_room: '🚪 Salir de la Sala',
    lobby_city_title: 'Ciudad / Mapa:',
    lobby_rounds_title: 'Rondas:',
    btn_start_game: '🎉 ¡Empezar Fiesta!',
    lobby_waiting_host: 'Esperando al anfitrión para iniciar...',

    // HUD & In-game
    hud_your_turn: '¡Es tu turno! Tira el dado y avanza',
    hud_turn_prefix: 'Turno: ',
    hud_turn_waiting: 'Turno del Jugador',
    hud_round_prefix: 'Ronda: ',
    btn_roll_dice: '🎲 TIRAR DADO',
    btn_bag: '🎒 Mochila',
    btn_trade: '🤝 Intercambio',
    btn_chat: '💬 Chat',
    btn_hud_leave: 'Salir del Juego',

    // Modals
    roulette_title: '🎡 ¡Ruleta de la Suerte!',
    roulette_spinning: 'La ruleta está girando...',
    roulette_player_at: '¡está en la casilla de la suerte!',
    roulette_won: '¡Felicidades, ganaste el Gran Premio!',

    leave_modal_title: 'Salir de la Partida',
    leave_modal_desc: '¿Seguro que deseas salir al menú principal? En partidas multijugador, un bot de IA ocupará tu lugar.',
    btn_leave_confirm: '🚪 Sí, Salir de la Sala',
    btn_leave_cancel: 'Cancelar / Seguir Jugando',

    settings_title: '⚙️ Ajustes del Juego',
    settings_lang_title: '🌐 Idioma / Language',
    settings_lang_sub: 'Idioma de la interfaz y textos',
    settings_sfx_title: '🔊 Efectos de Sonido',
    settings_sfx_sub: 'Dados, pasos, monedas y fanfarrias',
    settings_music_title: '🎵 Música de Fondo',
    settings_music_sub: 'Banda sonora sintetizada Web Audio',
    settings_dice_title: '🎲 Animaciones 3D del Dado',
    settings_dice_sub: 'Desactiva para resultados instantáneos',
    settings_lowpower_title: '⚡ Modo Ahorro de Energía',
    settings_lowpower_sub: 'Gráficos ligeros para móviles antiguos',
    btn_reset_profile: '🔄 Restablecer Perfil y Datos',
    btn_save_settings: 'Guardar Ajustes',

    rules_title: '📖 PartyCraft — Cómo Jugar',
    rules_goal_title: '🎯 Objetivo del Juego',
    rules_goal_body: '¡Consigue la mayor cantidad de <strong>Estrellas (⭐)</strong> y <strong>Monedas (🪙)</strong> antes de terminar las rondas! 1 Estrella equivale a 20 Monedas y tiene máxima prioridad.',
    rules_turn_title: '🎲 Turnos y Movimiento',
    rules_turn_body: 'En tu turno, pulsa <strong>TIRAR DADO</strong> o barra espaciadora. Avanza en sentido horario por el circuito. ¡Cada vuelta por Salida da <strong>+10 Monedas</strong>!',
    rules_tiles_title: '🗺️ Casillas Especiales y Trampas',
    rules_items_title: '🎒 Objetos Tácticos',
    rules_close_btn: '¡Entendido, volver al juego!',

    // Tiles
    tile_start: 'Salida (+10 🪙)',
    tile_coin: 'Casilla Moneda',
    tile_star: 'Pedestal de Estrella',
    tile_mystery: 'Ruleta de la Suerte',
    tile_trap: 'Casilla Trampa',
    tile_shop: 'Tienda de Objetos',
    tile_bank: 'Banco Central',
    tile_jail: 'Cárcel / Comisaría',
    tile_duel: 'Arena de Duelo',

    // Titles
    title_novice: 'Explorador Novato',
    title_dice: 'Acróbata del Dado',
    title_star: 'Cazador de Estrellas',
    title_board: 'Amo del Tablero',
    title_party: 'Leyenda de la Fiesta'
  },

  fr: {
    hero_badge: '🎲 Jeu de Plateau Multijoueur Tour du Monde',
    hero_title: 'Party<span>Craft</span>',
    hero_subtitle: 'Lancez les dés, faites la course et faites la fête dans les rues d\'Istanbul, Tokyo, Paris et New York !',
    studio_badge: '✨ CRÉEZ VOTRE PERSONNAGE',
    studio_name_label: 'Nom du Joueur :',
    studio_name_placeholder: 'Entrez votre nom...',
    studio_model_label: 'Modèle :',
    studio_hat_label: 'Chapeau & Coiffe :',
    studio_color_label: 'Couleur du Corps :',
    btn_quick_play: 'Partie Rapide',
    btn_quick_play_desc: 'Rejoignez immédiatement 3 bots IA à Istanbul sans attendre !',
    btn_play_friends: 'Jouer avec des Amis',
    btn_play_friends_desc: 'Créez une salle en 1 clic, invitez vos amis par lien direct ou QR code !',
    btn_play_bots: 'Jouer contre des Bots',
    btn_play_bots_desc: 'Choisissez de 1 à 3 bots et entraînez-vous hors ligne !',
    btn_how_to_play: 'Comment Jouer',
    btn_how_to_play_desc: 'Règles du jeu, cases et tactiques',
    btn_settings: 'Paramètres',
    btn_settings_desc: 'Audio, musique, langue et graphismes',
    room_code_placeholder: 'CODE DE SALLE (EX: ABCD)',
    btn_join_room: 'Rejoindre la Salle',
    server_status_checking: 'État du Serveur : Vérification de la connexion...',
    server_status_php: 'État du Serveur : Multijoueur PHP en ligne prêt',
    server_status_node: 'État du Serveur : WebSocket Node.js en ligne prêt',
    server_status_offline: 'État du Serveur : Mode Hors Ligne (Bots & Jeu local)',

    // Lobby
    lobby_room_title: 'Code de Salle :',
    lobby_players_title: 'Joueurs',
    lobby_share_title: 'Inviter des Amis (Lien direct) :',
    btn_copy_link: '📋 Copier le Lien' ,
    btn_copied: '✅ Copié !',
    btn_show_qr: '📱 Afficher le QR Code',
    btn_add_bot: '🤖 Ajouter un Bot',
    btn_leave_room: '🚪 Quitter la Salle',
    lobby_city_title: 'Ville / Thème :',
    lobby_rounds_title: 'Nombre de Tours :',
    btn_start_game: '🎉 Lancer la Fête !',
    lobby_waiting_host: 'En attente de l\'hôte pour démarrer...',

    // HUD & In-game
    hud_your_turn: 'À vous de jouer ! Lancez le dé et avancez',
    hud_turn_prefix: 'Tour : ',
    hud_turn_waiting: 'Tour du Joueur',
    hud_round_prefix: 'Manche : ',
    btn_roll_dice: '🎲 LANCER LE DÉ',
    btn_bag: '🎒 Inventaire',
    btn_trade: '🤝 Échange',
    btn_chat: '💬 Chat',
    btn_hud_leave: 'Quitter la Partie',

    // Modals
    roulette_title: '🎡 Roue de la Fortune !',
    roulette_spinning: 'La roue tourne...',
    roulette_player_at: 'est sur la case chance !',
    roulette_won: 'Félicitations, Grand Prix remporté !',

    leave_modal_title: 'Quitter la Partie',
    leave_modal_desc: 'Êtes-vous sûr de vouloir quitter vers le menu principal ? En multijoueur, un bot IA prendra votre place.',
    btn_leave_confirm: '🚪 Oui, Quitter la Salle',
    btn_leave_cancel: 'Annuler / Continuer à Jouer',

    settings_title: '⚙️ Paramètres du Jeu',
    settings_lang_title: '🌐 Langue / Language',
    settings_lang_sub: 'Langue de l\'interface et des textes',
    settings_sfx_title: '🔊 Effets Sonores',
    settings_sfx_sub: 'Dés, pas, pièces et fanfares',
    settings_music_title: '🎵 Musique de Fond',
    settings_music_sub: 'Bande-son festive synthétisée Web Audio',
    settings_dice_title: '🎲 Animations 3D du Dé',
    settings_dice_sub: 'Désactiver pour des résultats instantanés',
    settings_lowpower_title: '⚡ Mode Économie d\'Énergie',
    settings_lowpower_sub: 'Graphismes allégés pour mobiles anciens',
    btn_reset_profile: '🔄 Réinitialiser le Profil',
    btn_save_settings: 'Enregistrer les Paramètres',

    rules_title: '📖 PartyCraft — Comment Jouer',
    rules_goal_title: '🎯 Objectif du Jeu',
    rules_goal_body: 'Récoltez le plus d\'<strong>Étoiles (⭐)</strong> et de <strong>Pièces (🪙)</strong> avant la fin des manches ! 1 Étoile vaut 20 Pièces et prime au classement.',
    rules_turn_title: '🎲 Déplacement et Tours',
    rules_turn_body: 'À votre tour, cliquez sur <strong>LANCER LE DÉ</strong> ou appuyez sur Espace. Avancez dans le sens horaire. Chaque passage par Départ rapporte <strong>+10 Pièces</strong> !',
    rules_tiles_title: '🗺️ Cases Spéciales & Pièges',
    rules_items_title: '🎒 Objets Tactiques',
    rules_close_btn: 'Compris, retour au jeu !',

    // Tiles
    tile_start: 'Départ (+10 🪙)',
    tile_coin: 'Case Pièce',
    tile_star: 'Socle d\'Étoile',
    tile_mystery: 'Roue de la Fortune',
    tile_trap: 'Case Piège',
    tile_shop: 'Boutique d\'Objets',
    tile_bank: 'Banque Centrale',
    tile_jail: 'Prison / Commissariat',
    tile_duel: 'Arène de Duel',

    // Titles
    title_novice: 'Explorateur Novice',
    title_dice: 'Acrobate du Dé',
    title_star: 'Chasseur d\'Étoiles',
    title_board: 'Maître des Cases',
    title_party: 'Légende de la Fête'
  }
};

const SUPPORTED_LANGUAGES = ['tr', 'en', 'de', 'es', 'fr'];

class I18nManager {
  constructor() {
    this.currentLang = this.detectUserLanguage();
  }

  /**
   * Automatically detects the user's preferred language:
   * 1. URL parameter override: ?lang=en / ?lang=de / etc.
   * 2. Saved user preference in localStorage
   * 3. Browser locale from navigator.language / navigator.languages (e.g. US/UK -> en, DE -> de, FR -> fr, ES -> es, TR -> tr)
   * 4. Smart fallback: 'en' for international visitors outside Turkey, 'tr' for Turkish systems.
   */
  detectUserLanguage() {
    // 1. URL Query Parameter Override (?lang=en)
    try {
      if (typeof window !== 'undefined' && window.location && window.location.search) {
        const urlParams = new URLSearchParams(window.location.search);
        const urlLang = urlParams.get('lang');
        if (urlLang && SUPPORTED_LANGUAGES.includes(urlLang.toLowerCase())) {
          const clean = urlLang.toLowerCase();
          try { localStorage.setItem('partycraft_lang', clean); } catch (e) {}
          return clean;
        }
      }
    } catch (e) {}

    // 2. Previously Saved Preference in LocalStorage
    try {
      if (typeof localStorage !== 'undefined') {
        const saved = localStorage.getItem('partycraft_lang');
        if (saved && SUPPORTED_LANGUAGES.includes(saved.toLowerCase())) {
          return saved.toLowerCase();
        }
      }
    } catch (e) {}

    // 3. Browser / System Locale Detection (America, Europe, International)
    try {
      if (typeof navigator !== 'undefined') {
        const locales = navigator.languages || [navigator.language || navigator.userLanguage || ''];
        for (const loc of locales) {
          if (!loc || typeof loc !== 'string') continue;
          const clean = loc.toLowerCase().split('-')[0].split('_')[0]; // 'en-US' -> 'en', 'de-AT' -> 'de'
          if (SUPPORTED_LANGUAGES.includes(clean)) {
            return clean;
          }
        }
      }
    } catch (e) {}

    // 4. Default Fallback: If Turkish system, use 'tr'; otherwise default to international 'en'
    try {
      if (typeof navigator !== 'undefined') {
        const primary = (navigator.language || navigator.userLanguage || '').toLowerCase();
        if (primary.startsWith('tr')) return 'tr';
      }
    } catch (e) {}

    return 'en'; // International English fallback for visitors from America or other countries
  }

  getLang() {
    return this.currentLang;
  }

  t(key, fallback = '') {
    const dict = I18N_DATA[this.currentLang] || I18N_DATA.tr;
    if (dict && dict[key] !== undefined) {
      return dict[key];
    }
    const defaultDict = I18N_DATA.tr;
    return defaultDict[key] !== undefined ? defaultDict[key] : (fallback || key);
  }

  setLang(lang) {
    if (!SUPPORTED_LANGUAGES.includes(lang)) return;
    this.currentLang = lang;
    try {
      localStorage.setItem('partycraft_lang', lang);
    } catch (e) {}

    this.applyTranslations();

    // Notify UI and board if active
    if (window.UIEngine) {
      if (typeof window.UIEngine.onLanguageChanged === 'function') {
        window.UIEngine.onLanguageChanged(lang);
      }
    }
    if (window.BoardMap && typeof window.BoardMap.renderBoard === 'function') {
      window.BoardMap.renderBoard();
    }
  }

  applyTranslations() {
    if (typeof document === 'undefined') return;

    // Update HTML root lang attribute
    try {
      document.documentElement.lang = this.currentLang;
    } catch (e) {}

    // 1. Text content elements
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(el => {
      const key = el.getAttribute('data-i18n');
      const val = this.t(key);
      if (val) {
        if (val.includes('<') && val.includes('>')) {
          el.innerHTML = val;
        } else {
          el.textContent = val;
        }
      }
    });

    // 2. Placeholders
    const inputs = document.querySelectorAll('[data-i18n-placeholder]');
    inputs.forEach(el => {
      const key = el.getAttribute('data-i18n-placeholder');
      const val = this.t(key);
      if (val) {
        el.setAttribute('placeholder', val);
      }
    });

    // 3. Update active state of language toggle buttons
    const langBtns = document.querySelectorAll('.lang-btn, .lang-pill-btn');
    langBtns.forEach(btn => {
      const btnLang = btn.getAttribute('data-lang');
      if (btnLang === this.currentLang) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }
}

// Global instance
window.i18n = new I18nManager();
window.t = (key, fallback) => window.i18n.t(key, fallback);
window.setLanguage = (lang) => window.i18n.setLang(lang);

// Auto-apply translations on initial load
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => window.i18n.applyTranslations());
  } else {
    window.i18n.applyTranslations();
  }
}


/* =================== 2. QR CODE SVG GENERATOR =================== */
/**
 * Standalone Offline QR Code SVG Generator
 * Based on Kazuhiko Arase's QR Code algorithm (Public Domain / MIT)
 * Zero external libraries, zero CDN, 100% offline pure SVG generation.
 */
(function(window) {
  'use strict';

  // Galois Field and Reed-Solomon tables
  var QRMath = {
    glog: function(n) {
      if (n < 1) throw new Error('glog(' + n + ')');
      return QRMath.LOG_TABLE[n];
    },
    gexp: function(n) {
      while (n < 0) n += 255;
      while (n >= 256) n -= 255;
      return QRMath.EXP_TABLE[n];
    },
    EXP_TABLE: new Array(256),
    LOG_TABLE: new Array(256)
  };

  for (var i = 0; i < 8; i++) QRMath.EXP_TABLE[i] = 1 << i;
  for (var i = 8; i < 256; i++) QRMath.EXP_TABLE[i] = QRMath.EXP_TABLE[i - 4] ^ QRMath.EXP_TABLE[i - 5] ^ QRMath.EXP_TABLE[i - 6] ^ QRMath.EXP_TABLE[i - 8];
  for (var i = 0; i < 255; i++) QRMath.LOG_TABLE[QRMath.EXP_TABLE[i]] = i;

  function QRPolynomial(num, shift) {
    if (num.length === undefined) throw new Error(num.length + '/' + shift);
    var offset = 0;
    while (offset < num.length && num[offset] === 0) offset++;
    this.num = new Array(num.length - offset + shift);
    for (var i = 0; i < num.length - offset; i++) this.num[i] = num[i + offset];
    for (var i = num.length - offset; i < this.num.length; i++) this.num[i] = 0;
  }

  QRPolynomial.prototype = {
    get: function(index) { return this.num[index]; },
    getLength: function() { return this.num.length; },
    multiply: function(e) {
      var num = new Array(this.getLength() + e.getLength() - 1);
      for (var i = 0; i < this.getLength(); i++) {
        for (var j = 0; j < e.getLength(); j++) {
          num[i + j] ^= QRMath.gexp(QRMath.glog(this.get(i)) + QRMath.glog(e.get(j)));
        }
      }
      return new QRPolynomial(num, 0);
    },
    mod: function(e) {
      if (this.getLength() - e.getLength() < 0) return this;
      var ratio = QRMath.glog(this.get(0)) - QRMath.glog(e.get(0));
      var num = new Array(this.getLength());
      for (var i = 0; i < this.getLength(); i++) num[i] = this.get(i);
      for (var i = 0; i < e.getLength(); i++) {
        num[i] ^= QRMath.gexp(QRMath.glog(e.get(i)) + ratio);
      }
      return new QRPolynomial(num, 0).mod(e);
    }
  };

  // QR RS Blocks table for versions 1 to 10 (ECC Level M)
  var RS_BLOCK_TABLE = [
    [1, 26, 16], // v1
    [1, 44, 28], // v2
    [1, 70, 44], // v3
    [2, 50, 32], // v4
    [2, 67, 43], // v5
    [4, 43, 27], // v6
    [4, 53, 31], // v7
    [4, 65, 39], // v8
    [5, 68, 40], // v9
    [5, 78, 46]  // v10
  ];

  function QRCodeModel(typeNumber) {
    this.typeNumber = typeNumber;
    this.modules = null;
    this.moduleCount = 0;
    this.dataList = [];
  }

  QRCodeModel.prototype = {
    addData: function(data) {
      this.dataList.push(data);
    },
    isDark: function(row, col) {
      if (row < 0 || this.moduleCount <= row || col < 0 || this.moduleCount <= col) {
        throw new Error(row + ',' + col);
      }
      return this.modules[row][col];
    },
    getModuleCount: function() {
      return this.moduleCount;
    },
    make: function() {
      this.moduleCount = this.typeNumber * 4 + 17;
      this.modules = new Array(this.moduleCount);
      for (var row = 0; row < this.moduleCount; row++) {
        this.modules[row] = new Array(this.moduleCount);
        for (var col = 0; col < this.moduleCount; col++) {
          this.modules[row][col] = null;
        }
      }
      this.setupPositionProbePattern(0, 0);
      this.setupPositionProbePattern(this.moduleCount - 7, 0);
      this.setupPositionProbePattern(0, this.moduleCount - 7);
      this.setupTimingPattern();
      if (this.typeNumber >= 2) {
        this.setupPositionAdjustPattern();
      }
      this.setupTypeInfo(false, 0);
      this.mapData(this.createData(), 0);
    },
    setupPositionProbePattern: function(row, col) {
      for (var r = -1; r <= 7; r++) {
        if (row + r <= -1 || this.moduleCount <= row + r) continue;
        for (var c = -1; c <= 7; c++) {
          if (col + c <= -1 || this.moduleCount <= col + c) continue;
          if ((0 <= r && r <= 6 && (c === 0 || c === 6)) ||
              (0 <= c && c <= 6 && (r === 0 || r === 6)) ||
              (2 <= r && r <= 4 && 2 <= c && c <= 4)) {
            this.modules[row + r][col + c] = true;
          } else {
            this.modules[row + r][col + c] = false;
          }
        }
      }
    },
    setupTimingPattern: function() {
      for (var r = 8; r < this.moduleCount - 8; r++) {
        if (this.modules[r][6] !== null) continue;
        this.modules[r][6] = (r % 2 === 0);
      }
      for (var c = 8; c < this.moduleCount - 8; c++) {
        if (this.modules[6][c] !== null) continue;
        this.modules[6][c] = (c % 2 === 0);
      }
    },
    setupPositionAdjustPattern: function() {
      var pos = [6, 18, 22, 26, 30, 34][this.typeNumber - 1] || (this.moduleCount - 7);
      var row = pos, col = pos;
      for (var r = -2; r <= 2; r++) {
        for (var c = -2; c <= 2; c++) {
          if (r === -2 || r === 2 || c === -2 || c === 2 || (r === 0 && c === 0)) {
            this.modules[row + r][col + c] = true;
          } else {
            this.modules[row + r][col + c] = false;
          }
        }
      }
    },
    setupTypeInfo: function(test, maskPattern) {
      var data = (1 << 3) | maskPattern; // Level M = 0
      var bits = (data << 10);
      var g = 1335;
      while (bits >= 1024) {
        var shift = Math.floor(Math.log(bits) / Math.LN2) - Math.floor(Math.log(g) / Math.LN2);
        bits ^= (g << shift);
      }
      var format = ((data << 10) | bits) ^ 21522;
      for (var i = 0; i < 15; i++) {
        var mod = (!test && ((format >> i) & 1) === 1);
        if (i < 6) this.modules[i][8] = mod;
        else if (i < 8) this.modules[i + 1][8] = mod;
        else this.modules[this.moduleCount - 15 + i][8] = mod;

        if (i < 8) this.modules[8][this.moduleCount - i - 1] = mod;
        else if (i < 9) this.modules[8][15 - i - 1 + 1] = mod;
        else this.modules[8][15 - i - 1] = mod;
      }
      this.modules[this.moduleCount - 8][8] = !test;
    },
    mapData: function(data, maskPattern) {
      var inc = -1;
      var row = this.moduleCount - 1;
      var bitIndex = 7;
      var byteIndex = 0;
      for (var col = this.moduleCount - 1; col > 0; col -= 2) {
        if (col === 6) col--;
        while (true) {
          for (var c = 0; c < 2; c++) {
            if (this.modules[row][col - c] === null) {
              var dark = false;
              if (byteIndex < data.length) {
                dark = (((data[byteIndex] >>> bitIndex) & 1) === 1);
              }
              var mask = ((row + col - c) % 2 === 0);
              if (mask) dark = !dark;
              this.modules[row][col - c] = dark;
              bitIndex--;
              if (bitIndex === -1) {
                byteIndex++;
                bitIndex = 7;
              }
            }
          }
          row += inc;
          if (row < 0 || this.moduleCount <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    },
    createData: function() {
      var rsBlock = RS_BLOCK_TABLE[this.typeNumber - 1];
      var totalDataCount = rsBlock[0] * rsBlock[2];
      var buffer = [];
      // 8-bit byte mode indicator (0100)
      buffer.push(4);
      var text = this.dataList.join('');
      var utf8Bytes = [];
      for (var i = 0; i < text.length; i++) {
        var code = text.charCodeAt(i);
        if (code < 128) utf8Bytes.push(code);
        else if (code < 2048) utf8Bytes.push(192 | (code >> 6), 128 | (code & 63));
        else utf8Bytes.push(224 | (code >> 12), 128 | ((code >> 6) & 63), 128 | (code & 63));
      }
      
      // Length
      var bits = [];
      function put(val, len) {
        for (var b = len - 1; b >= 0; b--) {
          bits.push((val >>> b) & 1);
        }
      }
      put(4, 4); // mode
      put(utf8Bytes.length, this.typeNumber < 10 ? 8 : 16); // char count
      for (var i = 0; i < utf8Bytes.length; i++) {
        put(utf8Bytes[i], 8);
      }
      
      // Terminate
      while (bits.length % 8 !== 0) bits.push(0);
      var bytes = [];
      for (var i = 0; i < bits.length; i += 8) {
        var b = 0;
        for (var j = 0; j < 8; j++) b = (b << 1) | bits[i + j];
        bytes.push(b);
      }

      // Pad bytes
      var pad = [236, 17];
      var pidx = 0;
      while (bytes.length < totalDataCount) {
        bytes.push(pad[pidx]);
        pidx = (pidx + 1) % 2;
      }

      // Error correction generator polynomial
      var ecCount = rsBlock[1] - rsBlock[2];
      var gpoly = new QRPolynomial([1], 0);
      for (var i = 0; i < ecCount; i++) {
        gpoly = gpoly.multiply(new QRPolynomial([1, QRMath.gexp(i)], 0));
      }

      var rawPoly = new QRPolynomial(bytes, gpoly.getLength() - 1);
      var modPoly = rawPoly.mod(gpoly);
      var ecBytes = [];
      for (var i = 0; i < gpoly.getLength() - 1; i++) {
        var modIndex = i + modPoly.getLength() - (gpoly.getLength() - 1);
        ecBytes.push(modIndex >= 0 ? modPoly.get(modIndex) : 0);
      }

      return bytes.concat(ecBytes);
    }
  };

  /**
   * Generates a crisp, scalable, standalone SVG string for any URL or text.
   */
  function generateQRCodeSVG(text, size) {
    size = size || 180;
    var len = text.length;
    var type = 3;
    if (len < 14) type = 1;
    else if (len < 26) type = 2;
    else if (len < 42) type = 3;
    else if (len < 62) type = 4;
    else if (len < 84) type = 5;
    else type = 7;

    var qr = new QRCodeModel(type);
    qr.addData(text);
    qr.make();

    var count = qr.getModuleCount();
    var margin = 2;
    var fullSize = count + margin * 2;
    var path = '';

    for (var r = 0; r < count; r++) {
      for (var c = 0; c < count; c++) {
        if (qr.isDark(r, c)) {
          path += 'M' + (c + margin) + ',' + (r + margin) + 'h1v1h-1z ';
        }
      }
    }

    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + fullSize + ' ' + fullSize + '" width="' + size + '" height="' + size + '" shape-rendering="crispEdges">' +
           '<rect width="100%" height="100%" fill="#FFFFFF" rx="3"/>' +
           '<path d="' + path + '" fill="#0F172A"/>' +
           '</svg>';
  }

  window.generateQRCodeSVG = generateQRCodeSVG;
})(typeof window !== 'undefined' ? window : global);


/* =================== 3. AUDIO SYNTHESIZER =================== */
/**
 * Web Audio API Sound Synthesizer Engine
 * 100% Procedural & Royalty-Free - Zero external dependencies!
 */
class SoundEngine {
  constructor() {
    this.ctx = null;
    this.muted = false;
    this.musicPlaying = false;
    this.musicTimer = null;
    this.musicStep = 0;
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleMute() {
    this.muted = !this.muted;
    if (this.muted && this.musicPlaying) {
      this.stopMusic();
    }
    return this.muted;
  }

  playTone(freq, type = 'sine', duration = 0.1, gainVal = 0.15, delay = 0) {
    if (this.muted || !this.ctx) return;
    const now = this.ctx.currentTime + delay;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);

    gain.gain.setValueAtTime(gainVal, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + duration);
  }

  playClick() {
    this.init();
    if (this.muted || !this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(450, now);
    osc.frequency.exponentialRampToValueAtTime(120, now + 0.04);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.linearRampToValueAtTime(0.001, now + 0.04);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.04);
  }

  playStep() {
    this.init();
    if (this.muted || !this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(540, now + 0.08);
    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.09);
  }

  playDiceRoll() {
    this.init();
    if (this.muted || !this.ctx) return;
    const clicks = 8;
    for (let i = 0; i < clicks; i++) {
      const delay = i * 0.07;
      const freq = 180 + Math.random() * 220;
      this.playTone(freq, 'triangle', 0.03, 0.15, delay);
    }
  }

  playCoinSound() {
    this.init();
    if (this.muted || !this.ctx) return;
    // Bouncy two-tone coin arpeggio
    this.playTone(987.77, 'sine', 0.12, 0.22, 0);       // B5
    this.playTone(1318.51, 'triangle', 0.25, 0.28, 0.09); // E6
  }

  playStarFanfare() {
    this.init();
    if (this.muted || !this.ctx) return;
    // Triumphant Mario Party-style trumpet chords
    const notes = [
      { f: 523.25, d: 0.12, t: 0 },    // C5
      { f: 659.25, d: 0.12, t: 0.12 }, // E5
      { f: 783.99, d: 0.12, t: 0.24 }, // G5
      { f: 1046.50, d: 0.45, t: 0.36 } // C6
    ];
    notes.forEach(n => {
      this.playTone(n.f, 'triangle', n.d, 0.25, n.t);
      this.playTone(n.f * 1.002, 'sawtooth', n.d * 0.8, 0.08, n.t);
    });
  }

  playTrapSound() {
    this.init();
    if (this.muted || !this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(380, now);
    osc.frequency.linearRampToValueAtTime(110, now + 0.35);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.35);
  }

  playWarpSound() {
    this.init();
    if (this.muted || !this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(200, now);
    osc.frequency.exponentialRampToValueAtTime(1200, now + 0.28);
    gain.gain.setValueAtTime(0.22, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.3);
  }

  playCountdown(isFinal = false) {
    this.init();
    if (isFinal) {
      this.playTone(880, 'triangle', 0.35, 0.3);
    } else {
      this.playTone(440, 'sine', 0.15, 0.2);
    }
  }

  playEmoteReaction() {
    this.init();
    if (this.muted || !this.ctx) return;
    this.playTone(600, 'sine', 0.08, 0.15, 0);
    this.playTone(900, 'sine', 0.12, 0.2, 0.07);
  }

  playSlipSound() {
    this.init();
    if (this.muted || !this.ctx) return;
    const now = this.ctx.currentTime;
    // Comedic slide whistle up then down + boing
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(300, now);
    osc.frequency.linearRampToValueAtTime(750, now + 0.15);
    osc.frequency.linearRampToValueAtTime(140, now + 0.38);
    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.4);
  }

  playJailSound() {
    this.init();
    if (this.muted || !this.ctx) return;
    // Clang of iron prison bars
    this.playTone(220, 'sawtooth', 0.3, 0.3, 0);
    this.playTone(180, 'sawtooth', 0.4, 0.25, 0.05);
    this.playTone(110, 'triangle', 0.5, 0.35, 0.08);
  }

  playWheelTick() {
    this.init();
    if (this.muted || !this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1200 + Math.random() * 300, now);
    osc.frequency.exponentialRampToValueAtTime(180, now + 0.025);
    gain.gain.setValueAtTime(0.18, now);
    gain.gain.linearRampToValueAtTime(0.001, now + 0.025);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.025);
  }

  playLevelUp() {
    this.init();
    if (this.muted || !this.ctx) return;
    // Euphoric triumphant 5-note fanfare
    const notes = [
      { f: 523.25, d: 0.1, t: 0 },
      { f: 659.25, d: 0.1, t: 0.1 },
      { f: 783.99, d: 0.1, t: 0.2 },
      { f: 987.77, d: 0.12, t: 0.3 },
      { f: 1046.50, d: 0.55, t: 0.42 }
    ];
    notes.forEach(n => {
      this.playTone(n.f, 'triangle', n.d, 0.3, n.t);
      this.playTone(n.f * 1.003, 'sine', n.d, 0.15, n.t);
    });
  }

  playScreenShake() {
    this.init();
    if (this.muted || !this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(80, now);
    osc.frequency.linearRampToValueAtTime(35, now + 0.45);
    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.45);
  }

  playChestOpen() {
    this.init();
    if (this.muted || !this.ctx) return;
    // Mystical sparkle arpeggio
    const freqs = [587.33, 739.99, 880.00, 1174.66, 1479.98];
    freqs.forEach((f, idx) => {
      this.playTone(f, 'sine', 0.18, 0.2, idx * 0.06);
    });
  }

  // Procedural Background Music (Charming upbeat lounge arpeggios)
  startMusic() {
    if (this.musicPlaying || this.muted) return;
    this.init();
    if (!this.ctx) return;

    this.musicPlaying = true;
    const bpm = 120;
    const stepTime = (60 / bpm) / 2; // eighth notes

    // Cheerful pentatonic pattern
    const melody = [
      523.25, 0, 659.25, 783.99, 1046.50, 783.99, 659.25, 0,
      587.33, 0, 698.46, 880.00, 1174.66, 880.00, 698.46, 0,
      440.00, 0, 523.25, 659.25, 880.00, 659.25, 523.25, 0,
      392.00, 440.00, 523.25, 659.25, 783.99, 0, 0, 0
    ];

    const bass = [
      130.81, 0, 130.81, 0, 164.81, 0, 196.00, 0,
      146.83, 0, 146.83, 0, 174.61, 0, 220.00, 0,
      110.00, 0, 110.00, 0, 130.81, 0, 164.81, 0,
      98.00, 0, 98.00, 0, 130.81, 0, 196.00, 0
    ];

    const playLoop = () => {
      if (!this.musicPlaying || this.muted) return;
      const mFreq = melody[this.musicStep % melody.length];
      const bFreq = bass[this.musicStep % bass.length];

      if (mFreq > 0) {
        this.playTone(mFreq, 'sine', 0.14, 0.035);
      }
      if (bFreq > 0) {
        this.playTone(bFreq, 'triangle', 0.22, 0.045);
      }

      this.musicStep++;
      this.musicTimer = setTimeout(playLoop, stepTime * 1000);
    };

    playLoop();
  }

  stopMusic() {
    this.musicPlaying = false;
    if (this.musicTimer) {
      clearTimeout(this.musicTimer);
      this.musicTimer = null;
    }
  }

  toggleMusic() {
    if (this.musicPlaying) {
      this.stopMusic();
      return false;
    } else {
      this.startMusic();
      return true;
    }
  }
}

const AudioPlayer = new SoundEngine();


/* =================== 4. PROGRESSION =================== */
/**
 * Player Progression, XP, Level, and Unlockables System
 */
const AVATAR_DEFS = {
  builder: {
    id: 'builder',
    name: 'Minifig Bob',
    requiredLevel: 1,
    desc: 'Neşeli usta lego inşaatçısı.',
    color: '#3B82F6',
    svg: `<svg viewBox="0 0 48 48" width="100%" height="100%">
      <defs>
        <radialGradient id="bobHead" cx="40%" cy="35%" r="60%">
          <stop offset="0%" stop-color="#FEF08A"/>
          <stop offset="70%" stop-color="#FACC15"/>
          <stop offset="100%" stop-color="#EAB308"/>
        </radialGradient>
        <linearGradient id="bobHat" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#F97316"/>
          <stop offset="100%" stop-color="#EA580C"/>
        </linearGradient>
      </defs>
      <path d="M12 15 C12 6, 36 6, 36 15 Z" fill="url(#bobHat)"/>
      <ellipse cx="24" cy="15" rx="14" ry="3.5" fill="#C2410C"/>
      <path d="M18 9 Q24 7 30 9" stroke="#FED7AA" stroke-width="1.5" stroke-linecap="round" fill="none"/>
      <rect x="15" y="15" width="18" height="15" rx="4" fill="url(#bobHead)"/>
      <circle cx="20" cy="21" r="2.2" fill="#0F172A"/>
      <circle cx="19.3" cy="20.3" r="0.8" fill="#FFFFFF"/>
      <circle cx="28" cy="21" r="2.2" fill="#0F172A"/>
      <circle cx="27.3" cy="20.3" r="0.8" fill="#FFFFFF"/>
      <ellipse cx="18" cy="24" rx="2" ry="1.2" fill="#F87171" opacity="0.5"/>
      <ellipse cx="30" cy="24" rx="2" ry="1.2" fill="#F87171" opacity="0.5"/>
      <path d="M21 24 Q24 28 27 24" stroke="#0F172A" stroke-width="1.8" stroke-linecap="round" fill="none"/>
      <path d="M11 31 L37 31 L34 45 L14 45 Z" fill="#2563EB"/>
      <rect x="19" y="31" width="10" height="14" fill="#1D4ED8"/>
      <circle cx="16" cy="33" r="1.3" fill="#FBBF24"/>
      <circle cx="32" cy="33" r="1.3" fill="#FBBF24"/>
      <path d="M22 36 L26 40" stroke="#CBD5E1" stroke-width="1.5" stroke-linecap="round"/>
    </svg>`
  },
  dino: {
    id: 'dino',
    name: 'Şapkalı Dino',
    requiredLevel: 1,
    desc: 'Partilere bayılan sevimli yeşil dinozor.',
    color: '#10B981',
    svg: `<svg viewBox="0 0 48 48" width="100%" height="100%">
      <defs>
        <radialGradient id="dinoSkin" cx="35%" cy="35%" r="65%">
          <stop offset="0%" stop-color="#6EE7B7"/>
          <stop offset="60%" stop-color="#10B981"/>
          <stop offset="100%" stop-color="#047857"/>
        </radialGradient>
      </defs>
      <polygon points="12,12 8,5 16,10" fill="#F59E0B"/>
      <polygon points="19,8 20,1 23,8" fill="#EF4444"/>
      <polygon points="26,10 32,5 28,12" fill="#3B82F6"/>
      <rect x="12" y="11" width="24" height="20" rx="9" fill="url(#dinoSkin)"/>
      <ellipse cx="24" cy="23" rx="7" ry="4.5" fill="#34D399"/>
      <circle cx="22" cy="22" r="1" fill="#065F46"/>
      <circle cx="26" cy="22" r="1" fill="#065F46"/>
      <circle cx="18" cy="18" r="2.8" fill="#064E3B"/>
      <circle cx="17.2" cy="17" r="1.1" fill="#FFFFFF"/>
      <circle cx="30" cy="18" r="2.8" fill="#064E3B"/>
      <circle cx="29.2" cy="17" r="1.1" fill="#FFFFFF"/>
      <ellipse cx="15" cy="22" rx="2.5" ry="1.5" fill="#F472B6" opacity="0.65"/>
      <ellipse cx="33" cy="22" rx="2.5" ry="1.5" fill="#F472B6" opacity="0.65"/>
      <polygon points="24,2 19,12 29,12" fill="#F43F5E"/>
      <circle cx="24" cy="2" r="1.8" fill="#FDE047"/>
      <path d="M14 31 Q24 29 34 31 L32 45 L16 45 Z" fill="#059669"/>
      <ellipse cx="24" cy="38" rx="6" ry="5" fill="#A7F3D0"/>
    </svg>`
  },
  cat: {
    id: 'cat',
    name: 'Siber Neko',
    requiredLevel: 1,
    desc: 'Hızlı ve şanslı neon siber kedi.',
    color: '#EC4899',
    svg: `<svg viewBox="0 0 48 48" width="100%" height="100%">
      <defs>
        <radialGradient id="catSkin" cx="40%" cy="35%" r="60%">
          <stop offset="0%" stop-color="#FBCFE8"/>
          <stop offset="70%" stop-color="#F472B6"/>
          <stop offset="100%" stop-color="#DB2777"/>
        </radialGradient>
      </defs>
      <polygon points="11,18 15,4 23,15" fill="#DB2777"/>
      <polygon points="14,16 16,7 21,14" fill="#FDF2F8"/>
      <polygon points="37,18 33,4 25,15" fill="#DB2777"/>
      <polygon points="34,16 32,7 27,14" fill="#FDF2F8"/>
      <rect x="13" y="13" width="22" height="18" rx="8" fill="url(#catSkin)"/>
      <rect x="11" y="16" width="26" height="5" rx="2.5" fill="#0F172A"/>
      <rect x="13" y="17.5" width="22" height="2" rx="1" fill="#06B6D4"/>
      <ellipse cx="19" cy="22" rx="2.6" ry="3" fill="#0F172A"/>
      <circle cx="18.2" cy="21" r="1.1" fill="#FFFFFF"/>
      <ellipse cx="29" cy="22" rx="2.6" ry="3" fill="#0F172A"/>
      <circle cx="28.2" cy="21" r="1.1" fill="#FFFFFF"/>
      <polygon points="24,24 23,25.5 25,25.5" fill="#9D174D"/>
      <path d="M22 26 Q24 27.5 26 26" stroke="#9D174D" stroke-width="1.3" fill="none"/>
      <line x1="12" y1="23" x2="6" y2="22" stroke="#FCE7F3" stroke-width="1.5" stroke-linecap="round"/>
      <line x1="12" y1="25" x2="5" y2="26" stroke="#FCE7F3" stroke-width="1.5" stroke-linecap="round"/>
      <line x1="36" y1="23" x2="42" y2="22" stroke="#FCE7F3" stroke-width="1.5" stroke-linecap="round"/>
      <line x1="36" y1="25" x2="43" y2="26" stroke="#FCE7F3" stroke-width="1.5" stroke-linecap="round"/>
      <rect x="16" y="31" width="16" height="13" rx="4" fill="#BE185D"/>
      <circle cx="24" cy="33" r="2.8" fill="#FBBF24"/>
      <circle cx="24" cy="33.8" r="0.8" fill="#78350F"/>
    </svg>`
  },
  astro: {
    id: 'astro',
    name: 'Kozmik Kaşif',
    requiredLevel: 2,
    desc: 'Uzayın derinliklerinden gelen zar ustası.',
    color: '#06B6D4',
    svg: `<svg viewBox="0 0 48 48" width="100%" height="100%">
      <defs>
        <radialGradient id="visorGrad" cx="30%" cy="30%" r="70%">
          <stop offset="0%" stop-color="#67E8F9"/>
          <stop offset="50%" stop-color="#0891B2"/>
          <stop offset="100%" stop-color="#083344"/>
        </radialGradient>
      </defs>
      <line x1="24" y1="2" x2="24" y2="8" stroke="#94A3B8" stroke-width="2"/>
      <circle cx="24" cy="2" r="2.2" fill="#EF4444"/>
      <circle cx="24" cy="18" r="13" fill="#E2E8F0"/>
      <ellipse cx="24" cy="18" rx="9" ry="7" fill="url(#visorGrad)"/>
      <path d="M19 14 Q24 12 28 15" stroke="#FFFFFF" stroke-width="1.8" stroke-linecap="round" fill="none" opacity="0.8"/>
      <circle cx="27" cy="19" r="1.2" fill="#FFFFFF" opacity="0.9"/>
      <path d="M13 31 Q24 29 35 31 L33 45 L15 45 Z" fill="#F1F5F9"/>
      <rect x="18" y="33" width="12" height="11" rx="2" fill="#0891B2"/>
      <circle cx="21" cy="37" r="1.2" fill="#22C55E"/>
      <circle cx="27" cy="37" r="1.2" fill="#F59E0B"/>
    </svg>`
  },
  wizard: {
    id: 'wizard',
    name: 'Büyücü Merlin',
    requiredLevel: 2,
    desc: 'Zarları sihirle manipüle eden usta.',
    color: '#8B5CF6',
    svg: `<svg viewBox="0 0 48 48" width="100%" height="100%">
      <defs>
        <linearGradient id="wizHat" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#7C3AED"/>
          <stop offset="100%" stop-color="#4C1D95"/>
        </linearGradient>
      </defs>
      <path d="M24 1 Q34 6 28 17 L12 17 Q18 7 24 1 Z" fill="url(#wizHat)"/>
      <ellipse cx="24" cy="17" rx="14" ry="3.5" fill="#5B21B6"/>
      <circle cx="24" cy="8" r="1.5" fill="#FDE047"/>
      <polygon points="21,12 22,14 24,14 22.5,15 23,17 21,15.5 19,17 19.5,15 18,14 20,14" fill="#FDE047"/>
      <circle cx="24" cy="21" r="7.5" fill="#FED7AA"/>
      <circle cx="21" cy="20" r="1.5" fill="#1E1B4B"/>
      <circle cx="27" cy="20" r="1.5" fill="#1E1B4B"/>
      <path d="M17 23 C14 27, 18 36, 24 36 C30 36, 34 27, 31 23 Z" fill="#F8FAFC"/>
      <path d="M13 34 L35 34 L33 46 L15 46 Z" fill="#6D28D9"/>
      <path d="M24 34 L24 46" stroke="#FDE047" stroke-width="1.8"/>
    </svg>`
  },
  ninja: {
    id: 'ninja',
    name: 'Siber Ninja',
    requiredLevel: 3,
    desc: 'Tuzakları sezen sessiz parti gölgesi.',
    color: '#1E293B',
    svg: `<svg viewBox="0 0 48 48" width="100%" height="100%">
      <path d="M34 16 Q44 14 41 24" stroke="#DC2626" stroke-width="3" fill="none" stroke-linecap="round"/>
      <path d="M34 18 Q42 20 38 28" stroke="#EF4444" stroke-width="2.5" fill="none" stroke-linecap="round"/>
      <rect x="14" y="10" width="20" height="19" rx="7" fill="#0F172A"/>
      <rect x="14" y="12" width="20" height="5" fill="#DC2626"/>
      <rect x="21" y="12.5" width="6" height="4" rx="1" fill="#94A3B8"/>
      <rect x="17" y="18" width="14" height="6" rx="2" fill="#FED7AA"/>
      <circle cx="20" cy="20.5" r="1.6" fill="#0F172A"/>
      <circle cx="19.4" cy="19.8" r="0.6" fill="#EF4444"/>
      <circle cx="28" cy="20.5" r="1.6" fill="#0F172A"/>
      <circle cx="27.4" cy="19.8" r="0.6" fill="#EF4444"/>
      <path d="M13 30 L35 30 L32 45 L16 45 Z" fill="#1E293B"/>
      <line x1="16" y1="31" x2="31" y2="44" stroke="#DC2626" stroke-width="2.5"/>
      <line x1="32" y1="31" x2="17" y2="44" stroke="#DC2626" stroke-width="2.5"/>
    </svg>`
  },
  robot: {
    id: 'robot',
    name: 'Mecha Bot-7',
    requiredLevel: 1,
    desc: 'Hesaplama gücü yüksek tatlı robot dost.',
    color: '#06B6D4',
    svg: `<svg viewBox="0 0 48 48" width="100%" height="100%">
      <line x1="24" y1="2" x2="24" y2="9" stroke="#06B6D4" stroke-width="2.5"/>
      <circle cx="24" cy="3" r="3" fill="#FACC15"/>
      <rect x="11" y="17" width="3" height="6" rx="1" fill="#94A3B8"/>
      <rect x="34" y="17" width="3" height="6" rx="1" fill="#94A3B8"/>
      <rect x="13" y="10" width="22" height="19" rx="5" fill="#64748B"/>
      <rect x="16" y="13" width="16" height="13" rx="3" fill="#0F172A"/>
      <path d="M18 19 Q20 16 22 19" stroke="#38BDF8" stroke-width="2" stroke-linecap="round" fill="none"/>
      <path d="M26 19 Q28 16 30 19" stroke="#38BDF8" stroke-width="2" stroke-linecap="round" fill="none"/>
      <line x1="21" y1="23" x2="27" y2="23" stroke="#22D3EE" stroke-width="1.5" stroke-linecap="round"/>
      <path d="M14 30 L34 30 L32 45 L16 45 Z" fill="#475569"/>
      <rect x="19" y="33" width="10" height="9" rx="2" fill="#1E293B"/>
      <circle cx="22" cy="37" r="1.5" fill="#EF4444"/>
      <circle cx="26" cy="37" r="1.5" fill="#10B981"/>
    </svg>`
  },
  detective: {
    id: 'detective',
    name: 'Dedektif Holmes',
    requiredLevel: 2,
    desc: 'Hileleri ve gizemleri anında çözen dedektif.',
    color: '#78350F',
    svg: `<svg viewBox="0 0 48 48" width="100%" height="100%">
      <path d="M12 16 Q24 5 36 16 Z" fill="#92400E"/>
      <ellipse cx="24" cy="16" rx="15" ry="3.5" fill="#78350F"/>
      <path d="M23 7 Q24 5 25 7" stroke="#FEF3C7" stroke-width="2"/>
      <rect x="15" y="16" width="18" height="15" rx="5" fill="#FED7AA"/>
      <circle cx="19" cy="22" r="2" fill="#1E293B"/>
      <circle cx="18.3" cy="21.3" r="0.7" fill="#FFFFFF"/>
      <circle cx="28" cy="22" r="3.2" fill="none" stroke="#F59E0B" stroke-width="1.8"/>
      <circle cx="28" cy="22" r="1.8" fill="#1E293B"/>
      <line x1="31" y1="23" x2="35" y2="29" stroke="#F59E0B" stroke-width="1.2"/>
      <path d="M21 27 Q24 29 26 26" stroke="#78350F" stroke-width="1.5" fill="none" stroke-linecap="round"/>
      <path d="M12 32 L36 32 L33 46 L15 46 Z" fill="#B45309"/>
      <polygon points="20,32 24,37 28,32" fill="#78350F"/>
    </svg>`
  },
  panda: {
    id: 'panda',
    name: 'Parti Pandası',
    requiredLevel: 3,
    desc: 'Altın toplamayı seven sevimli dev panda.',
    color: '#F97316',
    svg: `<svg viewBox="0 0 48 48" width="100%" height="100%">
      <circle cx="14" cy="11" r="5" fill="#0F172A"/>
      <circle cx="34" cy="11" r="5" fill="#0F172A"/>
      <circle cx="24" cy="21" r="12" fill="#F8FAFC"/>
      <ellipse cx="18" cy="20" rx="3.5" ry="4" fill="#0F172A"/>
      <circle cx="17.5" cy="19.2" r="1.3" fill="#FFFFFF"/>
      <ellipse cx="30" cy="20" rx="3.5" ry="4" fill="#0F172A"/>
      <circle cx="29.5" cy="19.2" r="1.3" fill="#FFFFFF"/>
      <ellipse cx="24" cy="25" rx="2" ry="1.4" fill="#0F172A"/>
      <path d="M22 27 Q24 29 26 27" stroke="#0F172A" stroke-width="1.5" fill="none"/>
      <ellipse cx="13" cy="24" rx="2" ry="1.2" fill="#FDA4AF" opacity="0.6"/>
      <ellipse cx="35" cy="24" rx="2" ry="1.2" fill="#FDA4AF" opacity="0.6"/>
      <polygon points="21,32 27,32 24,35" fill="#EF4444"/>
      <polygon points="21,38 27,38 24,35" fill="#EF4444"/>
      <circle cx="24" cy="35" r="1.5" fill="#FDE047"/>
      <path d="M14 34 L34 34 L32 46 L16 46 Z" fill="#EA580C"/>
    </svg>`
  },
  king: {
    id: 'king',
    name: 'Altın Lego Kralı',
    requiredLevel: 4,
    desc: 'Parti Dünyasının mutlak altın hükümdarı!',
    color: '#EAB308',
    svg: `<svg viewBox="0 0 48 48" width="100%" height="100%">
      <polygon points="12,14 10,4 17,9 24,2 31,9 38,4 36,14" fill="#FACC15" stroke="#CA8A04" stroke-width="1.2"/>
      <circle cx="24" cy="3" r="2" fill="#EF4444"/>
      <circle cx="10" cy="5" r="1.5" fill="#3B82F6"/>
      <circle cx="38" cy="5" r="1.5" fill="#10B981"/>
      <rect x="15" y="14" width="18" height="15" rx="5" fill="#FDE047"/>
      <circle cx="20" cy="20" r="2" fill="#1E293B"/>
      <circle cx="19.3" cy="19.3" r="0.8" fill="#FFFFFF"/>
      <circle cx="28" cy="20" r="2" fill="#1E293B"/>
      <circle cx="27.3" cy="19.3" r="0.8" fill="#FFFFFF"/>
      <path d="M21 24 Q24 28 27 24" stroke="#1E293B" stroke-width="1.8" stroke-linecap="round" fill="none"/>
      <path d="M11 30 L37 30 L34 46 L14 46 Z" fill="#9333EA"/>
      <rect x="17" y="30" width="14" height="16" fill="#F8FAFC"/>
      <circle cx="24" cy="34" r="1.5" fill="#0F172A"/>
      <circle cx="24" cy="40" r="1.5" fill="#0F172A"/>
    </svg>`
  }
};

const HAT_DEFS = {
  none: { id: 'none', name: 'Şapkasız / Sade', requiredLevel: 1, icon: '🙂' },
  party_hat: { id: 'party_hat', name: 'Parti Külahı', requiredLevel: 1, icon: '🎉' },
  crown: { id: 'crown', name: 'Kraliyet Tacı', requiredLevel: 1, icon: '👑' },
  headphones: { id: 'headphones', name: 'DJ Kulaklığı', requiredLevel: 1, icon: '🎧' },
  flower_crown: { id: 'flower_crown', name: 'Çiçek Tacı', requiredLevel: 1, icon: '🌸' },
  pirate: { id: 'pirate', name: 'Korsan Kaptanı', requiredLevel: 2, icon: '🏴‍☠️' },
  wizard: { id: 'wizard', name: 'Büyücü Külahı', requiredLevel: 2, icon: '🧙' },
  cat_ears: { id: 'cat_ears', name: 'Kedi Kulakları', requiredLevel: 2, icon: '🐱' },
  visor: { id: 'visor', name: 'Siber Vizör', requiredLevel: 3, icon: '🕶️' },
  detective: { id: 'detective', name: 'Dedektif Fötrü', requiredLevel: 3, icon: '🕵️' },
  viking: { id: 'viking', name: 'Viking Miğferi', requiredLevel: 4, icon: '⚔️' },
  halo: { id: 'halo', name: 'Melek Halesi', requiredLevel: 4, icon: '😇' }
};

const COLOR_PRESETS = [
  { id: 'blue', hex: '#3B82F6', name: 'Kobalt Mavi' },
  { id: 'red', hex: '#EF4444', name: 'Alev Kırmızı' },
  { id: 'green', hex: '#10B981', name: 'Zümrüt Yeşil' },
  { id: 'amber', hex: '#F59E0B', name: 'Güneş Sarısı' },
  { id: 'purple', hex: '#8B5CF6', name: 'Mistik Mor' },
  { id: 'pink', hex: '#EC4899', name: 'Neon Pembe' },
  { id: 'cyan', hex: '#06B6D4', name: 'Siber Turkuaz' },
  { id: 'dark', hex: '#1E293B', name: 'Gece Grisi' }
];

const DICE_SKINS = {
  default: { id: 'default', name: 'Klasik Beyaz', requiredLevel: 1, color: '#FFFFFF', dotColor: '#1E293B', border: '#CBD5E1' },
  emerald: { id: 'emerald', name: 'Zümrüt Yeşil', requiredLevel: 3, color: '#10B981', dotColor: '#FFFFFF', border: '#059669' },
  ruby: { id: 'ruby', name: 'Alev Kırmızı', requiredLevel: 6, color: '#EF4444', dotColor: '#FEF08A', border: '#B91C1C' },
  neon: { id: 'neon', name: 'Siber Neon', requiredLevel: 10, color: '#06B6D4', dotColor: '#082F49', border: '#0E7490' },
  galaxy: { id: 'galaxy', name: 'Kozmik Galaksi', requiredLevel: 16, color: '#8B5CF6', dotColor: '#FDF4FF', border: '#6D28D9' },
  gold: { id: 'gold', name: 'Saf Altın Zar', requiredLevel: 22, color: '#FACC15', dotColor: '#78350F', border: '#CA8A04' }
};

const TITLES = [
  { id: 't1', title: 'Acemi Gezgin', title_en: 'Novice Explorer', title_de: 'Neuer Entdecker', title_es: 'Explorador Novato', title_fr: 'Explorateur Novice', level: 1 },
  { id: 't2', title: 'Şanslı Tilki', title_en: 'Lucky Fox', title_de: 'Glücksfuchs', title_es: 'Zorro Afortunado', title_fr: 'Renard Chanceux', level: 3 },
  { id: 't3', title: 'Zar Cambazı', title_en: 'Dice Acrobat', title_de: 'Würfel-Akrobat', title_es: 'Acróbata del Dado', title_fr: 'Acrobate du Dé', level: 6 },
  { id: 't4', title: 'Tuzak Bükücü', title_en: 'Trap Bender', title_de: 'Fallenmeister', title_es: 'Domador de Trampas', title_fr: 'Maître des Pièges', level: 10 },
  { id: 't5', title: 'Yıldız Avcısı', title_en: 'Star Hunter', title_de: 'Sternenjäger', title_es: 'Cazador de Estrellas', title_fr: 'Chasseur d\'Étoiles', level: 15 },
  { id: 't6', title: 'Parti Efsanesi', title_en: 'Party Legend', title_de: 'Party-Legende', title_es: 'Leyenda de la Fiesta', title_fr: 'Légende de la Fête', level: 22 }
];

const EMOTE_DEFS = {
  laugh: { id: 'laugh', char: '😂', name: 'Kahkaha', level: 1 },
  cool: { id: 'cool', char: '😎', name: 'Havalı', level: 1 },
  shock: { id: 'shock', char: '😱', name: 'Şok', level: 1 },
  party: { id: 'party', char: '🥳', name: 'Parti', level: 2 },
  fire: { id: 'fire', char: '🔥', name: 'Alev', level: 3 },
  skull: { id: 'skull', char: '💀', name: 'GG', level: 5 },
  rocket: { id: 'rocket', char: '🚀', name: 'Roket', level: 8 },
  crown: { id: 'crown', char: '👑', name: 'Kral', level: 12 }
};

class ProgressionManager {
  constructor() {
    this.storageKey = 'partycraft_player_profile';
    this.profile = this.loadProfile();
  }

  loadProfile() {
    try {
      const data = localStorage.getItem(this.storageKey);
      if (data) {
        const parsed = JSON.parse(data);
        if (!parsed.hat) parsed.hat = 'none';
        if (!parsed.color) parsed.color = '#3B82F6';
        return parsed;
      }
    } catch (e) {
      console.warn('Storage read error:', e);
    }

    // Default Profile
    const defaultProfile = {
      sessionId: 'sess_' + Math.random().toString(36).substr(2, 9),
      name: 'Oyuncu_' + Math.floor(Math.random() * 899 + 100),
      level: 1,
      xp: 0,
      avatar: 'builder',
      hat: 'none',
      color: '#3B82F6',
      diceSkin: 'default',
      title: 'Acemi Gezgin',
      stats: {
        gamesPlayed: 0,
        gamesWon: 0,
        starsCollected: 0,
        coinsEarned: 0,
        minigamesWon: 0
      }
    };
    this.saveProfile(defaultProfile);
    return defaultProfile;
  }

  saveProfile(profile = this.profile) {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(profile));
    } catch (e) {
      console.warn('Storage save error:', e);
    }
  }

  getXpRequired(level = this.profile.level) {
    return level * 140;
  }

  addXp(amount) {
    this.profile.xp += amount;
    let leveledUp = false;
    let oldLevel = this.profile.level;

    while (this.profile.xp >= this.getXpRequired(this.profile.level)) {
      this.profile.xp -= this.getXpRequired(this.profile.level);
      this.profile.level++;
      leveledUp = true;
    }

    this.saveProfile();
    return {
      leveledUp,
      oldLevel,
      newLevel: this.profile.level,
      currentXp: this.profile.xp,
      neededXp: this.getXpRequired(this.profile.level)
    };
  }

  setAvatar(avatarId) {
    const def = AVATAR_DEFS[avatarId];
    if (def && this.profile.level >= def.requiredLevel) {
      this.profile.avatar = avatarId;
      this.saveProfile();
      return true;
    }
    return false;
  }

  setHat(hatId) {
    const def = HAT_DEFS[hatId];
    if (def && this.profile.level >= def.requiredLevel) {
      this.profile.hat = hatId;
      this.saveProfile();
      return true;
    }
    return false;
  }

  setColor(hexColor) {
    if (hexColor && /^#[0-9A-Fa-f]{6}$/.test(hexColor)) {
      this.profile.color = hexColor;
      this.saveProfile();
      return true;
    }
    return false;
  }

  getUnlockedHats() {
    return Object.values(HAT_DEFS).filter(h => this.profile.level >= h.requiredLevel);
  }

  setDiceSkin(skinId) {
    const def = DICE_SKINS[skinId];
    if (def && this.profile.level >= def.requiredLevel) {
      this.profile.diceSkin = skinId;
      this.saveProfile();
      return true;
    }
    return false;
  }

  setTitle(titleStr) {
    this.profile.title = titleStr;
    this.saveProfile();
  }

  setName(newName) {
    if (newName && newName.trim().length > 0) {
      this.profile.name = newName.trim().substr(0, 16);
      this.saveProfile();
    }
  }

  getUnlockedAvatars() {
    return Object.values(AVATAR_DEFS).filter(a => this.profile.level >= a.requiredLevel);
  }

  getUnlockedDiceSkins() {
    return Object.values(DICE_SKINS).filter(d => this.profile.level >= d.requiredLevel);
  }

  getUnlockedTitles() {
    return TITLES.filter(t => this.profile.level >= t.level);
  }

  getDisplayTitle(titleStr) {
    const tStr = titleStr || this.profile.title || 'Acemi Gezgin';
    const lang = (window.i18n && window.i18n.getLang()) ? window.i18n.getLang() : 'tr';
    const match = TITLES.find(t => t.title === tStr || t.title_en === tStr || t.title_de === tStr || t.title_es === tStr || t.title_fr === tStr);
    if (match) {
      if (lang === 'en') return match.title_en;
      if (lang === 'de') return match.title_de;
      if (lang === 'es') return match.title_es;
      if (lang === 'fr') return match.title_fr;
      return match.title;
    }
    return tStr;
  }

  getUnlockedEmotes() {
    return Object.values(EMOTE_DEFS).filter(e => this.profile.level >= e.level);
  }
}

const PlayerProgression = new ProgressionManager();


/* =================== 5. BOARD MAP RENDERER =================== */
/**
 * Wonder Board Map Engine - Ultra-Crisp High-DPI Edition
 * Features 3 Interactive Maps (Tropics, Cyber Station, Candy Valley),
 * High-DPI auto-scaling, Anti-Overlap Token Cluster Layout & Interactive Tile Inspector.
 */

const MAP_THEMES = {
  istanbul: {
    id: 'istanbul',
    name: 'İstanbul - Boğazın İncisi',
    desc: 'Tarihi yarımada, Galata Kulesi, Boğaz Köprüsü ve Ayasofya!',
    bgColor: '#0B0F19',
    islandBase: '#1E293B',
    roadBase: '#334155',
    roadBorder: '#0284C7',
    landmark: { name: 'Kız Kulesi & Vapur', x: 880, y: 520, icon: '🏰' }
  },
  tokyo: {
    id: 'tokyo',
    name: 'Tokyo - Neon Şehri',
    desc: 'Shibuya neonları, Tokyo Kulesi, Skytree ve Torii tapınakları!',
    bgColor: '#060714',
    islandBase: '#0F172A',
    roadBase: '#1E1B4B',
    roadBorder: '#06B6D4',
    landmark: { name: 'Tokyo Kulesi & Tapınak', x: 880, y: 520, icon: '🗼' }
  },
  paris: {
    id: 'paris',
    name: 'Paris - Işıklar Şehri',
    desc: 'Eyfel Kulesi, Zafer Takı, Sen Nehri ve Louvre Piramidi!',
    bgColor: '#090D1A',
    islandBase: '#14532D',
    roadBase: '#1E293B',
    roadBorder: '#38BDF8',
    landmark: { name: 'Eyfel & Louvre', x: 880, y: 520, icon: '🗼' }
  },
  newyork: {
    id: 'newyork',
    name: 'New York - Büyük Elma',
    desc: 'Empire State, Özgürlük Heykeli, Brooklyn Köprüsü ve sarı taksiler!',
    bgColor: '#05070F',
    islandBase: '#1E293B',
    roadBase: '#334155',
    roadBorder: '#F59E0B',
    landmark: { name: 'Özgürlük Heykeli', x: 880, y: 520, icon: '🗽' }
  },
  tropics: {
    id: 'tropics',
    aliasOf: 'istanbul',
    name: 'İstanbul - Boğazın İncisi',
    desc: 'Tarihi yarımada, Galata Kulesi, Boğaz Köprüsü ve Ayasofya!',
    bgColor: '#0F172A',
    islandBase: '#FEF3C7',
    roadBase: '#E2E8F0',
    roadBorder: '#0284C7',
    landmark: { name: 'Kız Kulesi & Vapur', x: 880, y: 520, icon: '🏰' }
  },
  cyber: {
    id: 'cyber',
    aliasOf: 'tokyo',
    name: 'Tokyo - Neon Şehri',
    desc: 'Shibuya neonları, Tokyo Kulesi, Skytree ve Torii tapınakları!',
    bgColor: '#090A1A',
    islandBase: '#1E1B4B',
    roadBase: '#1E293B',
    roadBorder: '#06B6D4',
    landmark: { name: 'Tokyo Kulesi & Tapınak', x: 880, y: 520, icon: '🗼' }
  },
  candy: {
    id: 'candy',
    aliasOf: 'paris',
    name: 'Paris - Işıklar Şehri',
    desc: 'Eyfel Kulesi, Zafer Takı, Sen Nehri ve Louvre Piramidi!',
    bgColor: '#1E1B4B',
    islandBase: '#FCE7F3',
    roadBase: '#FFE4E6',
    roadBorder: '#EC4899',
    landmark: { name: 'Eyfel & Louvre', x: 880, y: 520, icon: '🗼' }
  }
};

const BOARD_TILES = [
  { id: 0, type: 'start', title: 'Başlangıç', desc: '+10 Altın Geçiş Bonusu!', icon: 'flag', color: '#10B981' },
  { id: 1, type: 'coin', amount: 4, title: 'Altın Karosu', desc: '+4 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
  { id: 2, type: 'mystery', title: 'Şans Kutusu', desc: 'Sürpriz bir olay seni bekliyor!', icon: 'sparkles', color: '#8B5CF6' },
  { id: 3, type: 'coin', amount: 5, title: 'Altın Karosu', desc: '+5 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
  { id: 4, type: 'trap', penalty: 4, title: 'Tuzak Karosu', desc: '-4 Altın kaybettin!', icon: 'flame', color: '#EF4444' },
  { id: 5, type: 'shop', title: 'Eşya Dükkanı', desc: 'Güçlü eşyalar satın al!', icon: 'shopping-bag', color: '#F59E0B' },
  { id: 6, type: 'coin', amount: 6, title: 'Büyük Altın', desc: '+6 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
  { id: 7, type: 'star', title: 'Yıldız Kaidesi', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
  { id: 8, type: 'warp', target: 16, title: 'Hava Geçidi', desc: '16. karoya ışınlan!', icon: 'zap', color: '#06B6D4' },
  { id: 9, type: 'coin', amount: 4, title: 'Altın Karosu', desc: '+4 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
  { id: 10, type: 'duel', title: 'Düello Meydanı', desc: 'Rakipten altın kap!', icon: 'swords', color: '#EC4899' },
  { id: 11, type: 'tax', title: 'Korsan / Vergi', desc: '%25 Altın cezası en fakir oyuncuya dağıtılır!', icon: 'coins', color: '#E11D48' },
  { id: 12, type: 'mystery', title: 'Görünmez Sandık', desc: 'Rulet çarkını çevir!', icon: 'sparkles', color: '#8B5CF6' },
  { id: 13, type: 'coin', amount: 7, title: 'Zengin Kuyu', desc: '+7 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
  { id: 14, type: 'shop', title: 'Gezgin Satıcı', desc: 'Nadir taktik eşyaları!', icon: 'shopping-bag', color: '#F59E0B' },
  { id: 15, type: 'star', title: 'Yıldız Kaidesi', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
  { id: 16, type: 'coin', amount: 4, title: 'Altın Karosu', desc: '+4 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
  { id: 17, type: 'jail', title: 'Kodes / Hapis', desc: '1 tur kilitli kal veya 5 altın kefalet öde!', icon: 'shield', color: '#DC2626' },
  { id: 18, type: 'mystery', title: 'Sihirli Çark', desc: 'Büyük ödüller veya sürprizler!', icon: 'sparkles', color: '#8B5CF6' },
  { id: 19, type: 'coin', amount: 5, title: 'Altın Karosu', desc: '+5 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
  { id: 20, type: 'duel', title: 'Altın Arenası', desc: 'Rakiplerle düello!', icon: 'swords', color: '#EC4899' },
  { id: 21, type: 'freeze', title: 'Buz Tuzağı', desc: 'Donma etkisi! 1 tur eşya kullanamazsın!', icon: 'zap', color: '#0284C7' },
  { id: 22, type: 'coin', amount: 6, title: 'Altın Karosu', desc: '+6 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
  { id: 23, type: 'star', title: 'Yıldız Kaidesi', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
  { id: 24, type: 'reverse', title: 'Ters Yön Laneti', desc: 'Pusula bozuldu! Sonraki zarda ters yöne yürü!', icon: 'undo-2', color: '#9333EA' },
  { id: 25, type: 'mystery', title: 'Hazine Sandığı', desc: 'Şansını sına!', icon: 'sparkles', color: '#8B5CF6' },
  { id: 26, type: 'shop', title: 'Parti Marketi', desc: 'Zafer için eşya kuşan!', icon: 'shopping-bag', color: '#F59E0B' },
  { id: 27, type: 'coin', amount: 8, title: 'Dev Hazine', desc: '+8 Altın!', icon: 'coins', color: '#3B82F6' },
  { id: 28, type: 'trap', penalty: 4, title: 'Tuzak Karosu', desc: '-4 Altın kaybettin!', icon: 'flame', color: '#EF4444' },
  { id: 29, type: 'duel', title: 'Büyük Hesaplaşma', desc: 'Liderden altın arakla!', icon: 'swords', color: '#EC4899' },
  { id: 30, type: 'coin', amount: 5, title: 'Altın Karosu', desc: '+5 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
  { id: 31, type: 'star', title: 'Yıldız Kaidesi', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' }
];

const SHOP_ITEMS = [
  { id: 'double_dice', name: 'Çift Zar', cost: 7, desc: 'Bir sonraki turda 2 zar birden atarsın (2-12 adım).', icon: 'dices' },
  { id: 'rocket', name: 'Süper Roket', cost: 12, desc: 'Hedefine doğru direkt 7 adım uçar!', icon: 'rocket' },
  { id: 'shield', name: 'Manyetik Kalkan', cost: 8, desc: 'Tuzaklara ve altın çalma hamlelerine karşı 2 tur korur.', icon: 'shield' },
  { id: 'magnet', name: 'Altın Mıknatısı', cost: 10, desc: 'Bütün rakiplerden 4\'er altın çeker!', icon: 'magnet' },
  { id: 'banana', name: 'Muz Kabuğu', cost: 5, desc: 'Bulunduğun karoya tuzak kur; üstüne basan 3 adım geri kayar!', icon: 'banana' },
  { id: 'swap_wand', name: 'Takas Asası', cost: 15, desc: 'İstediğin bir rakiple haritadaki yerlerini takas et!', icon: 'refresh-cw' },
  { id: 'ghost_cloak', name: 'Hayalet Pelerin', cost: 9, desc: '2 tur boyunca hiçbir tuzaktan veya cezadan etkilenmezsin!', icon: 'shield' },
  { id: 'lucky_die', name: 'Şanslı Altın Zar', cost: 14, desc: 'Sıradaki zarda 1-6 arasında istediğin sayıyı sen seçersin!', icon: 'dices' }
];

class BoardRenderer {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas ? this.canvas.getContext('2d') : null;
    
    // Virtual resolution (game coordinates)
    this.virtualWidth = 1100;
    this.virtualHeight = 760;
    this.dpr = 1;
    this.baseScale = 1;
    this.offsetX = 0;
    this.offsetY = 0;

    this.tileCoords = this.calculateTilePositions();
    this.playerOffsets = {}; // playerId -> { currentX, currentY, hopOffset }
    this.animationFrame = null;
    this.starPulse = 0;
    this.autoFollow = true;
    this.selectedTileIndex = null;
    this.activeTheme = 'istanbul';

    // Interactive Landmark state
    this.landmarkPulse = 0;
    this.particles = [];

    // Viewport pan & zoom (Center-origin tracking)
    this.cameraFocus = { x: 550, y: 380 };
    this.camera = { dragX: 0, dragY: 0, zoom: 1 };
    this.isDragging = false;
    this.dragStart = { x: 0, y: 0 };
    this.dragDistance = 0;

    this.resizeCanvas();
    this.bindEvents();
    this.startLoop();
  }

  setTheme(themeId) {
    if (MAP_THEMES[themeId]) {
      this.activeTheme = MAP_THEMES[themeId].aliasOf || themeId;
    }
  }

  resizeCanvas() {
    if (!this.canvas) return;
    const parent = this.canvas.parentElement;
    const rect = parent.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5); // High-DPI sharpness without lag

    this.dpr = dpr;
    this.canvas.width = Math.round(rect.width * dpr);
    this.canvas.height = Math.round(rect.height * dpr);
    this.canvas.style.width = `${rect.width}px`;
    this.canvas.style.height = `${rect.height}px`;

    // Uniform fit scale
    const scaleX = rect.width / this.virtualWidth;
    const scaleY = rect.height / this.virtualHeight;
    this.baseScale = Math.min(scaleX, scaleY);
    this.offsetX = (rect.width - (this.virtualWidth * this.baseScale)) / 2;
    this.offsetY = (rect.height - (this.virtualHeight * this.baseScale)) / 2;
  }

  calculateTilePositions() {
    // Dynamic, organic, fluid racetrack (Mario Party / Dokapon style)
    // Curving gracefully across scenic bays, bridges, coastal promenades and skyline heights
    return [
      { x: 206, y: 492 }, // 0: Start Meydanı (Liman Başlangıç)
      { x: 267, y: 530 }, // 1: Sahil Kordonu
      { x: 329, y: 564 }, // 2: Balıkçı İskelesi
      { x: 395, y: 592 }, // 3: Çeşme Meydanı
      { x: 463, y: 613 }, // 4: Boğaz Yolu
      { x: 533, y: 626 }, // 5: Marina Kordonu
      { x: 604, y: 629 }, // 6: Kıyı Parkı
      { x: 675, y: 623 }, // 7: Star Pedestal
      { x: 745, y: 608 }, // 8: Doğu Sahili
      { x: 813, y: 586 }, // 9: Hisar Yokuşu
      { x: 877, y: 555 }, // 10: Düello Meydanı
      { x: 937, y: 517 }, // 11: Köprü Yaklaşımı
      { x: 990, y: 469 }, // 12: Şans Kemeri
      { x: 1028, y: 409 }, // 13: Seyir Tepesi
      { x: 1034, y: 339 }, // 14: Kule Yolu
      { x: 1000, y: 277 }, // 15: Star Pedestal
      { x: 944, y: 235 }, // 16: Hava Geçidi
      { x: 878, y: 207 }, // 17: Kodes & Hisar
      { x: 809, y: 191 }, // 18: Sihirli Çark
      { x: 738, y: 182 }, // 19: Panorama Terası
      { x: 667, y: 180 }, // 20: Çamlıca Zirvesi
      { x: 595, y: 179 }, // 21: Donma Vadisi
      { x: 524, y: 177 }, // 22: Saray Sırtı
      { x: 453, y: 174 }, // 23: Star Pedestal
      { x: 381, y: 174 }, // 24: Ters Rüzgar Tepesi
      { x: 310, y: 179 }, // 25: Sandık Bahçesi
      { x: 241, y: 194 }, // 26: Kapalıçarşı Kemeri
      { x: 174, y: 220 }, // 27: Hazine Meydanı
      { x: 118, y: 263 }, // 28: Dikenli Vadi
      { x: 88, y: 326 },  // 29: Büyük Arena
      { x: 104, y: 394 }, // 30: Gülhane Yolu
      { x: 149, y: 449 }  // 31: Star Kaidesi
    ];
  }

  bindEvents() {
    if (!this.canvas) return;

    window.addEventListener('resize', () => this.resizeCanvas());

    // Mouse Controls (Center-origin offset)
    this.canvas.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.dragDistance = 0;
      this.dragStart = { x: e.clientX - this.camera.dragX, y: e.clientY - this.camera.dragY };
    });

    window.addEventListener('mousemove', (e) => {
      if (this.isDragging) {
        const dx = e.clientX - (this.dragStart.x + this.camera.dragX);
        const dy = e.clientY - (this.dragStart.y + this.camera.dragY);
        this.dragDistance += Math.hypot(dx, dy);
        this.camera.dragX = e.clientX - this.dragStart.x;
        this.camera.dragY = e.clientY - this.dragStart.y;
        this.autoFollow = false;
      }
    });

    window.addEventListener('mouseup', (e) => {
      if (this.isDragging && this.dragDistance < 6) {
        // Was a Click! (not a drag)
        this.handleCanvasClick(e.clientX, e.clientY);
      }
      this.isDragging = false;
    });

    // Touch Controls
    let touchStart = { x: 0, y: 0 };
    this.canvas.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) {
        this.isDragging = true;
        this.dragDistance = 0;
        touchStart = {
          x: e.touches[0].clientX - this.camera.dragX,
          y: e.touches[0].clientY - this.camera.dragY
        };
      }
    }, { passive: true });

    this.canvas.addEventListener('touchmove', (e) => {
      if (this.isDragging && e.touches.length === 1) {
        const dx = e.touches[0].clientX - (touchStart.x + this.camera.dragX);
        const dy = e.touches[0].clientY - (touchStart.y + this.camera.dragY);
        this.dragDistance += Math.hypot(dx, dy);
        this.camera.dragX = e.touches[0].clientX - touchStart.x;
        this.camera.dragY = e.touches[0].clientY - touchStart.y;
        this.autoFollow = false;
      }
    }, { passive: true });

    this.canvas.addEventListener('touchend', (e) => {
      if (this.isDragging && this.dragDistance < 10 && e.changedTouches.length === 1) {
        this.handleCanvasClick(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
      }
      this.isDragging = false;
    });

    // Mouse Wheel Zoom
    this.canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const zoomFactor = e.deltaY < 0 ? 1.08 : 0.92;
      this.camera.zoom = Math.max(0.65, Math.min(2.0, this.camera.zoom * zoomFactor));
    }, { passive: false });
  }

  handleCanvasClick(screenX, screenY) {
    const rect = this.canvas.getBoundingClientRect();
    const canvasX = (screenX - rect.left) * (this.canvas.width / rect.width) / this.dpr;
    const canvasY = (screenY - rect.top) * (this.canvas.height / rect.height) / this.dpr;
    const viewportW = this.canvas.width / this.dpr;
    const viewportH = this.canvas.height / this.dpr;

    const totalScale = this.baseScale * this.camera.zoom;
    const worldX = ((canvasX - (viewportW / 2 + this.camera.dragX)) / totalScale) + this.cameraFocus.x;
    const worldY = ((canvasY - (viewportH / 2 + this.camera.dragY)) / totalScale) + this.cameraFocus.y;

    // Check click on interactive Landmark
    const theme = MAP_THEMES[this.activeTheme] || MAP_THEMES.tropics;
    const lm = theme.landmark;
    if (Math.hypot(worldX - lm.x, worldY - lm.y) < 44) {
      this.triggerLandmarkInteraction(lm.x, lm.y);
      return;
    }

    // Check click on any tile
    for (let i = 0; i < this.tileCoords.length; i++) {
      const pos = this.tileCoords[i];
      if (Math.hypot(worldX - pos.x, worldY - pos.y) < 36) {
        this.selectTile(i);
        return;
      }
    }
  }

  triggerLandmarkInteraction(x, y) {
    AudioPlayer.playStarFanfare();
    // Burst particles
    for (let i = 0; i < 18; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 2 + Math.random() * 4;
      this.particles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 1.0,
        color: ['#FBBF24', '#38BDF8', '#EC4899', '#10B981'][Math.floor(Math.random() * 4)]
      });
    }
    const theme = MAP_THEMES[this.activeTheme] || MAP_THEMES.tropics;
    if (window.UI) UI.showToast(`✨ ${theme.landmark.name} ile etkileşime geçtin!`, 'info');
  }

  selectTile(index) {
    this.selectedTileIndex = index;
    AudioPlayer.playClick();

    const roomState = window.CURRENT_ROOM_STATE;
    const currentBoard = (roomState && roomState.board) ? roomState.board : BOARD_TILES;
    const tile = currentBoard[index];
    const playersOnTile = roomState ? roomState.players.filter(p => p.position === index) : [];
    
    // Distance from active player
    let stepsAway = 0;
    if (roomState && roomState.players) {
      const activeP = roomState.players[roomState.turnIndex];
      if (activeP) {
        stepsAway = (index - activeP.position + currentBoard.length) % currentBoard.length;
      }
    }

    if (window.UI && window.UI.showTileInspector) {
      window.UI.showTileInspector(tile, index, playersOnTile, stepsAway);
    }
  }

  focusPlayer(player) {
    if (!player || !this.autoFollow) return;
    const anim = this.playerHopState && this.playerHopState[player.id];
    const px = anim ? anim.displayX : (this.tileCoords[player.position] ? this.tileCoords[player.position].x : 550);
    const py = anim ? (anim.displayY + anim.hopArcY) : (this.tileCoords[player.position] ? this.tileCoords[player.position].y : 380);
    // Smooth lerp focus directly onto character token without drift
    this.cameraFocus.x += (px - this.cameraFocus.x) * 0.08;
    this.cameraFocus.y += (py - this.cameraFocus.y) * 0.08;
  }

  resetCamera() {
    this.camera = { dragX: 0, dragY: 0, zoom: 1 };
    this.cameraFocus = { x: 550, y: 380 };
    this.autoFollow = true;
  }

  zoomIn() {
    this.camera.zoom = Math.min(2.0, this.camera.zoom * 1.15);
  }

  zoomOut() {
    this.camera.zoom = Math.max(0.65, this.camera.zoom * 0.85);
  }

  startLoop() {
    const render = () => {
      this.draw();
      this.animationFrame = requestAnimationFrame(render);
    };
    this.animationFrame = requestAnimationFrame(render);
  }

  draw() {
    if (!this.ctx) return;
    const ctx = this.ctx;

    // Reset transform & clear
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    const viewportW = this.canvas.width / this.dpr;
    const viewportH = this.canvas.height / this.dpr;

    // Apply high-DPI
    ctx.scale(this.dpr, this.dpr);

    // Deep dark celestial background for entire viewport (No white borders on any screen!)
    const currentTheme = MAP_THEMES[this.activeTheme] || MAP_THEMES.istanbul;
    ctx.fillStyle = currentTheme.bgColor || '#0B0F19';
    ctx.fillRect(0, 0, viewportW, viewportH);

    // Apply Center-Origin Camera Projection (Camera stays 100% centered on character on zoom!)
    ctx.translate(viewportW / 2 + this.camera.dragX, viewportH / 2 + this.camera.dragY);
    const totalScale = this.baseScale * this.camera.zoom;
    ctx.scale(totalScale, totalScale);
    ctx.translate(-this.cameraFocus.x, -this.cameraFocus.y);

    // 1. Draw Environment Backdrop (City-specific)
    this.drawEnvironment(ctx);

    // 2. Draw Road Pathways with Directional Flow Chevrons
    this.drawPathways(ctx);

    // 3. Draw Projected Step Trajectory
    this.drawStepTrajectory(ctx);

    // 4. Draw 3D Stylized Platform Tiles
    const roomState = window.CURRENT_ROOM_STATE;
    const currentBoard = (roomState && roomState.board) ? roomState.board : BOARD_TILES;
    const activeStar = roomState ? roomState.activeStarTile : 7;
    const traps = roomState ? (roomState.trapsOnBoard || {}) : {};

    for (let i = 0; i < this.tileCoords.length; i++) {
      const tile = currentBoard[i] || BOARD_TILES[i];
      const pos = this.tileCoords[i];
      const isStarTile = (i === activeStar);
      const isSelected = (i === this.selectedTileIndex);
      const hasTrap = !!traps[i];
      this.drawPlatformTile(ctx, i, tile, pos, isStarTile, isSelected, hasTrap);
    }

    // 5. Draw Interactive Landmark
    this.drawLandmark(ctx);

    // 6. Draw Dramatic Turn Spotlight
    this.drawTurnSpotlight(ctx);

    // 7. Draw Particles
    this.drawParticles(ctx);

    // 8. Draw Spatially Separated, Non-Overlapping Player Tokens (Y-Sorted)
    if (roomState && roomState.players) {
      this.drawPlayerTokens(ctx, roomState.players);
      const activePlayer = roomState.players[roomState.turnIndex];
      if (activePlayer && this.autoFollow) {
        this.focusPlayer(activePlayer);
      }
    }

    this.starPulse += 0.04;
  }

  drawEnvironment(ctx) {
    const theme = MAP_THEMES[this.activeTheme] || MAP_THEMES.istanbul;
    ctx.save();

    // 1. Full-Canvas Thematic Sky & Atmosphere (Twinkling stars, sunset glow, clouds)
    this.drawSkyAndAtmosphere(ctx, theme);

    // 2. Full-Canvas Terrain & Water Bodies (Replaces the empty void with living diorama)
    this.drawWaterAndTerrain(ctx, theme);

    // 3. Iconic City Architecture & Living Scenery
    const themeKey = theme.aliasOf || this.activeTheme;
    if (themeKey === 'tokyo') {
      this.drawTokyoEnvironment(ctx);
    } else if (themeKey === 'paris') {
      this.drawParisEnvironment(ctx);
    } else if (themeKey === 'newyork') {
      this.drawNewYorkEnvironment(ctx);
    } else {
      this.drawIstanbulEnvironment(ctx);
    }

    // 4. Ambient Street Lamps, Animated Vehicles & Foliage (Eliminates any bare canvas)
    this.drawAmbientWorldDetails(ctx, theme);

    ctx.restore();
  }

  /* ----------------------------------------------------
     ATMOSPHERIC SKY & HORIZON (Full 1100x760 Canvas)
     ---------------------------------------------------- */
  drawSkyAndAtmosphere(ctx, theme) {
    const themeKey = theme.aliasOf || this.activeTheme;

    // Atmospheric Gradient Backdrop
    const skyGrad = ctx.createLinearGradient(0, 0, 0, 760);
    if (themeKey === 'tokyo') {
      skyGrad.addColorStop(0, '#060714');
      skyGrad.addColorStop(0.35, '#0F1035');
      skyGrad.addColorStop(0.7, '#1E1B4B');
      skyGrad.addColorStop(1, '#090A1A');
    } else if (themeKey === 'paris') {
      skyGrad.addColorStop(0, '#1E1B4B');
      skyGrad.addColorStop(0.4, '#4C1D95');
      skyGrad.addColorStop(0.75, '#831843');
      skyGrad.addColorStop(1, '#3B0764');
    } else if (themeKey === 'newyork') {
      skyGrad.addColorStop(0, '#030712');
      skyGrad.addColorStop(0.4, '#0F172A');
      skyGrad.addColorStop(0.75, '#1E293B');
      skyGrad.addColorStop(1, '#111827');
    } else {
      // Istanbul Twilight
      skyGrad.addColorStop(0, '#0A192F');
      skyGrad.addColorStop(0.35, '#0F2B48');
      skyGrad.addColorStop(0.65, '#1E3A8A');
      skyGrad.addColorStop(0.85, '#D97706');
      skyGrad.addColorStop(1, '#78350F');
    }

    ctx.fillStyle = skyGrad;
    ctx.fillRect(-2500, -2500, 6000, 6000);

    // Twinkling Stars in upper sky
    ctx.save();
    const starCoords = [
      { x: 90, y: 35, s: 1.6 }, { x: 210, y: 55, s: 1.2 }, { x: 330, y: 30, s: 2.0 },
      { x: 470, y: 50, s: 1.4 }, { x: 590, y: 25, s: 1.8 }, { x: 710, y: 45, s: 1.3 },
      { x: 840, y: 30, s: 2.2 }, { x: 970, y: 60, s: 1.5 }, { x: 1040, y: 40, s: 1.7 },
      { x: 150, y: 95, s: 1.3 }, { x: 380, y: 110, s: 1.1 }, { x: 670, y: 90, s: 1.6 },
      { x: 890, y: 105, s: 1.4 }
    ];
    starCoords.forEach((st, i) => {
      const alpha = 0.35 + 0.65 * Math.abs(Math.sin(this.starPulse * 2.2 + i * 1.5));
      ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
      ctx.beginPath();
      ctx.arc(st.x, st.y, st.s, 0, Math.PI * 2);
      ctx.fill();
    });

    // Glowing Celestial Body
    if (themeKey === 'tokyo') {
      ctx.save();
      ctx.fillStyle = '#F43F5E';
      ctx.shadowColor = '#F43F5E';
      ctx.shadowBlur = 25;
      ctx.beginPath();
      ctx.arc(930, 85, 24, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(244, 63, 94, 0.2)';
      ctx.beginPath();
      ctx.arc(930, 85, 38, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    } else {
      ctx.save();
      ctx.translate(140, 75);
      ctx.fillStyle = '#FEF08A';
      ctx.shadowColor = '#FDE047';
      ctx.shadowBlur = 18;
      ctx.beginPath();
      ctx.arc(0, 0, 16, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.arc(6, -4, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Drifting Stylized Sunset Clouds
    ctx.fillStyle = (themeKey === 'paris') ? 'rgba(252, 231, 243, 0.25)' : 'rgba(255, 255, 255, 0.14)';
    const cloudOffsets = [0, 380, 760, 1140];
    cloudOffsets.forEach((co, idx) => {
      const cx = ((this.starPulse * 14 + co) % 1320) - 120;
      const cy = 45 + (idx % 2) * 35;
      ctx.beginPath();
      ctx.arc(cx, cy, 20, 0, Math.PI * 2);
      ctx.arc(cx + 20, cy - 8, 26, 0, Math.PI * 2);
      ctx.arc(cx + 44, cy, 18, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();
  }

  /* ----------------------------------------------------
     BASE WATERWAYS & 3D FLOATING DIORAMA TERRAIN
     ---------------------------------------------------- */
  drawWaterAndTerrain(ctx, theme) {
    const themeKey = theme.aliasOf || this.activeTheme;
    ctx.save();

    // 1. Surrounding Atmospheric Ocean / Void Base
    const oceanGrad = ctx.createRadialGradient(550, 390, 200, 550, 390, 950);
    if (themeKey === 'tokyo') {
      oceanGrad.addColorStop(0, '#090D1E');
      oceanGrad.addColorStop(0.6, '#050711');
      oceanGrad.addColorStop(1, '#020308');
    } else if (themeKey === 'paris') {
      oceanGrad.addColorStop(0, '#0D1527');
      oceanGrad.addColorStop(0.6, '#080C18');
      oceanGrad.addColorStop(1, '#03050B');
    } else if (themeKey === 'newyork') {
      oceanGrad.addColorStop(0, '#0B132B');
      oceanGrad.addColorStop(0.6, '#060B18');
      oceanGrad.addColorStop(1, '#020409');
    } else {
      oceanGrad.addColorStop(0, '#0C2340');
      oceanGrad.addColorStop(0.6, '#081729');
      oceanGrad.addColorStop(1, '#030810');
    }
    ctx.fillStyle = oceanGrad;
    ctx.fillRect(-2500, -2500, 6000, 6000);

    // 2. Volumetric Drop Shadow under the Floating Diorama Island
    ctx.beginPath();
    ctx.ellipse(550, 440, 540, 310, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
    ctx.fill();

    // 3. 3D Floating Island Cliff Underside (Layered Bedrock Strata)
    ctx.beginPath();
    ctx.ellipse(550, 422, 528, 305, 0, 0, Math.PI); // bottom half of lower rim
    ctx.ellipse(550, 392, 528, 305, 0, Math.PI, 0, true); // bottom half of upper rim reversed
    ctx.closePath();
    const cliffGrad = ctx.createLinearGradient(0, 390, 0, 428);
    cliffGrad.addColorStop(0, '#1E293B');
    cliffGrad.addColorStop(0.5, '#0F172A');
    cliffGrad.addColorStop(1, '#020617');
    ctx.fillStyle = cliffGrad;
    ctx.fill();

    // Cliff vertical rock strata ribs
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1.5;
    for (let angle = 0.2; angle < Math.PI - 0.2; angle += 0.14) {
      const rx = 528 * Math.cos(angle);
      const ry1 = 392 + 305 * Math.sin(angle);
      const ry2 = 422 + 305 * Math.sin(angle);
      ctx.beginPath();
      ctx.moveTo(550 + rx, ry1);
      ctx.lineTo(550 + rx, ry2);
      ctx.stroke();
    }

    // 4. Coastal Shoreline & Golden Sand Beach Shelf
    ctx.beginPath();
    ctx.ellipse(550, 390, 528, 305, 0, 0, Math.PI * 2);
    const sandGrad = ctx.createLinearGradient(550, 85, 550, 695);
    if (themeKey === 'tokyo') {
      sandGrad.addColorStop(0, '#1E1B4B');
      sandGrad.addColorStop(1, '#312E81');
    } else {
      sandGrad.addColorStop(0, '#FDE68A');
      sandGrad.addColorStop(0.5, '#F59E0B');
      sandGrad.addColorStop(1, '#D97706');
    }
    ctx.fillStyle = sandGrad;
    ctx.fill();

    // Water shoreline foam line
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.ellipse(550, 390, 529, 306, 0, 0, Math.PI * 2);
    ctx.stroke();

    // 5. Main Island Plateau (Lush Green Parklands / City Ground)
    ctx.beginPath();
    ctx.ellipse(550, 388, 508, 292, 0, 0, Math.PI * 2);
    const parkGrad = ctx.createRadialGradient(550, 388, 50, 550, 388, 500);
    if (themeKey === 'paris') {
      parkGrad.addColorStop(0, '#166534'); // Rich Parisian garden green
      parkGrad.addColorStop(0.7, '#14532D');
      parkGrad.addColorStop(1, '#0F3E22');
    } else if (themeKey === 'tokyo') {
      parkGrad.addColorStop(0, '#0F172A');
      parkGrad.addColorStop(0.7, '#1E1B4B');
      parkGrad.addColorStop(1, '#090D1A');
    } else if (themeKey === 'newyork') {
      parkGrad.addColorStop(0, '#1F2937');
      parkGrad.addColorStop(0.65, '#166534'); // Central Park lushness
      parkGrad.addColorStop(1, '#111827');
    } else {
      // Istanbul
      parkGrad.addColorStop(0, '#1E293B');
      parkGrad.addColorStop(0.65, '#14532D');
      parkGrad.addColorStop(1, '#0F172A');
    }
    ctx.fillStyle = parkGrad;
    ctx.fill();

    // 6. Inner Cobblestone Promenade Ring
    ctx.strokeStyle = (themeKey === 'tokyo') ? 'rgba(56, 189, 248, 0.22)' : 'rgba(255, 255, 255, 0.12)';
    ctx.lineWidth = 14;
    ctx.beginPath();
    ctx.ellipse(550, 388, 435, 235, 0, 0, Math.PI * 2);
    ctx.stroke();

    // 7. Radial Parisian/City Boulevards connecting center to racetrack
    ctx.strokeStyle = (themeKey === 'tokyo') ? 'rgba(56, 189, 248, 0.15)' : 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 10;
    const radAngles = [0, Math.PI / 4, 3 * Math.PI / 4, Math.PI, 5 * Math.PI / 4, 7 * Math.PI / 4];
    radAngles.forEach(ang => {
      ctx.beginPath();
      ctx.moveTo(550 + Math.cos(ang) * 90, 388 + Math.sin(ang) * 55);
      ctx.lineTo(550 + Math.cos(ang) * 420, 388 + Math.sin(ang) * 225);
      ctx.stroke();
    });

    ctx.restore();
  }

  /* ----------------------------------------------------
     1. İSTANBUL ENVIRONMENT (Boğaz, Galata, Ayasofya, Köprü)
     ---------------------------------------------------- */
  drawIstanbulEnvironment(ctx) {
    // 1. Bosphorus Strait Water Channel (Boğaz)
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(380, 50);
    ctx.bezierCurveTo(460, 220, 340, 420, 520, 730);
    ctx.lineTo(660, 730);
    ctx.bezierCurveTo(490, 420, 610, 220, 520, 50);
    ctx.closePath();
    const waterGrad = ctx.createLinearGradient(400, 50, 600, 730);
    waterGrad.addColorStop(0, '#0284C7');
    waterGrad.addColorStop(0.5, '#0369A1');
    waterGrad.addColorStop(1, '#075985');
    ctx.fillStyle = waterGrad;
    ctx.fill();

    // Animated water ripples
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.28)';
    ctx.lineWidth = 1.8;
    for (let r = 0; r < 6; r++) {
      const rx = 440 + Math.sin(this.starPulse + r * 1.5) * 40;
      const ry = 140 + r * 90 + Math.cos(this.starPulse + r) * 15;
      ctx.beginPath();
      ctx.arc(rx, ry, 22 + r * 4, 0.2 * Math.PI, 0.8 * Math.PI);
      ctx.stroke();
    }

    // 2. Şehir Hatları Vapuru (Istanbul Ferry)
    const ferryBob = Math.sin(this.starPulse * 1.5) * 3;
    const fx = 470, fy = 360 + ferryBob;
    ctx.save();
    ctx.translate(fx, fy);
    // Hull
    ctx.beginPath();
    ctx.moveTo(-36, 10); ctx.lineTo(36, 10); ctx.lineTo(28, 24); ctx.lineTo(-28, 24); ctx.closePath();
    ctx.fillStyle = '#1E293B'; ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-38, 2); ctx.lineTo(38, 2); ctx.lineTo(34, 10); ctx.lineTo(-34, 10); ctx.closePath();
    ctx.fillStyle = '#FFFFFF'; ctx.fill();
    // Cabins
    ctx.fillStyle = '#F8FAFC';
    ctx.fillRect(-24, -12, 48, 14);
    ctx.fillStyle = '#0284C7';
    for (let p = -18; p <= 18; p += 9) {
      ctx.fillRect(p, -8, 5, 5);
    }
    // Smokestack & Chimney smoke
    ctx.fillStyle = '#EF4444';
    ctx.fillRect(-4, -20, 8, 8);
    ctx.fillStyle = '#FBBF24';
    ctx.fillRect(-4, -16, 8, 2);
    // Smoke puffs
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    ctx.beginPath();
    ctx.arc(-2 + Math.sin(this.starPulse * 2) * 4, -26, 4, 0, Math.PI * 2);
    ctx.arc(-5 + Math.sin(this.starPulse * 2.2) * 6, -34, 6, 0, Math.PI * 2);
    ctx.fill();
    // Turkish Flag
    ctx.fillStyle = '#DC2626';
    ctx.fillRect(28, -6, 10, 6);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 5px sans-serif';
    ctx.fillText('☪', 33, -2);
    ctx.restore();

    // 3. 15 Temmuz Şehitler Köprüsü (Bosphorus Bridge)
    ctx.save();
    ctx.strokeStyle = '#94A3B8';
    ctx.lineWidth = 4;
    // European Tower
    ctx.beginPath(); ctx.moveTo(400, 110); ctx.lineTo(400, 200); ctx.stroke();
    // Asian Tower
    ctx.beginPath(); ctx.moveTo(520, 95); ctx.lineTo(520, 185); ctx.stroke();
    // Bridge roadway deck
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 6;
    ctx.beginPath(); ctx.moveTo(350, 160); ctx.lineTo(570, 145); ctx.stroke();
    // Catenary Cables
    ctx.strokeStyle = '#CBD5E1';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(350, 160);
    ctx.quadraticCurveTo(460, 175, 570, 145);
    ctx.stroke();
    // Traffic dots (glowing red and white lights)
    const trafficOffset = (this.starPulse * 20) % 200;
    ctx.fillStyle = '#EF4444';
    ctx.fillRect(360 + (trafficOffset % 190), 158, 4, 2);
    ctx.fillStyle = '#FEF08A';
    ctx.fillRect(550 - (trafficOffset % 190), 148, 4, 2);
    ctx.restore();

    // 4. Galata Kulesi (Galata Tower) at Europe side (x: 230, y: 190)
    ctx.save();
    ctx.translate(230, 190);
    // Base shadow
    ctx.beginPath(); ctx.ellipse(0, 30, 22, 10, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(15, 23, 42, 0.15)'; ctx.fill();
    // Stone Tower Shaft
    ctx.fillStyle = '#D6D3D1';
    ctx.fillRect(-16, -25, 32, 55);
    // Masonry accent rings
    ctx.strokeStyle = '#A8A29E'; ctx.lineWidth = 2;
    ctx.strokeRect(-16, -25, 32, 55);
    ctx.beginPath(); ctx.moveTo(-16, -5); ctx.lineTo(16, -5); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-16, 12); ctx.lineTo(16, 12); ctx.stroke();
    // Arched windows
    ctx.fillStyle = '#1E293B';
    ctx.beginPath(); ctx.arc(-6, 2, 3, Math.PI, 0); ctx.rect(-9, 2, 6, 6); ctx.fill();
    ctx.beginPath(); ctx.arc(6, 2, 3, Math.PI, 0); ctx.rect(3, 2, 6, 6); ctx.fill();
    // Observation Balcony (360 viewing terrace)
    ctx.fillStyle = '#78716C';
    ctx.fillRect(-20, -32, 40, 7);
    ctx.strokeStyle = '#44403C'; ctx.lineWidth = 1.5;
    ctx.strokeRect(-20, -32, 40, 7);
    // Upper stone turret
    ctx.fillStyle = '#E7E5E4';
    ctx.fillRect(-13, -46, 26, 14);
    // Conical lead/copper Roof
    ctx.beginPath();
    ctx.moveTo(-18, -46); ctx.lineTo(18, -46); ctx.lineTo(0, -78); ctx.closePath();
    ctx.fillStyle = '#475569'; ctx.fill();
    ctx.strokeStyle = '#334155'; ctx.lineWidth = 2; ctx.stroke();
    // Golden Spire & Crescent
    ctx.fillStyle = '#F59E0B';
    ctx.fillRect(-1.5, -88, 3, 10);
    ctx.beginPath(); ctx.arc(0, -90, 4, 0.4 * Math.PI, 1.6 * Math.PI); ctx.stroke();
    // Title label
    ctx.font = 'bold 9px sans-serif'; ctx.fillStyle = '#1E293B'; ctx.textAlign = 'center';
    ctx.fillText('Galata Kulesi', 0, 44);
    ctx.restore();

    // 5. Ayasofya & Sultanahmet (Historic Peninsula) at x: 670, y: 200
    ctx.save();
    ctx.translate(670, 200);
    // Monumental terracotta facade
    ctx.fillStyle = '#B45309';
    ctx.fillRect(-35, -15, 70, 45);
    // Central Grand Dome
    ctx.beginPath();
    ctx.arc(0, -15, 24, Math.PI, 0);
    ctx.fillStyle = '#78716C'; ctx.fill();
    ctx.strokeStyle = '#44403C'; ctx.lineWidth = 2; ctx.stroke();
    // Half-domes
    ctx.beginPath(); ctx.arc(-22, -10, 14, Math.PI, 0); ctx.fillStyle = '#A8A29E'; ctx.fill();
    ctx.beginPath(); ctx.arc(22, -10, 14, Math.PI, 0); ctx.fillStyle = '#A8A29E'; ctx.fill();
    // Dome Spire
    ctx.fillStyle = '#F59E0B';
    ctx.fillRect(-1, -44, 2, 8);
    // Four Soaring Pencil Minarets
    const minaretOffsets = [-44, -36, 36, 44];
    minaretOffsets.forEach(mx => {
      ctx.fillStyle = '#E7E5E4';
      ctx.fillRect(mx - 3, -48, 6, 78);
      // Minaret Balconies (Şerefe)
      ctx.fillStyle = '#78716C';
      ctx.fillRect(mx - 5, -28, 10, 4);
      ctx.fillRect(mx - 5, -42, 10, 4);
      // Conical pointed spire
      ctx.beginPath();
      ctx.moveTo(mx - 3, -48); ctx.lineTo(mx + 3, -48); ctx.lineTo(mx, -64); ctx.closePath();
      ctx.fillStyle = '#475569'; ctx.fill();
    });
    ctx.font = 'bold 9px sans-serif'; ctx.fillStyle = '#1E293B'; ctx.textAlign = 'center';
    ctx.fillText('Ayasofya-i Kebir', 0, 42);
    ctx.restore();

    // 6. Kız Kulesi (Maiden's Tower) on its own islet at (740, 390)
    ctx.save();
    ctx.translate(740, 390);
    ctx.fillStyle = '#78716C';
    ctx.beginPath(); ctx.ellipse(0, 16, 26, 12, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#E7E5E4';
    ctx.fillRect(-12, -10, 24, 24);
    ctx.strokeStyle = '#A8A29E'; ctx.lineWidth = 1.5; ctx.strokeRect(-12, -10, 24, 24);
    ctx.fillStyle = '#D6D3D1'; ctx.fillRect(-8, -22, 16, 12);
    ctx.beginPath(); ctx.arc(0, -22, 8, Math.PI, 0); ctx.fillStyle = '#DC2626'; ctx.fill();
    // Sweeping Lighthouse Beam
    const ltAngle = this.starPulse * 1.2;
    const ltLen = 130;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(0, -22);
    ctx.lineTo(Math.cos(ltAngle - 0.25) * ltLen, -22 + Math.sin(ltAngle - 0.25) * ltLen * 0.5);
    ctx.lineTo(Math.cos(ltAngle + 0.25) * ltLen, -22 + Math.sin(ltAngle + 0.25) * ltLen * 0.5);
    ctx.closePath();
    const ltGrad = ctx.createRadialGradient(0, -22, 4, 0, -22, ltLen);
    ltGrad.addColorStop(0, 'rgba(254, 240, 138, 0.8)');
    ltGrad.addColorStop(1, 'rgba(254, 240, 138, 0)');
    ctx.fillStyle = ltGrad;
    ctx.fill();
    ctx.restore();
    ctx.font = 'bold 8px sans-serif'; ctx.fillStyle = '#1E293B'; ctx.textAlign = 'center';
    ctx.fillText('Kız Kulesi', 0, 34);
    ctx.restore();

    // 7. Taksim Nostaljik Kırmızı Tramvay on Rails
    ctx.save();
    const tramX = 180 + Math.sin(this.starPulse * 0.8) * 20;
    const tramY = 360;
    ctx.translate(tramX, tramY);
    ctx.strokeStyle = '#64748B'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(-45, 14); ctx.lineTo(45, 14); ctx.moveTo(-45, 18); ctx.lineTo(45, 18); ctx.stroke();
    ctx.fillStyle = '#DC2626'; ctx.fillRect(-18, -12, 36, 22);
    ctx.fillStyle = '#FEF08A'; ctx.fillRect(-18, 0, 36, 4);
    ctx.fillStyle = '#38BDF8';
    ctx.fillRect(-14, -8, 7, 7); ctx.fillRect(-4, -8, 8, 7); ctx.fillRect(7, -8, 7, 7);
    ctx.fillStyle = '#1E293B'; ctx.fillRect(-14, 10, 6, 4); ctx.fillRect(8, 10, 6, 4);
    ctx.strokeStyle = '#1E293B'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(0, -12); ctx.lineTo(4, -24); ctx.lineTo(12, -24); ctx.stroke();
    ctx.font = 'bold 7px sans-serif'; ctx.fillStyle = '#1E293B'; ctx.textAlign = 'center';
    ctx.fillText('Nostaljik Tramvay', 0, 28);
    ctx.restore();

    // 8. Flying Seagulls (Martılar) in the sky
    ctx.strokeStyle = '#1E293B';
    ctx.lineWidth = 1.5;
    const gulls = [
      { x: 310, y: 120 }, { x: 340, y: 105 }, { x: 620, y: 110 }, { x: 580, y: 90 }
    ];
    gulls.forEach((g, idx) => {
      const wingBob = Math.sin(this.starPulse * 3 + idx) * 3;
      ctx.beginPath();
      ctx.moveTo(g.x - 7, g.y + wingBob);
      ctx.quadraticCurveTo(g.x - 3, g.y - 4, g.x, g.y);
      ctx.quadraticCurveTo(g.x + 3, g.y - 4, g.x + 7, g.y + wingBob);
      ctx.stroke();
    });

    ctx.restore();
  }

  /* ----------------------------------------------------
     2. TOKYO ENVIRONMENT (Neon, Skytree, Tokyo Kulesi, Torii)
     ---------------------------------------------------- */
  drawTokyoEnvironment(ctx) {
    ctx.save();
    // 1. Cyber Grid Flooring
    ctx.strokeStyle = 'rgba(6, 182, 212, 0.12)';
    ctx.lineWidth = 1;
    for (let x = 80; x < 1020; x += 45) {
      ctx.beginPath(); ctx.moveTo(x, 60); ctx.lineTo(x, 700); ctx.stroke();
    }
    for (let y = 60; y < 700; y += 45) {
      ctx.beginPath(); ctx.moveTo(80, y); ctx.lineTo(1020, y); ctx.stroke();
    }

    // 2. Tokyo Tower (Red and White Steel Truss Pyramid) at x: 250, y: 200
    ctx.save();
    ctx.translate(250, 200);
    // Red/White Truss Body
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#EF4444';
    ctx.beginPath();
    ctx.moveTo(-28, 50); ctx.lineTo(-12, -10); ctx.lineTo(12, -10); ctx.lineTo(28, 50);
    ctx.stroke();
    // Lattice crosses
    ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-24, 40); ctx.lineTo(24, 20); ctx.moveTo(24, 40); ctx.lineTo(-24, 20);
    ctx.stroke();
    // Observation Deck
    ctx.fillStyle = '#FFFFFF'; ctx.fillRect(-18, -10, 36, 12);
    ctx.fillStyle = '#EF4444'; ctx.fillRect(-14, -22, 28, 12);
    // Needle mast
    ctx.strokeStyle = '#EF4444'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(0, -22); ctx.lineTo(0, -68); ctx.stroke();
    // Top beacon light
    ctx.fillStyle = '#FEF08A';
    ctx.beginPath(); ctx.arc(0, -68, 4, 0, Math.PI * 2); ctx.fill();
    ctx.font = 'bold 9px sans-serif'; ctx.fillStyle = '#E2E8F0'; ctx.textAlign = 'center';
    ctx.fillText('Tokyo Kulesi', 0, 64);
    ctx.restore();

    // 3. Tokyo Skytree (Futuristic Mast) at x: 720, y: 170
    ctx.save();
    ctx.translate(720, 170);
    ctx.strokeStyle = '#E2E8F0'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(-16, 60); ctx.lineTo(-6, -30); ctx.lineTo(6, -30); ctx.lineTo(16, 60); ctx.stroke();
    // Skytree observation spheres
    ctx.fillStyle = '#06B6D4';
    ctx.beginPath(); ctx.ellipse(0, 10, 20, 7, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(0, -20, 14, 5, 0, 0, Math.PI * 2); ctx.fill();
    // Antenna & Pulsing Cyan Beacon
    ctx.strokeStyle = '#38BDF8'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, -30); ctx.lineTo(0, -80); ctx.stroke();
    const beaconAlpha = 0.5 + Math.sin(this.starPulse * 4) * 0.5;
    ctx.fillStyle = `rgba(34, 211, 238, ${beaconAlpha})`;
    ctx.beginPath(); ctx.arc(0, -80, 6, 0, Math.PI * 2); ctx.fill();
    ctx.font = 'bold 9px sans-serif'; ctx.fillStyle = '#E2E8F0'; ctx.textAlign = 'center';
    ctx.fillText('Tokyo Skytree', 0, 74);
    ctx.restore();

    // 4. Shinto Torii Gate at x: 450, y: 460
    ctx.save();
    ctx.translate(450, 460);
    ctx.fillStyle = '#DC2626';
    // Twin vertical columns
    ctx.fillRect(-22, -26, 6, 36); ctx.fillRect(16, -26, 6, 36);
    // Main top crossbar (Kasagi)
    ctx.fillRect(-32, -34, 64, 7);
    ctx.fillStyle = '#0F172A'; ctx.fillRect(-34, -36, 68, 3);
    // Tie-beam (Nuki)
    ctx.fillStyle = '#DC2626'; ctx.fillRect(-25, -20, 50, 4);
    // Hanging glowing chōchin paper lanterns
    ctx.fillStyle = '#F59E0B';
    ctx.beginPath(); ctx.arc(-10, -12, 4, 0, Math.PI * 2); ctx.arc(10, -12, 4, 0, Math.PI * 2); ctx.fill();
    ctx.restore();

    // 5. Holographic Shibuya / Shinjuku Neon Billboards
    const neonSigns = [
      { x: 380, y: 220, text: '渋谷 NEON', color: '#06B6D4' },
      { x: 570, y: 220, text: 'ラーメン 🍜', color: '#F59E0B' },
      { x: 840, y: 340, text: 'ゲーム 🎮', color: '#EC4899' }
    ];
    neonSigns.forEach(s => {
      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.roundRect(-36, -14, 72, 28, 6);
      ctx.fill();
      ctx.strokeStyle = s.color; ctx.lineWidth = 2;
      ctx.shadowColor = s.color; ctx.shadowBlur = 10;
      ctx.stroke();
      ctx.font = 'bold 10px sans-serif'; ctx.fillStyle = '#FFFFFF'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(s.text, 0, 0);
      ctx.restore();
    });

    // 6. Sakura Blossom Tree with drifting petals
    ctx.save();
    ctx.translate(850, 450);
    ctx.fillStyle = '#78350F'; ctx.fillRect(-4, 0, 8, 22);
    ctx.fillStyle = '#F472B6';
    ctx.beginPath();
    ctx.arc(-10, -12, 14, 0, Math.PI * 2);
    ctx.arc(10, -14, 16, 0, Math.PI * 2);
    ctx.arc(0, -22, 18, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.restore();
  }

  /* ----------------------------------------------------
     3. PARİS ENVIRONMENT (Eyfel, Zafer Takı, Sen Nehri, Louvre)
     ---------------------------------------------------- */
  drawParisEnvironment(ctx) {
    ctx.save();

    // 1. River Seine (Sen Nehri) with Deep Water Flow
    ctx.beginPath();
    ctx.moveTo(350, 60); ctx.bezierCurveTo(440, 220, 360, 440, 600, 720);
    ctx.lineTo(720, 720); ctx.bezierCurveTo(480, 440, 560, 220, 470, 60);
    ctx.closePath();
    const seineGrad = ctx.createLinearGradient(350, 60, 650, 720);
    seineGrad.addColorStop(0, '#0284C7');
    seineGrad.addColorStop(0.5, '#0369A1');
    seineGrad.addColorStop(1, '#075985');
    ctx.fillStyle = seineGrad;
    ctx.fill();

    // Seine Water Ripples
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
    ctx.lineWidth = 1.5;
    for (let r = 0; r < 5; r++) {
      const rx = 440 + Math.sin(this.starPulse + r * 1.4) * 30;
      const ry = 180 + r * 95;
      ctx.beginPath();
      ctx.arc(rx, ry, 20 + r * 3, 0.2 * Math.PI, 0.8 * Math.PI);
      ctx.stroke();
    }

    // Cruise Boat (Bateau-Mouche) on Seine
    const boatX = 490 + Math.sin(this.starPulse * 0.8) * 22;
    const boatY = 460 + Math.cos(this.starPulse * 0.8) * 18;
    ctx.save();
    ctx.translate(boatX, boatY);
    ctx.rotate(0.32);
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.moveTo(-16, 5); ctx.lineTo(16, 5); ctx.lineTo(12, 13); ctx.lineTo(-12, 13); ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#0284C7';
    ctx.fillRect(-10, 1, 20, 4);
    ctx.fillStyle = '#FEF08A';
    ctx.fillRect(-7, 2, 3, 2); ctx.fillRect(-1, 2, 3, 2); ctx.fillRect(5, 2, 3, 2);
    ctx.restore();

    // 2. Arched Pont Neuf Stone Bridge
    ctx.fillStyle = '#E2E8F0';
    ctx.fillRect(400, 280, 110, 22);
    ctx.strokeStyle = '#94A3B8'; ctx.lineWidth = 2;
    ctx.strokeRect(400, 280, 110, 22);
    // Bridge Arch cutouts
    ctx.fillStyle = '#0369A1';
    ctx.beginPath(); ctx.arc(430, 302, 12, Math.PI, 0); ctx.arc(480, 302, 12, Math.PI, 0); ctx.fill();
    // Bridge balustrade details
    ctx.strokeStyle = '#64748B'; ctx.lineWidth = 1.2;
    for (let bx = 410; bx <= 500; bx += 10) {
      ctx.beginPath(); ctx.moveTo(bx, 280); ctx.lineTo(bx, 286); ctx.stroke();
    }

    // 3. 3D Parisian Haussmann Buildings (Living city quarters)
    const buildings = [
      { x: 330, y: 350, w: 32, h: 26 },
      { x: 375, y: 385, w: 28, h: 24 },
      { x: 740, y: 330, w: 34, h: 28 },
      { x: 785, y: 365, w: 30, h: 26 },
      { x: 670, y: 380, w: 26, h: 24 }
    ];
    buildings.forEach(b => {
      ctx.save();
      ctx.translate(b.x, b.y);
      // Drop Shadow
      ctx.fillStyle = 'rgba(0,0,0,0.3)';
      ctx.fillRect(-b.w / 2 + 2, b.h / 2, b.w, 4);
      // Stone facade
      ctx.fillStyle = '#E2E8F0';
      ctx.fillRect(-b.w / 2, -b.h / 2, b.w, b.h);
      ctx.strokeStyle = '#94A3B8'; ctx.lineWidth = 1;
      ctx.strokeRect(-b.w / 2, -b.h / 2, b.w, b.h);
      // Blue-grey zinc mansard roof
      ctx.beginPath();
      ctx.moveTo(-b.w / 2 - 2, -b.h / 2);
      ctx.lineTo(-b.w / 2 + 4, -b.h / 2 - 8);
      ctx.lineTo(b.w / 2 - 4, -b.h / 2 - 8);
      ctx.lineTo(b.w / 2 + 2, -b.h / 2);
      ctx.closePath();
      ctx.fillStyle = '#475569';
      ctx.fill();
      // Lit warm windows
      ctx.fillStyle = '#FEF08A';
      for (let wx = -b.w / 2 + 5; wx <= b.w / 2 - 8; wx += 8) {
        for (let wy = -b.h / 2 + 4; wy <= b.h / 2 - 6; wy += 8) {
          ctx.fillRect(wx, wy, 4, 5);
        }
      }
      ctx.restore();
    });

    // 4. French Formal Garden Parterres (Champs de Mars) & Fountain
    ctx.save();
    ctx.translate(290, 275);
    // Green hedge borders
    ctx.strokeStyle = '#15803D'; ctx.lineWidth = 3;
    ctx.strokeRect(-24, -16, 48, 32);
    ctx.fillStyle = '#14532D'; ctx.fillRect(-22, -14, 44, 28);
    // Center Fountain
    ctx.beginPath(); ctx.arc(0, 0, 7, 0, Math.PI * 2); ctx.fillStyle = '#38BDF8'; ctx.fill();
    ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 1.5; ctx.stroke();
    // Fountain water spray
    const sprayH = 4 + Math.sin(this.starPulse * 4) * 2;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.beginPath(); ctx.arc(0, -sprayH, 2, 0, Math.PI * 2); ctx.fill();
    ctx.restore();

    // 5. Tour Eiffel (Eiffel Tower) with Rotating Golden Spotlight at x: 240, y: 200
    ctx.save();
    ctx.translate(240, 200);
    // Grand Ground Arch
    ctx.strokeStyle = '#78716C'; ctx.lineWidth = 3.5;
    ctx.beginPath(); ctx.moveTo(-32, 50); ctx.lineTo(-14, 10); ctx.lineTo(14, 10); ctx.lineTo(32, 50); ctx.stroke();
    ctx.beginPath(); ctx.arc(0, 50, 18, Math.PI, 0); ctx.stroke();
    // 1st and 2nd Level Decks
    ctx.fillStyle = '#57534E';
    ctx.fillRect(-22, 10, 44, 7);
    ctx.fillRect(-15, -15, 30, 6);
    // Middle tapered shaft
    ctx.beginPath(); ctx.moveTo(-13, 10); ctx.lineTo(-7, -15); ctx.lineTo(7, -15); ctx.lineTo(13, 10); ctx.stroke();
    // Top Spire
    ctx.beginPath(); ctx.moveTo(-6, -15); ctx.lineTo(0, -68); ctx.lineTo(6, -15); ctx.stroke();
    // Golden Twinkle Lights
    ctx.fillStyle = '#FDE047';
    for (let i = 0; i < 6; i++) {
      if (Math.sin(this.starPulse * 3 + i) > 0) {
        ctx.fillRect(-8 + (i % 3) * 8, 4 - i * 8, 2, 2);
      }
    }
    // Rotating Sweeping Beacon Spotlight Beam
    const beaconAngle = this.starPulse * 0.7;
    const beamLength = 160;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(0, -68);
    ctx.lineTo(Math.cos(beaconAngle - 0.2) * beamLength, -68 + Math.sin(beaconAngle - 0.2) * beamLength * 0.4);
    ctx.lineTo(Math.cos(beaconAngle + 0.2) * beamLength, -68 + Math.sin(beaconAngle + 0.2) * beamLength * 0.4);
    ctx.closePath();
    const beamGrad = ctx.createRadialGradient(0, -68, 5, 0, -68, beamLength);
    beamGrad.addColorStop(0, 'rgba(253, 224, 71, 0.75)');
    beamGrad.addColorStop(1, 'rgba(253, 224, 71, 0)');
    ctx.fillStyle = beamGrad;
    ctx.fill();
    ctx.restore();

    ctx.font = 'bold 9px sans-serif'; ctx.fillStyle = '#FFFFFF'; ctx.textAlign = 'center';
    ctx.fillText('Eyfel Kulesi', 0, 65);
    ctx.restore();

    // 6. Arc de Triomphe (Zafer Takı) at x: 700, y: 210
    ctx.save();
    ctx.translate(700, 210);
    ctx.fillStyle = '#E7E5E4';
    ctx.fillRect(-26, -20, 52, 45);
    ctx.strokeStyle = '#A8A29E'; ctx.lineWidth = 2;
    ctx.strokeRect(-26, -20, 52, 45);
    // Center Arch Vault
    ctx.fillStyle = '#1E293B';
    ctx.beginPath();
    ctx.arc(0, 5, 12, Math.PI, 0); ctx.rect(-12, 5, 24, 20); ctx.fill();
    ctx.stroke();
    // Attic cornice frieze
    ctx.fillStyle = '#D6D3D1'; ctx.fillRect(-30, -28, 60, 8);
    ctx.font = 'bold 9px sans-serif'; ctx.fillStyle = '#FFFFFF'; ctx.textAlign = 'center';
    ctx.fillText('Zafer Takı', 0, 40);
    ctx.restore();

    // 7. Louvre Glass Pyramid (Louvre Piramidi) at x: 460, y: 460
    ctx.save();
    ctx.translate(460, 460);
    ctx.beginPath();
    ctx.moveTo(-28, 20); ctx.lineTo(28, 20); ctx.lineTo(0, -18); ctx.closePath();
    ctx.fillStyle = 'rgba(217, 249, 157, 0.55)'; ctx.fill();
    ctx.strokeStyle = '#CA8A04'; ctx.lineWidth = 2; ctx.stroke();
    // Diamond facets
    ctx.beginPath();
    ctx.moveTo(-14, 20); ctx.lineTo(0, -18); ctx.lineTo(14, 20);
    ctx.moveTo(-28, 20); ctx.lineTo(0, 2); ctx.lineTo(28, 20);
    ctx.stroke();
    ctx.font = 'bold 9px sans-serif'; ctx.fillStyle = '#FFFFFF'; ctx.textAlign = 'center';
    ctx.fillText('Louvre Piramidi', 0, 32);
    ctx.restore();

    ctx.restore();
  }

  /* ----------------------------------------------------
     4. NEW YORK ENVIRONMENT (Empire State, Özgürlük Heykeli, Köprü)
     ---------------------------------------------------- */
  drawNewYorkEnvironment(ctx) {
    ctx.save();

    // 1. Empire State Building at x: 260, y: 190
    ctx.save();
    ctx.translate(260, 190);
    // Stepped Art Deco Towers
    ctx.fillStyle = '#CBD5E1';
    ctx.fillRect(-22, 10, 44, 45);
    ctx.fillRect(-16, -15, 32, 25);
    ctx.fillRect(-10, -40, 20, 25);
    // Mooring Mast & Needle
    ctx.fillStyle = '#94A3B8'; ctx.fillRect(-4, -60, 8, 20);
    ctx.strokeStyle = '#EF4444'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, -60); ctx.lineTo(0, -82); ctx.stroke();
    // Glowing top beacon
    ctx.fillStyle = '#EF4444';
    ctx.beginPath(); ctx.arc(0, -82, 4, 0, Math.PI * 2); ctx.fill();
    // Office Windows
    ctx.fillStyle = '#FEF08A';
    for (let wy = -35; wy < 40; wy += 8) {
      ctx.fillRect(-7, wy, 3, 4);
      ctx.fillRect(4, wy, 3, 4);
    }
    ctx.font = 'bold 9px sans-serif'; ctx.fillStyle = '#1E293B'; ctx.textAlign = 'center';
    ctx.fillText('Empire State', 0, 68);
    ctx.restore();

    // 2. Chrysler Building Spire at x: 420, y: 180
    ctx.save();
    ctx.translate(420, 180);
    ctx.fillStyle = '#94A3B8';
    ctx.fillRect(-14, 0, 28, 50);
    // Sunburst crown arcs
    ctx.fillStyle = '#E2E8F0';
    ctx.beginPath(); ctx.arc(0, 0, 12, Math.PI, 0); ctx.fill();
    ctx.beginPath(); ctx.arc(0, -10, 8, Math.PI, 0); ctx.fill();
    // Stainless Needle
    ctx.strokeStyle = '#E2E8F0'; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.moveTo(0, -10); ctx.lineTo(0, -55); ctx.stroke();
    ctx.restore();

    // 3. Statue of Liberty (Özgürlük Heykeli) at x: 740, y: 200
    ctx.save();
    ctx.translate(740, 200);
    // Star Fort Pedestal
    ctx.fillStyle = '#78716C';
    ctx.fillRect(-20, 15, 40, 30);
    ctx.fillStyle = '#A8A29E';
    ctx.fillRect(-14, -5, 28, 20);
    // Copper Statue (Oxidized Green)
    ctx.fillStyle = '#34D399';
    // Draped Toga Robe
    ctx.beginPath();
    ctx.moveTo(-10, -5); ctx.lineTo(-14, 20); ctx.lineTo(14, 20); ctx.lineTo(10, -5); ctx.closePath();
    ctx.fill();
    // Head & 7-spike Crown
    ctx.beginPath(); ctx.arc(0, -12, 6, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#059669'; ctx.lineWidth = 1.5;
    for (let s = -3; s <= 3; s++) {
      ctx.beginPath(); ctx.moveTo(s * 2, -16); ctx.lineTo(s * 3.5, -22); ctx.stroke();
    }
    // Raised Right Arm & Golden Torch
    ctx.strokeStyle = '#34D399'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(6, -8); ctx.lineTo(16, -26); ctx.stroke();
    // Golden Flame Beacon
    ctx.fillStyle = '#F59E0B';
    ctx.beginPath(); ctx.ellipse(16, -29, 4, 6, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(251, 191, 36, 0.4)';
    ctx.beginPath(); ctx.arc(16, -29, 9, 0, Math.PI * 2); ctx.fill();

    ctx.font = 'bold 9px sans-serif'; ctx.fillStyle = '#1E293B'; ctx.textAlign = 'center';
    ctx.fillText('Özgürlük Heykeli', 0, 58);
    ctx.restore();

    // 4. Brooklyn Bridge at x: 530, y: 470
    ctx.save();
    ctx.translate(530, 470);
    // Gothic Twin Arches
    ctx.fillStyle = '#78716C';
    ctx.fillRect(-22, -26, 44, 38);
    ctx.fillStyle = '#FEF08A';
    ctx.beginPath();
    ctx.arc(-10, -8, 6, Math.PI, 0); ctx.rect(-16, -8, 12, 20); ctx.fill();
    ctx.beginPath();
    ctx.arc(10, -8, 6, Math.PI, 0); ctx.rect(4, -8, 12, 20); ctx.fill();
    // Suspension Cables
    ctx.strokeStyle = '#475569'; ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-50, -10); ctx.quadraticCurveTo(-20, 4, 0, -26);
    ctx.quadraticCurveTo(20, 4, 50, -10);
    ctx.stroke();
    ctx.restore();

    // 5. Yellow New York Cabs
    const cabPos = (this.starPulse * 30) % 300;
    ctx.fillStyle = '#FACC15';
    ctx.fillRect( cabPos + 320, 680, 24, 12);
    ctx.fillStyle = '#1E293B';
    ctx.fillRect( cabPos + 323, 689, 5, 5);
    ctx.fillRect( cabPos + 336, 689, 5, 5);
    ctx.fillStyle = '#EF4444';
    ctx.fillRect( cabPos + 342, 682, 2, 4);

    ctx.restore();
  }

  /* ----------------------------------------------------
     AMBIENT WORLD DETAILS (Street Lamps, Light Cones, Trees, Foliage)
     ---------------------------------------------------- */
  drawAmbientWorldDetails(ctx, theme) {
    ctx.save();

    // 1. Street Lamps with Warm Glowing Cones along the track
    const lampCoords = [
      { x: 267, y: 560 }, { x: 533, y: 655 }, { x: 813, y: 615 }, { x: 990, y: 500 },
      { x: 878, y: 175 }, { x: 524, y: 145 }, { x: 241, y: 165 }, { x: 118, y: 295 }
    ];

    lampCoords.forEach(lamp => {
      // Warm ground light circle
      ctx.fillStyle = 'rgba(254, 240, 138, 0.18)';
      ctx.beginPath();
      ctx.ellipse(lamp.x, lamp.y + 6, 22, 10, 0, 0, Math.PI * 2);
      ctx.fill();

      // Lamp post & glowing head
      ctx.fillStyle = '#1E293B';
      ctx.fillRect(lamp.x - 1.5, lamp.y - 18, 3, 18);
      ctx.fillStyle = '#FEF08A';
      ctx.beginPath();
      ctx.arc(lamp.x, lamp.y - 19, 4, 0, Math.PI * 2);
      ctx.fill();
    });

    // 2. Isometric 3D Puffy Cartoon Trees (Fills empty spaces with greenery)
    const treeCoords = [
      { x: 270, y: 350, s: 1.1 }, { x: 310, y: 380, s: 0.9 }, { x: 280, y: 420, s: 1.2 },
      { x: 820, y: 280, s: 1.0 }, { x: 860, y: 310, s: 1.2 }, { x: 790, y: 340, s: 0.9 },
      { x: 410, y: 530, s: 1.1 }, { x: 670, y: 530, s: 1.0 }, { x: 490, y: 260, s: 1.2 },
      { x: 580, y: 260, s: 1.1 }, { x: 370, y: 280, s: 0.9 }, { x: 720, y: 270, s: 1.0 }
    ];

    treeCoords.forEach(t => {
      ctx.save();
      ctx.translate(t.x, t.y);
      ctx.scale(t.s, t.s);

      // Shadow
      ctx.fillStyle = 'rgba(15, 23, 42, 0.12)';
      ctx.beginPath();
      ctx.ellipse(0, 12, 16, 7, 0, 0, Math.PI * 2);
      ctx.fill();

      // Trunk
      ctx.fillStyle = '#78350F';
      ctx.fillRect(-3, 0, 6, 12);

      // Foliage Layers (Puffy Cartoon Tree)
      ctx.fillStyle = '#15803D';
      ctx.beginPath();
      ctx.arc(0, -6, 16, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#22C55E';
      ctx.beginPath();
      ctx.arc(-2, -10, 13, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#86EFAC';
      ctx.beginPath();
      ctx.arc(-5, -14, 6, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
    });

    ctx.restore();
  }

  drawPathways(ctx) {
    const theme = MAP_THEMES[this.activeTheme] || MAP_THEMES.istanbul;
    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Connector drop shadow
    ctx.beginPath();
    for (let i = 0; i < this.tileCoords.length; i++) {
      const p1 = this.tileCoords[i];
      const p2 = this.tileCoords[(i + 1) % this.tileCoords.length];
      if (i === 0) ctx.moveTo(p1.x, p1.y + 12);
      ctx.lineTo(p2.x, p2.y + 12);
    }
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.12)';
    ctx.lineWidth = 26;
    ctx.stroke();

    // Road Base
    ctx.beginPath();
    for (let i = 0; i < this.tileCoords.length; i++) {
      const p1 = this.tileCoords[i];
      const p2 = this.tileCoords[(i + 1) % this.tileCoords.length];
      if (i === 0) ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
    }
    ctx.strokeStyle = theme.roadBase;
    ctx.lineWidth = 22;
    ctx.stroke();

    // Dotted center line
    ctx.strokeStyle = theme.roadBorder;
    ctx.lineWidth = 3.5;
    ctx.setLineDash([8, 12]);
    ctx.stroke();
    ctx.setLineDash([]);

    // Forward Direction Chevrons (Kutucuklar üzerinde gidişat akışı)
    for (let i = 0; i < this.tileCoords.length; i++) {
      const p1 = this.tileCoords[i];
      const p2 = this.tileCoords[(i + 1) % this.tileCoords.length];
      const mx = (p1.x + p2.x) / 2;
      const my = (p1.y + p2.y) / 2;
      const angle = Math.atan2(p2.y - p1.y, p2.x - p1.x);

      // Gentle forward pulse shift
      const pulseShift = (Math.sin(this.starPulse * 2.5 + i * 0.45) + 1) * 0.5;

      ctx.save();
      ctx.translate(mx, my);
      ctx.rotate(angle);
      ctx.fillStyle = theme.roadBorder;
      ctx.globalAlpha = 0.45 + pulseShift * 0.45;

      // Draw forward-pointing chevron
      ctx.beginPath();
      ctx.moveTo(-6, -6);
      ctx.lineTo(4, 0);
      ctx.lineTo(-6, 6);
      ctx.lineTo(-3, 0);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    ctx.restore();
  }

  /* ----------------------------------------------------
     STEP TRAJECTORY PREVIEW (Gidişat Yolu ve Hedef Karosu)
     ---------------------------------------------------- */
  drawStepTrajectory(ctx) {
    const roomState = window.CURRENT_ROOM_STATE;
    if (!roomState || !roomState.players || roomState.players.length === 0) return;

    const activePlayer = roomState.players[roomState.turnIndex];
    if (!activePlayer) return;

    const startIdx = activePlayer.position;
    const previewSteps = 5;

    ctx.save();
    // Glowing connecting line along future steps
    ctx.setLineDash([6, 8]);
    ctx.lineDashOffset = -this.starPulse * 24;
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.75)';
    ctx.lineWidth = 3.5;
    ctx.beginPath();

    const startPos = this.tileCoords[startIdx];
    if (startPos) {
      ctx.moveTo(startPos.x, startPos.y);

      for (let step = 1; step <= previewSteps; step++) {
        const nextIdx = (startIdx + step) % this.tileCoords.length;
        const nextPos = this.tileCoords[nextIdx];
        ctx.lineTo(nextPos.x, nextPos.y);
      }
      ctx.stroke();
    }
    ctx.setLineDash([]);

    // Floating step progression tags (+1, +2, +3... Target)
    for (let step = 1; step <= previewSteps; step++) {
      const nextIdx = (startIdx + step) % this.tileCoords.length;
      const p = this.tileCoords[nextIdx];
      if (!p) continue;
      const isTarget = (step === previewSteps);

      ctx.save();
      ctx.translate(p.x, p.y - 28);
      if (isTarget) {
        const bounce = Math.sin(this.starPulse * 3.5) * 4;
        ctx.translate(0, bounce);
        ctx.beginPath();
        ctx.arc(0, 0, 14, 0, Math.PI * 2);
        ctx.fillStyle = '#EF4444';
        ctx.shadowColor = '#EF4444';
        ctx.shadowBlur = 10;
        ctx.fill();
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 10px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🎯', 0, 0);
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, 9, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
        ctx.fill();
        ctx.strokeStyle = '#FBBF24';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.fillStyle = '#FBBF24';
        ctx.font = 'bold 8px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(`+${step}`, 0, 0);
      }
      ctx.restore();
    }

    ctx.restore();
  }

  /* ----------------------------------------------------
     DRAMATIC TURN SPOTLIGHT (Sıranın Kimde Olduğu Apaydın)
     ---------------------------------------------------- */
  drawTurnSpotlight(ctx) {
    const roomState = window.CURRENT_ROOM_STATE;
    if (!roomState || !roomState.players || roomState.players.length === 0) return;

    const activePlayer = roomState.players[roomState.turnIndex];
    if (!activePlayer) return;

    const anim = this.playerHopState && this.playerHopState[activePlayer.id];
    const px = anim ? anim.displayX : (this.tileCoords[activePlayer.position] ? this.tileCoords[activePlayer.position].x : 550);
    const py = anim ? (anim.displayY + anim.hopArcY) : (this.tileCoords[activePlayer.position] ? this.tileCoords[activePlayer.position].y : 380);

    ctx.save();

    // 1. Conical Volumetric Spotlight Beam from Sky
    const spotGrad = ctx.createLinearGradient(px, 0, px, py + 15);
    spotGrad.addColorStop(0, 'rgba(251, 191, 36, 0.03)');
    spotGrad.addColorStop(0.5, 'rgba(251, 191, 36, 0.12)');
    spotGrad.addColorStop(1, 'rgba(251, 191, 36, 0.32)');

    ctx.beginPath();
    ctx.moveTo(px - 18, 0);
    ctx.lineTo(px + 18, 0);
    ctx.lineTo(px + 48, py + 14);
    ctx.lineTo(px - 48, py + 14);
    ctx.closePath();
    ctx.fillStyle = spotGrad;
    ctx.fill();

    // 2. Pulsing Golden Halo Ring on the Floor
    const haloRadius = 26 + Math.sin(this.starPulse * 3.5) * 6;
    ctx.beginPath();
    ctx.ellipse(px, py + 10, haloRadius, haloRadius * 0.45, 0, 0, Math.PI * 2);
    ctx.strokeStyle = '#FBBF24';
    ctx.lineWidth = 3;
    ctx.shadowColor = '#FBBF24';
    ctx.shadowBlur = 14;
    ctx.stroke();

    // 3. Elegant Floating 3D Pointer Diamond (Unobtrusive & Never collides with name tags)
    const isMe = (window.GameClient && window.GameClient.player && window.GameClient.player.sessionId === activePlayer.sessionId);
    const bob = Math.sin(this.starPulse * 4) * 4;
    ctx.translate(px, py - 64 + bob);

    // Glowing 3D Diamond Indicator
    const diamondColor = isMe ? '#10B981' : '#F59E0B';
    const diamondBorder = isMe ? '#6EE7B7' : '#FDE047';

    ctx.save();
    ctx.shadowColor = diamondColor;
    ctx.shadowBlur = 12;

    // Diamond shape
    ctx.beginPath();
    ctx.moveTo(0, -9);
    ctx.lineTo(8, 0);
    ctx.lineTo(0, 9);
    ctx.lineTo(-8, 0);
    ctx.closePath();
    ctx.fillStyle = diamondColor;
    ctx.fill();
    ctx.strokeStyle = diamondBorder;
    ctx.lineWidth = 2;
    ctx.stroke();

    // Diamond facet highlight
    ctx.beginPath();
    ctx.moveTo(0, -9);
    ctx.lineTo(8, 0);
    ctx.lineTo(0, 0);
    ctx.closePath();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    ctx.fill();

    // Downward pointer tip
    ctx.beginPath();
    ctx.moveTo(-4, 7);
    ctx.lineTo(4, 7);
    ctx.lineTo(0, 13);
    ctx.closePath();
    ctx.fillStyle = diamondBorder;
    ctx.fill();
    ctx.restore();

    ctx.restore();
  }

  drawPlatformTile(ctx, index, tile, pos, isStarTile, isSelected, hasTrap) {
    const w = 68;
    const h = 50;
    const x = pos.x - w / 2;
    const y = pos.y - h / 2;

    const isHazard = (tile.type === 'trap' || tile.type === 'tax' || tile.type === 'jail' || tile.type === 'slip' || tile.type === 'freeze');
    const isBank = (tile.type === 'bank');
    const isStart = (tile.type === 'start');

    ctx.save();

    // 1. Selected Tile Pulsing Ring
    if (isSelected) {
      ctx.beginPath();
      ctx.roundRect(x - 6, y - 6, w + 12, h + 12, 20);
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 3.5;
      ctx.stroke();
    }

    // 2. Star Pedestal Volumetric Aura
    if (isStarTile) {
      const pulseSize = 14 + Math.sin(this.starPulse * 1.5) * 6;
      ctx.beginPath();
      ctx.ellipse(pos.x, pos.y + 6, (w / 2) + pulseSize, (h / 2) + pulseSize * 0.7, 0, 0, Math.PI * 2);
      const starGrad = ctx.createRadialGradient(pos.x, pos.y, 8, pos.x, pos.y, (w / 2) + pulseSize);
      starGrad.addColorStop(0, 'rgba(251, 191, 36, 0.85)');
      starGrad.addColorStop(0.5, 'rgba(245, 158, 11, 0.35)');
      starGrad.addColorStop(1, 'rgba(245, 158, 11, 0)');
      ctx.fillStyle = starGrad;
      ctx.fill();
    }

    // 3. Hazard Tile Danger Aura
    if (isHazard) {
      const hazardPulse = 6 + Math.sin(this.starPulse * 2.5) * 4;
      ctx.beginPath();
      ctx.ellipse(pos.x, pos.y + 8, (w / 2) + hazardPulse, (h / 2) + hazardPulse * 0.6, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(239, 68, 68, 0.16)';
      ctx.fill();
    }

    // 4. Soft Ground Shadow
    ctx.beginPath();
    ctx.ellipse(pos.x, pos.y + (h / 2) + 6, w * 0.48, 10, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(15, 23, 42, 0.22)';
    ctx.fill();

    // 5. 3D Extruded Bevel Base (Side Skirt)
    ctx.beginPath();
    ctx.roundRect(x, y + 6, w, h, 14);
    if (isHazard) {
      ctx.fillStyle = '#1A0C0E';
    } else if (isBank) {
      ctx.fillStyle = '#064E3B';
    } else {
      ctx.fillStyle = this.darkenColor(tile.color || '#3B82F6', 0.4);
    }
    ctx.fill();

    // 6. Top Island Platform Surface
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, 14);
    if (isHazard) {
      const lavaGrad = ctx.createLinearGradient(x, y, x, y + h);
      lavaGrad.addColorStop(0, '#261115');
      lavaGrad.addColorStop(0.6, '#38161D');
      lavaGrad.addColorStop(1, '#1A0A0D');
      ctx.fillStyle = lavaGrad;
    } else if (isBank) {
      const bankGrad = ctx.createLinearGradient(x, y, x, y + h);
      bankGrad.addColorStop(0, '#059669');
      bankGrad.addColorStop(1, '#047857');
      ctx.fillStyle = bankGrad;
    } else {
      const surfaceGrad = ctx.createLinearGradient(x, y, x, y + h);
      surfaceGrad.addColorStop(0, tile.color || '#3B82F6');
      surfaceGrad.addColorStop(1, this.darkenColor(tile.color || '#3B82F6', 0.18));
      ctx.fillStyle = surfaceGrad;
    }
    ctx.fill();

    // 7. Bevel Border Stroke
    if (isHazard) {
      ctx.strokeStyle = '#EF4444';
      ctx.lineWidth = 2.5;
    } else if (isStarTile) {
      ctx.strokeStyle = '#FDE047';
      ctx.lineWidth = 3;
    } else {
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2.2;
    }
    ctx.stroke();

    // 8. Hazard Visual Details (Glowing Molten Lava Cracks & Hazard Stripes)
    if (isHazard) {
      ctx.save();
      // Glowing lava crack veins
      ctx.strokeStyle = '#F97316';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x + 10, y + 14);
      ctx.lineTo(x + 24, y + 26);
      ctx.lineTo(x + 32, y + 18);
      ctx.lineTo(x + 52, y + 36);
      ctx.stroke();

      ctx.strokeStyle = '#FEF08A';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x + 12, y + 15);
      ctx.lineTo(x + 24, y + 26);
      ctx.stroke();

      // Caution corner tags
      ctx.fillStyle = '#EF4444';
      ctx.font = 'bold 8px sans-serif';
      ctx.fillText('⚠️', x + w - 12, y + 12);
      ctx.restore();
    }

    // 9. Center Emblem Badge
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 14, 0, Math.PI * 2);
    ctx.fillStyle = isHazard ? '#1E1B2E' : '#FFFFFF';
    ctx.fill();
    ctx.strokeStyle = isHazard ? '#EF4444' : (isBank ? '#F59E0B' : this.darkenColor(tile.color || '#3B82F6', 0.2));
    ctx.lineWidth = 2;
    ctx.stroke();

    // Center Icon
    let iconSymbol = '🪙';
    if (tile.type === 'start') iconSymbol = '🏁';
    else if (tile.type === 'star') iconSymbol = '⭐';
    else if (tile.type === 'bank') iconSymbol = '🏦';
    else if (tile.type === 'trap') iconSymbol = '💥';
    else if (tile.type === 'mystery') iconSymbol = '🎁';
    else if (tile.type === 'shop') iconSymbol = '🛍️';
    else if (tile.type === 'warp') iconSymbol = '🌀';
    else if (tile.type === 'slip') iconSymbol = '🍌';
    else if (tile.type === 'duel') iconSymbol = '⚔️';
    else if (tile.type === 'jail') iconSymbol = '⛓️';
    else if (tile.type === 'tax') iconSymbol = '💸';
    else if (tile.type === 'freeze') iconSymbol = '🧊';
    else if (tile.type === 'reverse') iconSymbol = '🔄';

    ctx.font = 'bold 13px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(iconSymbol, pos.x, pos.y + 1);

    // 10. Tile Number Badge
    ctx.beginPath();
    ctx.arc(x + 10, y + 8, 8, 0, Math.PI * 2);
    ctx.fillStyle = isHazard ? '#EF4444' : '#1E293B';
    ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 8px sans-serif';
    ctx.fillText(index.toString(), x + 10, y + 9);

    // 11. Floating Golden Star Flag
    if (isStarTile) {
      const starBob = Math.sin(this.starPulse * 1.5) * 8;
      ctx.save();
      ctx.translate(pos.x, y - 32 + starBob);
      ctx.font = '32px sans-serif';
      ctx.textAlign = 'center';
      ctx.shadowColor = '#F59E0B';
      ctx.shadowBlur = 14;
      ctx.fillText('⭐', 0, 0);
      ctx.restore();
    }

    // 12. Trap Marker
    if (hasTrap) {
      ctx.save();
      ctx.translate(pos.x, y - 16);
      ctx.font = '22px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('🍌', 0, 0);
      ctx.restore();
    }

    ctx.restore();
  }

  drawLandmark(ctx) {
    const theme = MAP_THEMES[this.activeTheme] || MAP_THEMES.tropics;
    const lm = theme.landmark;
    ctx.save();
    ctx.translate(lm.x, lm.y);

    // Landmark Shadow
    ctx.beginPath();
    ctx.ellipse(0, 16, 28, 12, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(15, 23, 42, 0.15)';
    ctx.fill();

    // Bobbing Landmark icon
    const bob = Math.sin(this.starPulse) * 4;
    ctx.font = '38px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(lm.icon, 0, bob);

    // Interactive Callout Tag
    ctx.font = 'bold 10px sans-serif';
    ctx.fillStyle = 'rgba(15, 23, 42, 0.8)';
    ctx.fillText(lm.name, 0, 32);

    ctx.restore();
  }

  drawParticles(ctx) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.life -= 0.035;

      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }

      ctx.beginPath();
      ctx.arc(p.x, p.y, 4 * p.life, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.globalAlpha = p.life;
      ctx.fill();
      ctx.globalAlpha = 1.0;
    }
  }

  /* --------------------------------------------------------------------------
     MONOPOLY-STYLE TILE-BY-TILE HOPPING & CHIBI CHARACTER TOKEN ENGINE
     -------------------------------------------------------------------------- */
  drawPlayerTokens(ctx, players) {
    if (!this.playerHopState) this.playerHopState = {};

    // 1. Group players by target/current tile position for cluster spacing
    const positionGroups = {};
    players.forEach(p => {
      positionGroups[p.position] = positionGroups[p.position] || [];
      positionGroups[p.position].push(p);
    });

    const tokensToRender = [];

    players.forEach((player) => {
      const tilePos = this.tileCoords[player.position] || { x: 110, y: 620 };
      const group = positionGroups[player.position];
      const count = group.length;
      const indexInGroup = group.indexOf(player);

      let clusterDx = 0;
      let clusterDy = 0;
      if (count === 2) {
        clusterDx = (indexInGroup === 0 ? -24 : 24);
      } else if (count >= 3) {
        const angle = (indexInGroup / count) * Math.PI * 2 - Math.PI / 2;
        clusterDx = Math.cos(angle) * 32;
        clusterDy = Math.sin(angle) * 22;
      }

      // Initialize state if first time seeing player
      if (!this.playerHopState[player.id]) {
        this.playerHopState[player.id] = {
          currentTile: player.position,
          targetTile: player.position,
          lastServerPos: player.position,
          hopQueue: [],
          hopProgress: 0,
          displayX: tilePos.x + clusterDx,
          displayY: tilePos.y + clusterDy,
          hopArcY: 0,
          scaleX: 1,
          scaleY: 1,
          isHopping: false
        };
      }

      const pState = this.playerHopState[player.id];

      // Detect server position change -> Enqueue intermediate tiles for Monopoly hop!
      if (player.position !== pState.lastServerPos) {
        const from = pState.currentTile;
        const to = player.position;
        pState.lastServerPos = player.position;

        if (from !== to) {
          const forwardSteps = (to - from + 32) % 32;
          const backwardSteps = (from - to + 32) % 32;
          const isReverse = !!player.reverseNext || (backwardSteps < forwardSteps && backwardSteps <= 6);

          if (isReverse) {
            for (let s = 1; s <= backwardSteps; s++) {
              pState.hopQueue.push((from - s + 32) % 32);
            }
          } else {
            for (let s = 1; s <= forwardSteps; s++) {
              pState.hopQueue.push((from + s) % 32);
            }
          }
          pState.isHopping = true;
        }
      }

      // Animate Hopping or Idle Breathing
      if (pState.hopQueue.length > 0) {
        const targetTile = pState.hopQueue[0];
        const fromPos = this.tileCoords[pState.currentTile] || { x: 110, y: 620 };
        const toPos = this.tileCoords[targetTile] || { x: 110, y: 620 };

        // Advance hop progress smoothly (accelerated by turbo speed & bot multiplier)
        const speedMultiplier = (window.GAME_SPEED || 1) * (player.isBot ? 1.35 : 1);
        pState.hopProgress += 0.042 * speedMultiplier;
        const p = Math.min(1, pState.hopProgress);

        // Linear ground position interpolation
        pState.displayX = fromPos.x + (toPos.x - fromPos.x) * p;
        pState.displayY = fromPos.y + (toPos.y - fromPos.y) * p;

        // Parabolic vertical jump arc (height = 32px)
        pState.hopArcY = -Math.sin(p * Math.PI) * 32;

        // Squash & Stretch physics
        if (p < 0.2) {
          const sub = p / 0.2;
          pState.scaleX = 1 + 0.15 * (1 - sub);
          pState.scaleY = 0.85 + 0.15 * sub;
        } else if (p < 0.8) {
          pState.scaleX = 0.88;
          pState.scaleY = 1.18;
        } else {
          const sub = (p - 0.8) / 0.2;
          pState.scaleX = 0.88 + 0.32 * sub;
          pState.scaleY = 1.18 - 0.38 * sub;
        }

        // Check if step completed
        if (pState.hopProgress >= 1) {
          pState.currentTile = pState.hopQueue.shift();
          pState.hopProgress = 0;
          pState.hopArcY = 0;
          pState.scaleX = 1;
          pState.scaleY = 1;

          // Sound effect on each hop landing
          if (window.AudioPlayer && window.AudioPlayer.playStep) {
            window.AudioPlayer.playStep();
          }

          // Emit dust puff particles at landing tile
          for (let d = 0; d < 4; d++) {
            this.particles.push({
              x: toPos.x + (Math.random() - 0.5) * 18,
              y: toPos.y + 12 + (Math.random() - 0.5) * 6,
              vx: (Math.random() - 0.5) * 2.2,
              vy: -Math.random() * 1.8 - 0.4,
              size: Math.random() * 3 + 2,
              color: 'rgba(226, 232, 240, 0.85)',
              life: 1,
              decay: 0.05
            });
          }

          // Destination reached!
          if (pState.hopQueue.length === 0) {
            pState.isHopping = false;
            // Celebratory star particles burst on final arrival
            for (let s = 0; s < 10; s++) {
              const ang = Math.random() * Math.PI * 2;
              const spd = Math.random() * 3.5 + 2;
              this.particles.push({
                x: toPos.x,
                y: toPos.y - 12,
                vx: Math.cos(ang) * spd,
                vy: Math.sin(ang) * spd - 2,
                size: Math.random() * 4 + 2,
                color: ['#FBBF24', '#38BDF8', '#F472B6', '#10B981'][Math.floor(Math.random() * 4)],
                life: 1,
                decay: 0.035
              });
            }
          }
        }
      } else {
        // Idle state: smooth slide to cluster offset & gentle breathing bob
        const targetX = tilePos.x + clusterDx;
        const targetY = tilePos.y + clusterDy;
        pState.displayX += (targetX - pState.displayX) * 0.2;
        pState.displayY += (targetY - pState.displayY) * 0.2;

        const idleBob = Math.sin(this.starPulse * 2.5 + player.name.charCodeAt(0)) * 1.8;
        pState.hopArcY = idleBob;
        pState.scaleX = 1;
        pState.scaleY = 1;
      }

      tokensToRender.push({
        player,
        floorX: pState.displayX,
        floorY: pState.displayY,
        px: pState.displayX,
        py: pState.displayY + pState.hopArcY,
        scaleX: pState.scaleX,
        scaleY: pState.scaleY,
        hopArcY: pState.hopArcY,
        clusterCount: count
      });
    });

    // 3. DEPTH SORTING (Y-Sort): Render tokens from top to bottom
    tokensToRender.sort((a, b) => a.floorY - b.floorY);

    // 4. Render each Chibi Token cleanly
    tokensToRender.forEach(item => {
      this.renderMinifigToken(
        ctx,
        item.player,
        item.px,
        item.py,
        item.floorY,
        item.clusterCount > 1,
        item.scaleX,
        item.scaleY,
        item.hopArcY
      );
    });
  }

  /* --------------------------------------------------------------------------
     PREMIUM 3D CHIBI CHARACTER TOKEN RENDERER
     -------------------------------------------------------------------------- */
  renderMinifigToken(ctx, player, px, py, floorY, isClustered, scaleX = 1, scaleY = 1, hopArcY = 0) {
    const isCurrent = window.CURRENT_ROOM_STATE && 
                      window.CURRENT_ROOM_STATE.players[window.CURRENT_ROOM_STATE.turnIndex] &&
                      window.CURRENT_ROOM_STATE.players[window.CURRENT_ROOM_STATE.turnIndex].id === player.id;

    ctx.save();

    // 1. Dynamic Ground Shadow (Stays on floor, shrinks & fades as token hops higher)
    const jumpHeight = Math.max(0, -hopArcY);
    const shadowScale = Math.max(0.35, 1 - (jumpHeight / 50));
    const shadowAlpha = Math.max(0.08, 0.28 * (1 - (jumpHeight / 45)));

    ctx.beginPath();
    ctx.ellipse(px, floorY + 8, 18 * shadowScale, 9 * shadowScale, 0, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(15, 23, 42, ${shadowAlpha})`;
    ctx.fill();

    // 2. Base Colored Ring on Floor
    ctx.beginPath();
    ctx.ellipse(px, floorY + 7, 15 * shadowScale, 7 * shadowScale, 0, 0, Math.PI * 2);
    ctx.strokeStyle = player.color || '#3B82F6';
    ctx.lineWidth = 2.5 * shadowScale;
    ctx.stroke();

    // Apply Token Squash & Stretch Transform
    ctx.translate(px, py);
    ctx.scale(scaleX, scaleY);

    // 3. Shield Bubble if active
    if (player.shieldActive > 0) {
      ctx.beginPath();
      ctx.arc(0, -18, 28, 0, Math.PI * 2);
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 2.5;
      ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
      ctx.fill();
      ctx.stroke();
    }

    // 3.1 Ghost Cloak Ethereal Aura if active
    if (player.ghostCloakActive > 0) {
      ctx.save();
      ctx.beginPath();
      ctx.arc(0, -18, 30, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(6, 182, 212, 0.25)';
      ctx.shadowColor = '#22D3EE';
      ctx.shadowBlur = 12;
      ctx.fill();
      ctx.strokeStyle = '#67E8F9';
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 3]);
      ctx.stroke();
      ctx.restore();
    }

    // 4. Ice Block if frozen
    if (player.frozenTurns > 0) {
      ctx.beginPath();
      ctx.roundRect(-20, -42, 40, 48, 8);
      ctx.fillStyle = 'rgba(186, 230, 253, 0.55)';
      ctx.strokeStyle = '#0284C7';
      ctx.lineWidth = 2;
      ctx.fill();
      ctx.stroke();
    }

    const avatarId = player.avatar || 'builder';
    const mainColor = player.color || '#3B82F6';

    // 5. Draw Archetype-Specific Chibi Silhouette & Features
    if (avatarId === 'dino') {
      // --- CUTE DINO CHIBI ---
      // Dorsal crest spikes
      ctx.fillStyle = '#F59E0B';
      ctx.beginPath(); ctx.moveTo(-6, -34); ctx.lineTo(-12, -40); ctx.lineTo(-2, -37); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(0, -38); ctx.lineTo(0, -46); ctx.lineTo(6, -38); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(6, -34); ctx.lineTo(12, -40); ctx.lineTo(2, -37); ctx.closePath(); ctx.fill();

      // Green body & chubby head
      ctx.beginPath(); ctx.roundRect(-14, -20, 28, 22, 6); ctx.fillStyle = '#059669'; ctx.fill();
      ctx.beginPath(); ctx.roundRect(-13, -37, 26, 20, 9); ctx.fillStyle = '#10B981'; ctx.fill();
      ctx.strokeStyle = '#047857'; ctx.lineWidth = 1.5; ctx.stroke();

      // Light belly
      ctx.beginPath(); ctx.ellipse(0, -11, 7, 7, 0, 0, Math.PI * 2); ctx.fillStyle = '#A7F3D0'; ctx.fill();

      // Cute snout
      ctx.beginPath(); ctx.ellipse(0, -26, 8, 5, 0, 0, Math.PI * 2); ctx.fillStyle = '#34D399'; ctx.fill();
      ctx.fillStyle = '#065F46';
      ctx.beginPath(); ctx.arc(-2.5, -26.5, 1, 0, Math.PI * 2); ctx.arc(2.5, -26.5, 1, 0, Math.PI * 2); ctx.fill();

      // Big anime eyes
      ctx.fillStyle = '#064E3B';
      ctx.beginPath(); ctx.arc(-5.5, -31, 2.5, 0, Math.PI * 2); ctx.arc(5.5, -31, 2.5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath(); ctx.arc(-6.2, -32, 1, 0, Math.PI * 2); ctx.arc(4.8, -32, 1, 0, Math.PI * 2); ctx.fill();

      // Rosy cheeks
      ctx.fillStyle = '#F472B6';
      ctx.beginPath(); ctx.ellipse(-9, -27, 2.5, 1.3, 0, 0, Math.PI * 2); ctx.ellipse(9, -27, 2.5, 1.3, 0, 0, Math.PI * 2); ctx.fill();

    } else if (avatarId === 'cat') {
      // --- SIBER NEKO (CAT) CHIBI ---
      // Curled kitty tail behind
      ctx.strokeStyle = mainColor; ctx.lineWidth = 3.5; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(10, -12); ctx.quadraticCurveTo(22, -18, 18, -30); ctx.stroke();

      // Kitty ears with pink inner fluff
      ctx.fillStyle = mainColor;
      ctx.beginPath(); ctx.moveTo(-11, -33); ctx.lineTo(-14, -46); ctx.lineTo(-4, -36); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(11, -33); ctx.lineTo(14, -46); ctx.lineTo(4, -36); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#FDF2F8';
      ctx.beginPath(); ctx.moveTo(-10, -34); ctx.lineTo(-12, -42); ctx.lineTo(-5, -36); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(10, -34); ctx.lineTo(12, -42); ctx.lineTo(5, -36); ctx.closePath(); ctx.fill();

      // Body & chubby face
      ctx.beginPath(); ctx.roundRect(-13, -19, 26, 21, 6); ctx.fillStyle = mainColor; ctx.fill();
      ctx.beginPath(); ctx.roundRect(-12, -36, 24, 19, 8); ctx.fillStyle = '#F472B6'; ctx.fill();
      ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 1.5; ctx.stroke();

      // Cyber visor band
      ctx.fillStyle = '#0F172A'; ctx.fillRect(-12, -34, 24, 4);
      ctx.fillStyle = '#06B6D4'; ctx.fillRect(-10, -33, 20, 2);

      // Cute big cat eyes
      ctx.fillStyle = '#0F172A';
      ctx.beginPath(); ctx.ellipse(-5, -27, 2.4, 2.8, 0, 0, Math.PI * 2); ctx.ellipse(5, -27, 2.4, 2.8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath(); ctx.arc(-5.8, -28, 1, 0, Math.PI * 2); ctx.arc(4.2, -28, 1, 0, Math.PI * 2); ctx.fill();

      // Cute nose & whiskers
      ctx.fillStyle = '#9D174D'; ctx.beginPath(); ctx.moveTo(0, -24.5); ctx.lineTo(-1.5, -23); ctx.lineTo(1.5, -23); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(-9, -24); ctx.lineTo(-15, -25); ctx.moveTo(-9, -22); ctx.lineTo(-15, -21); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(9, -24); ctx.lineTo(15, -25); ctx.moveTo(9, -22); ctx.lineTo(15, -21); ctx.stroke();

      // Gold collar bell
      ctx.fillStyle = '#FBBF24'; ctx.beginPath(); ctx.arc(0, -18, 3, 0, Math.PI * 2); ctx.fill();

    } else if (avatarId === 'astro') {
      // --- SPACE EXPLORER CHIBI ---
      // Spacesuit torso
      ctx.beginPath(); ctx.roundRect(-14, -19, 28, 21, 5); ctx.fillStyle = '#F1F5F9'; ctx.fill();
      ctx.strokeStyle = '#CBD5E1'; ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = mainColor; ctx.beginPath(); ctx.roundRect(-8, -16, 16, 12, 3); ctx.fill();
      ctx.fillStyle = '#22C55E'; ctx.beginPath(); ctx.arc(-3, -10, 1.5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#EF4444'; ctx.beginPath(); ctx.arc(3, -10, 1.5, 0, Math.PI * 2); ctx.fill();

      // Big Round Space Helmet
      ctx.beginPath(); ctx.arc(0, -32, 13, 0, Math.PI * 2); ctx.fillStyle = '#E2E8F0'; ctx.fill();
      ctx.strokeStyle = '#94A3B8'; ctx.lineWidth = 1.5; ctx.stroke();

      // Iridescent Cyan/Gold Visor
      ctx.beginPath(); ctx.ellipse(0, -32, 9, 7.5, 0, 0, Math.PI * 2); ctx.fillStyle = '#0891B2'; ctx.fill();
      ctx.strokeStyle = '#67E8F9'; ctx.lineWidth = 1.5; ctx.stroke();
      // Glint
      ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 1.5; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.arc(0, -32, 6, 1.1 * Math.PI, 1.6 * Math.PI); ctx.stroke();

    } else if (avatarId === 'robot') {
      // --- MECHA ROBOT CHIBI ---
      // Top Antenna with glowing bulb
      ctx.strokeStyle = '#06B6D4'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0, -37); ctx.lineTo(0, -45); ctx.stroke();
      ctx.fillStyle = '#FACC15'; ctx.beginPath(); ctx.arc(0, -46, 3, 0, Math.PI * 2); ctx.fill();

      // Metallic Chassis Torso
      ctx.beginPath(); ctx.roundRect(-13, -19, 26, 21, 4); ctx.fillStyle = '#475569'; ctx.fill();
      ctx.strokeStyle = '#94A3B8'; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.fillStyle = '#1E293B'; ctx.fillRect(-7, -15, 14, 9);

      // Square Monitor Head
      ctx.beginPath(); ctx.roundRect(-12, -37, 24, 18, 4); ctx.fillStyle = '#64748B'; ctx.fill();
      ctx.strokeStyle = '#334155'; ctx.lineWidth = 1.5; ctx.stroke();

      // CRT Face Screen
      ctx.fillStyle = '#0F172A'; ctx.beginPath(); ctx.roundRect(-9, -34, 18, 12, 2.5); ctx.fill();

      // Cyan Glowing Anime Eyes ( ^ ◡ ^ )
      ctx.strokeStyle = '#38BDF8'; ctx.lineWidth = 1.8; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(-6, -29); ctx.lineTo(-4, -31); ctx.lineTo(-2, -29); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(2, -29); ctx.lineTo(4, -31); ctx.lineTo(6, -29); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, -26, 2, 0.1 * Math.PI, 0.9 * Math.PI); ctx.stroke();

    } else if (avatarId === 'wizard') {
      // --- WIZARD MERLIN CHIBI ---
      // Robes
      ctx.beginPath(); ctx.roundRect(-14, -19, 28, 22, 5); ctx.fillStyle = '#6D28D9'; ctx.fill();
      ctx.strokeStyle = '#FDE047'; ctx.lineWidth = 1.5; ctx.stroke();

      // Head & White Cloud Beard
      ctx.beginPath(); ctx.arc(0, -28, 9, 0, Math.PI * 2); ctx.fillStyle = '#FED7AA'; ctx.fill();
      ctx.fillStyle = '#F8FAFC';
      ctx.beginPath(); ctx.moveTo(-8, -26); ctx.quadraticCurveTo(0, -14, 8, -26); ctx.closePath(); ctx.fill();

      // Wizard Hat
      ctx.fillStyle = '#7C3AED';
      ctx.beginPath(); ctx.ellipse(0, -35, 13, 3.5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-9, -35); ctx.quadraticCurveTo(-1, -50, 4, -58); ctx.lineTo(7, -35); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#FDE047'; ctx.beginPath(); ctx.arc(0, -44, 2, 0, Math.PI * 2); ctx.fill();

      // Eyes
      ctx.fillStyle = '#1E1B4B';
      ctx.beginPath(); ctx.arc(-3.5, -28, 1.4, 0, Math.PI * 2); ctx.arc(3.5, -28, 1.4, 0, Math.PI * 2); ctx.fill();

    } else if (avatarId === 'ninja') {
      // --- SHINOBI NINJA CHIBI ---
      // Headband tails flying
      ctx.strokeStyle = '#DC2626'; ctx.lineWidth = 3; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(11, -33); ctx.quadraticCurveTo(20, -32, 18, -22); ctx.stroke();

      // Ninja Gi Torso
      ctx.beginPath(); ctx.roundRect(-13, -19, 26, 21, 5); ctx.fillStyle = '#1E293B'; ctx.fill();
      ctx.strokeStyle = '#DC2626'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-10, -19); ctx.lineTo(10, 0); ctx.stroke();

      // Dark Mask Cowl
      ctx.beginPath(); ctx.roundRect(-11, -37, 22, 19, 7); ctx.fillStyle = '#0F172A'; ctx.fill();

      // Red Forehead Band
      ctx.fillStyle = '#DC2626'; ctx.fillRect(-11, -35, 22, 4);

      // Eye Slit & Intense Eyes
      ctx.fillStyle = '#FED7AA'; ctx.fillRect(-7, -29, 14, 5);
      ctx.fillStyle = '#DC2626';
      ctx.beginPath(); ctx.arc(-3.5, -26.5, 1.5, 0, Math.PI * 2); ctx.arc(3.5, -26.5, 1.5, 0, Math.PI * 2); ctx.fill();

    } else if (avatarId === 'detective') {
      // --- DETECTIVE CHIBI ---
      // Trenchcoat
      ctx.beginPath(); ctx.roundRect(-14, -19, 28, 22, 5); ctx.fillStyle = '#B45309'; ctx.fill();
      ctx.strokeStyle = '#78350F'; ctx.lineWidth = 1.5; ctx.stroke();

      // Chibi Head
      ctx.beginPath(); ctx.roundRect(-11, -36, 22, 18, 6); ctx.fillStyle = '#FED7AA'; ctx.fill();

      // Deerstalker Cap
      ctx.fillStyle = '#78350F';
      ctx.beginPath(); ctx.ellipse(0, -36, 14, 3.5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.roundRect(-9, -46, 18, 11, [5, 5, 1, 1]); ctx.fillStyle = '#92400E'; ctx.fill();

      // Monocle Right Eye
      ctx.strokeStyle = '#F59E0B'; ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.arc(4, -27, 3, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#1E293B';
      ctx.beginPath(); ctx.arc(-4, -27, 1.8, 0, Math.PI * 2); ctx.arc(4, -27, 1.8, 0, Math.PI * 2); ctx.fill();

    } else if (avatarId === 'panda') {
      // --- CHIBI PANDA ---
      // Black Ears
      ctx.fillStyle = '#0F172A';
      ctx.beginPath(); ctx.arc(-9, -38, 4.5, 0, Math.PI * 2); ctx.arc(9, -38, 4.5, 0, Math.PI * 2); ctx.fill();

      // Torso & Red Bowtie
      ctx.beginPath(); ctx.roundRect(-14, -19, 28, 22, 6); ctx.fillStyle = '#EA580C'; ctx.fill();
      ctx.fillStyle = '#EF4444'; ctx.beginPath(); ctx.arc(-3, -17, 2.5, 0, Math.PI * 2); ctx.arc(3, -17, 2.5, 0, Math.PI * 2); ctx.fill();

      // Round White Panda Head
      ctx.beginPath(); ctx.arc(0, -28, 12, 0, Math.PI * 2); ctx.fillStyle = '#F8FAFC'; ctx.fill();
      ctx.strokeStyle = '#0F172A'; ctx.lineWidth = 1.2; ctx.stroke();

      // Black Eye Patches
      ctx.fillStyle = '#0F172A';
      ctx.beginPath(); ctx.ellipse(-5, -29, 3, 3.8, 0, 0, Math.PI * 2); ctx.ellipse(5, -29, 3, 3.8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath(); ctx.arc(-5.8, -30, 1.2, 0, Math.PI * 2); ctx.arc(4.2, -30, 1.2, 0, Math.PI * 2); ctx.fill();

      // Nose & Blush
      ctx.fillStyle = '#0F172A'; ctx.beginPath(); ctx.arc(0, -25, 1.5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#FDA4AF'; ctx.beginPath(); ctx.arc(-8, -26, 2, 0, Math.PI * 2); ctx.arc(8, -26, 2, 0, Math.PI * 2); ctx.fill();

    } else if (avatarId === 'king') {
      // --- ROYAL KING CHIBI ---
      // Royal Cape
      ctx.beginPath(); ctx.roundRect(-15, -19, 30, 22, 5); ctx.fillStyle = '#9333EA'; ctx.fill();
      ctx.fillStyle = '#F8FAFC'; ctx.fillRect(-6, -19, 12, 22);

      // Head & Golden Crown
      ctx.beginPath(); ctx.roundRect(-11, -35, 22, 17, 5); ctx.fillStyle = '#FDE047'; ctx.fill();
      ctx.fillStyle = '#FACC15'; ctx.strokeStyle = '#CA8A04'; ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-11, -35); ctx.lineTo(-12, -47); ctx.lineTo(-5, -41); ctx.lineTo(0, -49); ctx.lineTo(5, -41); ctx.lineTo(12, -47); ctx.lineTo(11, -35);
      ctx.closePath(); ctx.fill(); ctx.stroke();

      ctx.fillStyle = '#EF4444'; ctx.beginPath(); ctx.arc(0, -44, 2, 0, Math.PI * 2); ctx.fill();

      // Eyes & Smile
      ctx.fillStyle = '#1E293B';
      ctx.beginPath(); ctx.arc(-4, -28, 1.8, 0, Math.PI * 2); ctx.arc(4, -28, 1.8, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(0, -24, 3, 0.1 * Math.PI, 0.9 * Math.PI); ctx.stroke();

    } else {
      // --- BUILDER (MINIFIG BOB) DEFAULT ---
      // Blue Dungarees Torso
      ctx.beginPath(); ctx.roundRect(-13, -19, 26, 22, 5); ctx.fillStyle = mainColor; ctx.fill();
      ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 2; ctx.stroke();

      // Yellow Head
      ctx.beginPath(); ctx.roundRect(-10, -35, 20, 17, 5); ctx.fillStyle = '#FCD34D'; ctx.fill();
      ctx.strokeStyle = '#1E293B'; ctx.lineWidth = 1.5; ctx.stroke();

      // Hardhat / Stud
      ctx.beginPath(); ctx.ellipse(0, -35, 12, 3.5, 0, 0, Math.PI * 2); ctx.fillStyle = '#EA580C'; ctx.fill();
      ctx.beginPath(); ctx.arc(0, -37, 7, Math.PI, 0); ctx.fillStyle = '#F97316'; ctx.fill();

      // Cute Face
      ctx.fillStyle = '#1E293B';
      ctx.beginPath(); ctx.arc(-4, -28, 1.8, 0, Math.PI * 2); ctx.arc(4, -28, 1.8, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath(); ctx.arc(-4.6, -28.8, 0.8, 0, Math.PI * 2); ctx.arc(3.4, -28.8, 0.8, 0, Math.PI * 2); ctx.fill();

      ctx.strokeStyle = '#1E293B'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(0, -24, 3.5, 0.1 * Math.PI, 0.9 * Math.PI, false); ctx.stroke();

      ctx.fillStyle = '#FDA4AF';
      ctx.beginPath(); ctx.ellipse(-7.5, -25.5, 2, 1.2, 0, 0, Math.PI * 2); ctx.ellipse(7.5, -25.5, 2, 1.2, 0, 0, Math.PI * 2); ctx.fill();
    }

    // 6. Dynamic Headwear / Hats (if equipped)
    const hat = player.hat;
    if (hat === 'crown') {
      ctx.fillStyle = '#FBBF24'; ctx.strokeStyle = '#D97706'; ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(-9, -37); ctx.lineTo(-9, -48); ctx.lineTo(-4, -42); ctx.lineTo(0, -50); ctx.lineTo(4, -42); ctx.lineTo(9, -48); ctx.lineTo(9, -37);
      ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#EF4444'; ctx.beginPath(); ctx.arc(0, -44, 2, 0, Math.PI * 2); ctx.fill();
    } else if (hat === 'headphones') {
      // DJ Headphones
      ctx.strokeStyle = '#0F172A'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(0, -36, 13, Math.PI, 0); ctx.stroke();
      ctx.fillStyle = '#06B6D4'; ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.roundRect(-16, -34, 5, 11, 2); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.roundRect(11, -34, 5, 11, 2); ctx.fill(); ctx.stroke();
    } else if (hat === 'flower_crown') {
      // Flower Crown
      const flowers = ['#F43F5E', '#FBBF24', '#38BDF8', '#A855F7'];
      for (let f = 0; f < 4; f++) {
        ctx.fillStyle = flowers[f];
        ctx.beginPath(); ctx.arc(-9 + f * 6, -36, 2.5, 0, Math.PI * 2); ctx.fill();
      }
    } else if (hat === 'halo') {
      // Angel Halo
      ctx.strokeStyle = '#FDE047'; ctx.lineWidth = 2.5;
      ctx.shadowColor = '#FACC15'; ctx.shadowBlur = 8;
      ctx.beginPath(); ctx.ellipse(0, -47, 10, 3.5, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.shadowBlur = 0;
    } else if (hat === 'pirate') {
      ctx.fillStyle = '#0F172A';
      ctx.beginPath(); ctx.moveTo(-15, -36); ctx.quadraticCurveTo(0, -54, 15, -36); ctx.quadraticCurveTo(0, -43, -15, -36); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#F59E0B'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.fillStyle = '#FFFFFF'; ctx.beginPath(); ctx.arc(0, -43, 2.5, 0, Math.PI * 2); ctx.fill();
    } else if (hat === 'wizard') {
      ctx.fillStyle = '#7C3AED'; ctx.beginPath(); ctx.ellipse(0, -36, 13, 4, 0, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-10, -36); ctx.quadraticCurveTo(-2, -54, 5, -62); ctx.lineTo(8, -36); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#FDE047'; ctx.beginPath(); ctx.arc(0, -45, 2, 0, Math.PI * 2); ctx.fill();
    } else if (hat === 'cat_ears') {
      ctx.fillStyle = mainColor;
      ctx.beginPath(); ctx.moveTo(-9, -36); ctx.lineTo(-6, -46); ctx.lineTo(-2, -36); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(2, -36); ctx.lineTo(6, -46); ctx.lineTo(9, -36); ctx.closePath(); ctx.fill();
    } else if (hat === 'party_hat') {
      ctx.fillStyle = '#EF4444';
      ctx.beginPath(); ctx.moveTo(-8, -37); ctx.lineTo(8, -37); ctx.lineTo(0, -56); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#38BDF8'; ctx.beginPath(); ctx.arc(0, -57, 3, 0, Math.PI * 2); ctx.fill();
    } else if (hat === 'visor') {
      ctx.fillStyle = '#06B6D4'; ctx.shadowColor = '#06B6D4'; ctx.shadowBlur = 8;
      ctx.fillRect(-10, -30, 20, 5); ctx.shadowBlur = 0;
      ctx.fillStyle = '#FFFFFF'; ctx.fillRect(-8, -29, 16, 1.5);
    } else if (hat === 'detective') {
      ctx.fillStyle = '#78350F'; ctx.beginPath(); ctx.ellipse(0, -37, 14, 3.5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#92400E'; ctx.beginPath(); ctx.roundRect(-8, -47, 16, 11, [4, 4, 1, 1]); ctx.fill();
    } else if (hat === 'viking') {
      ctx.fillStyle = '#64748B'; ctx.beginPath(); ctx.arc(0, -36, 10, Math.PI, 0); ctx.fill();
      ctx.fillStyle = '#FEF08A';
      ctx.beginPath(); ctx.moveTo(-9, -37); ctx.quadraticCurveTo(-16, -43, -15, -49); ctx.quadraticCurveTo(-11, -43, -6, -39); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(9, -37); ctx.quadraticCurveTo(16, -43, 15, -49); ctx.quadraticCurveTo(11, -43, 6, -39); ctx.closePath(); ctx.fill();
    }

    // 7. Dynamic Auto-Sizing Name Tag Pill (Guarantees zero text overflow!)
    if (isCurrent || !isClustered) {
      ctx.font = 'bold 9.5px sans-serif';
      const displayName = player.name.length > 10 ? player.name.substr(0, 9) + '..' : player.name;
      const tagText = `${displayName} ⭐${player.stars}`;
      const textWidth = ctx.measureText(tagText).width;
      const pillWidth = Math.max(76, textWidth + 18);
      const pillHeight = 18;

      ctx.beginPath();
      ctx.roundRect(-pillWidth / 2, -56, pillWidth, pillHeight, 9);
      ctx.fillStyle = isCurrent ? '#FEF08A' : 'rgba(15, 23, 42, 0.9)';
      ctx.fill();
      ctx.strokeStyle = player.color || '#38BDF8';
      ctx.lineWidth = isCurrent ? 2 : 1.2;
      ctx.stroke();

      ctx.fillStyle = isCurrent ? '#854D0E' : '#FFFFFF';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(tagText, 0, -47);

      // Active Buff Badges (Double Dice, Lucky Die, Ghost)
      let buffOffset = pillWidth / 2 + 10;
      if (player.doubleDiceActive) {
        ctx.beginPath();
        ctx.arc(buffOffset, -47, 8, 0, Math.PI * 2);
        ctx.fillStyle = '#F59E0B';
        ctx.fill();
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 1.2;
        ctx.stroke();
        ctx.font = '9px sans-serif';
        ctx.fillText('🎲', buffOffset, -46);
        buffOffset += 18;
      }
      if (player.fixedRollNext) {
        ctx.beginPath();
        ctx.arc(buffOffset, -47, 8, 0, Math.PI * 2);
        ctx.fillStyle = '#10B981';
        ctx.fill();
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 1.2;
        ctx.stroke();
        ctx.font = 'bold 9px sans-serif';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(player.fixedRollNext, buffOffset, -47);
        buffOffset += 18;
      }
    } else {
      ctx.beginPath();
      ctx.arc(0, -45, 10, 0, Math.PI * 2);
      ctx.fillStyle = player.color;
      ctx.fill();
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 9px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(player.name.charAt(0).toUpperCase(), 0, -45);
    }

    ctx.restore();
  }

  darkenColor(hex, factor = 0.2) {
    if (!hex || hex[0] !== '#') return '#1E293B';
    let r = parseInt(hex.substr(1, 2), 16);
    let g = parseInt(hex.substr(3, 2), 16);
    let b = parseInt(hex.substr(5, 2), 16);
    r = Math.floor(Math.max(0, r * (1 - factor)));
    g = Math.floor(Math.max(0, g * (1 - factor)));
    b = Math.floor(Math.max(0, b * (1 - factor)));
    return `rgb(${r}, ${g}, ${b})`;
  }
}

window.BoardRenderer = BoardRenderer;


/* =================== 6. MINI GAMES =================== */
/**
 * Interactive Party Mini-Games Engine
 * Real-time mini-games with high stakes, zero-zoom mobile touch controls,
 * and 5 distinct game modes!
 */
class MiniGameManager {
  constructor() {
    this.container = document.getElementById('minigame-overlay');
    this.activeGame = null;
    this.timerInterval = null;
    this.score = 0;
    this.gameFinished = false;
  }

  start(minigameData) {
    if (!this.container) return;
    this.score = 0;
    this.gameFinished = false;
    this.activeGame = minigameData;
    this.container.classList.remove('hidden');

    switch (minigameData.id) {
      case 'coin_catch':
        this.runCoinCatch(minigameData);
        break;
      case 'reflex_pop':
        this.runReflexPop(minigameData);
        break;
      case 'balloon_mash':
        this.runBalloonMash(minigameData);
        break;
      case 'lucky_chests':
        this.runLuckyChests(minigameData);
        break;
      case 'memory_matrix':
        this.runMemoryMatrix(minigameData);
        break;
      case 'timing_hammer':
        this.runTimingHammer(minigameData);
        break;
      default:
        this.runCoinCatch(minigameData);
        break;
    }
  }

  end() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
    this.gameFinished = true;
    if (window.GameClient) {
      window.GameClient.sendMiniGameScore(this.score);
    }
  }

  close() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
    this.gameFinished = true;
    if (this.container) {
      this.container.classList.add('hidden');
      this.container.innerHTML = '';
    }
    this.activeGame = null;
  }

  /* ----------------------------------------------------
     MINI-GAME 1: GÖKTEN ALTIN YAĞMURU (Coin Rain Blitz)
     - Touch-action: none prevents double-tap zoom
     - Smooth continuous hold & direct touch drag support
     ---------------------------------------------------- */
  runCoinCatch(data) {
    let timeLeft = data.duration || 15;

    this.container.innerHTML = `
      <div class="minigame-card">
        <div class="minigame-header">
          <div class="mg-stakes-badge">🏆 1.ye +15 🪙 & Eşya! • 💀 Sonuncuya -5 🪙 Ceza!</div>
          <h2>🪙 ${data.title}</h2>
          <p>${data.desc}</p>
          <div class="minigame-stats">
            <div class="badge-time">⏳ Süre: <span id="mg-timer">${timeLeft}</span>s</div>
            <div class="badge-score">⭐ Skor: <span id="mg-score">0</span></div>
          </div>
        </div>
        <div class="coin-catch-arena" id="catch-arena" style="touch-action: none; user-select: none;">
          <div class="catch-basket" id="basket">🧺</div>
        </div>
        <div class="touch-controls-row" style="touch-action: none;">
          <button class="touch-btn" id="btn-left" style="touch-action: none; user-select: none;">◀ SOLA</button>
          <button class="touch-btn" id="btn-right" style="touch-action: none; user-select: none;">SAĞA ▶</button>
        </div>
      </div>
    `;

    const arena = document.getElementById('catch-arena');
    const basket = document.getElementById('basket');
    const timerElem = document.getElementById('mg-timer');
    const scoreElem = document.getElementById('mg-score');

    let basketX = 160;
    basket.style.left = `${basketX}px`;

    const moveBasket = (delta) => {
      if (this.gameFinished) return;
      const arenaW = arena.clientWidth || 360;
      basketX = Math.max(10, Math.min(arenaW - 60, basketX + delta));
      basket.style.left = `${basketX}px`;
    };

    // Keyboard support
    const handleKey = (e) => {
      if (e.key === 'ArrowLeft' || e.key === 'a') moveBasket(-28);
      if (e.key === 'ArrowRight' || e.key === 'd') moveBasket(28);
    };
    window.addEventListener('keydown', handleKey);

    // Direct touch / mouse drag across arena (Smooth finger tracking)
    const handlePointerMove = (clientX) => {
      const rect = arena.getBoundingClientRect();
      const relativeX = clientX - rect.left - 25;
      const arenaW = rect.width || 360;
      basketX = Math.max(10, Math.min(arenaW - 60, relativeX));
      basket.style.left = `${basketX}px`;
    };

    arena.addEventListener('pointermove', (e) => {
      if (e.buttons > 0 || e.pointerType === 'touch') {
        handlePointerMove(e.clientX);
      }
    });

    arena.addEventListener('pointerdown', (e) => {
      handlePointerMove(e.clientX);
    });

    // Continuous button hold-to-move without browser double-tap zoom
    let holdInterval = null;
    const startHold = (delta) => (e) => {
      if (e) { e.preventDefault(); e.stopPropagation(); }
      moveBasket(delta);
      if (holdInterval) clearInterval(holdInterval);
      holdInterval = setInterval(() => moveBasket(delta), 50);
    };
    const stopHold = (e) => {
      if (e) { e.preventDefault(); }
      if (holdInterval) {
        clearInterval(holdInterval);
        holdInterval = null;
      }
    };

    const btnL = document.getElementById('btn-left');
    const btnR = document.getElementById('btn-right');

    btnL.addEventListener('pointerdown', startHold(-18));
    btnL.addEventListener('pointerup', stopHold);
    btnL.addEventListener('pointercancel', stopHold);
    btnL.addEventListener('pointerleave', stopHold);

    btnR.addEventListener('pointerdown', startHold(18));
    btnR.addEventListener('pointerup', stopHold);
    btnR.addEventListener('pointercancel', stopHold);
    btnR.addEventListener('pointerleave', stopHold);

    // Spawn falling items
    const items = [];
    const spawnItem = () => {
      if (this.gameFinished) return;
      const isBomb = Math.random() < 0.26;
      const isGem = !isBomb && Math.random() < 0.28;

      const itemElem = document.createElement('div');
      itemElem.className = 'falling-item';
      itemElem.innerHTML = isBomb ? '💣' : (isGem ? '💎' : '🪙');
      const startX = Math.random() * (arena.clientWidth - 40);
      itemElem.style.left = `${startX}px`;
      itemElem.style.top = '0px';
      arena.appendChild(itemElem);

      items.push({
        elem: itemElem,
        x: startX,
        y: 0,
        speed: 3 + Math.random() * 4,
        isBomb,
        isGem
      });
    };

    const spawnInterval = setInterval(spawnItem, 420);

    // Game loop for falling physics and collision
    let animId;
    const updatePhysics = () => {
      if (this.gameFinished) {
        cancelAnimationFrame(animId);
        return;
      }

      const basketRect = basket.getBoundingClientRect();

      for (let i = items.length - 1; i >= 0; i--) {
        const item = items[i];
        item.y += item.speed;
        item.elem.style.top = `${item.y}px`;

        const itemRect = item.elem.getBoundingClientRect();

        // Check Collision with basket
        if (
          itemRect.bottom >= basketRect.top &&
          itemRect.top <= basketRect.bottom &&
          itemRect.right >= basketRect.left &&
          itemRect.left <= basketRect.right
        ) {
          if (item.isBomb) {
            this.score = Math.max(0, this.score - 5);
            AudioPlayer.playTrapSound();
            basket.style.transform = 'scale(0.8) rotate(-15deg)';
            setTimeout(() => basket.style.transform = '', 200);
          } else if (item.isGem) {
            this.score += 4;
            AudioPlayer.playStarFanfare();
          } else {
            this.score += 2;
            AudioPlayer.playCoinSound();
          }

          scoreElem.innerText = this.score;
          item.elem.remove();
          items.splice(i, 1);
          continue;
        }

        // Out of bounds
        if (item.y > arena.clientHeight) {
          item.elem.remove();
          items.splice(i, 1);
        }
      }

      animId = requestAnimationFrame(updatePhysics);
    };

    animId = requestAnimationFrame(updatePhysics);

    // Countdown Timer
    this.timerInterval = setInterval(() => {
      timeLeft--;
      timerElem.innerText = timeLeft;
      AudioPlayer.playCountdown(timeLeft <= 3);

      if (timeLeft <= 0) {
        clearInterval(spawnInterval);
        stopHold();
        window.removeEventListener('keydown', handleKey);
        this.end();
      }
    }, 1000);
  }

  /* ----------------------------------------------------
     MINI-GAME 2: HIZLI PARMAK (Reflex Duel)
     ---------------------------------------------------- */
  runReflexPop(data) {
    this.container.innerHTML = `
      <div class="minigame-card text-center">
        <div class="mg-stakes-badge">🏆 1.ye +15 🪙 & Eşya! • 💀 Sonuncuya -5 🪙 Ceza!</div>
        <h2>⚡ ${data.title}</h2>
        <p>${data.desc}</p>
        <div class="reflex-pad wait-state" id="reflex-pad" style="touch-action: none; user-select: none;">
          <div class="reflex-icon" id="reflex-icon">🛑</div>
          <div class="reflex-msg" id="reflex-msg">BEKLE...</div>
          <div class="reflex-sub">Yeşil olduğunda hemen dokun!</div>
        </div>
        <div class="badge-score mt-3">Skorun: <span id="reflex-score">0</span></div>
      </div>
    `;

    const pad = document.getElementById('reflex-pad');
    const icon = document.getElementById('reflex-icon');
    const msg = document.getElementById('reflex-msg');
    const scoreElem = document.getElementById('reflex-score');

    let canClick = false;
    let startTime = 0;
    let reacted = false;

    // Wait between 1.2 and 2.6 seconds
    const waitTime = Math.random() * 1400 + 1200;
    const triggerTimeout = setTimeout(() => {
      if (this.gameFinished) return;
      canClick = true;
      startTime = Date.now();
      pad.className = 'reflex-pad ready-state';
      icon.innerText = '⚡';
      msg.innerText = 'ŞİMDİ DOKUN!';
      AudioPlayer.playStarFanfare();
    }, waitTime);

    pad.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      if (reacted) return;
      reacted = true;

      if (!canClick) {
        // False start!
        clearTimeout(triggerTimeout);
        pad.className = 'reflex-pad error-state';
        icon.innerText = '❌';
        msg.innerText = 'ERKEN TIKLADIN!';
        this.score = 0;
        AudioPlayer.playTrapSound();
        scoreElem.innerText = this.score;
        setTimeout(() => this.end(), 600);
      } else {
        const diffMs = Date.now() - startTime;
        this.score = Math.max(5, Math.floor(35 - (diffMs / 32)));
        pad.className = 'reflex-pad success-state';
        icon.innerText = '🎉';
        msg.innerText = `${diffMs} ms! Harika!`;
        AudioPlayer.playCoinSound();
        scoreElem.innerText = this.score;
        setTimeout(() => this.end(), 700);
      }
    });
  }

  /* ----------------------------------------------------
     MINI-GAME 3: LEGO BALON ŞİŞİRME (Balloon Mash)
     ---------------------------------------------------- */
  runBalloonMash(data) {
    let timeLeft = data.duration || 12;
    let balloonSize = 60;

    this.container.innerHTML = `
      <div class="minigame-card text-center">
        <div class="mg-stakes-badge">🏆 1.ye +15 🪙 & Eşya! • 💀 Sonuncuya -5 🪙 Ceza!</div>
        <h2>🎈 ${data.title}</h2>
        <p>${data.desc}</p>
        <div class="minigame-stats">
          <div class="badge-time">⏳ <span id="mash-timer">${timeLeft}</span>s</div>
          <div class="badge-score">Puan: <span id="mash-score">0</span></div>
        </div>
        <div class="balloon-arena">
          <div class="lego-balloon" id="lego-balloon">🎈</div>
        </div>
        <button class="mash-btn" id="mash-btn" style="touch-action: none; user-select: none;">POMPALA! (TIKLA)</button>
      </div>
    `;

    const balloon = document.getElementById('lego-balloon');
    const btn = document.getElementById('mash-btn');
    const timerElem = document.getElementById('mash-timer');
    const scoreElem = document.getElementById('mash-score');

    const handlePump = (e) => {
      if (e) e.preventDefault();
      if (this.gameFinished) return;
      this.score += 2;
      balloonSize += 5;
      scoreElem.innerText = this.score;

      balloon.style.transform = `scale(${balloonSize / 60})`;
      AudioPlayer.playStep();

      if (balloonSize >= 180) {
        // Popped!
        AudioPlayer.playStarFanfare();
        balloon.innerHTML = '💥';
        balloon.style.transform = 'scale(2.2)';
        this.score += 15;
        scoreElem.innerText = this.score;
        btn.disabled = true;
        setTimeout(() => this.end(), 600);
      }
    };

    btn.addEventListener('pointerdown', handlePump);
    window.addEventListener('keydown', (e) => {
      if (e.code === 'Space') handlePump();
    });

    this.timerInterval = setInterval(() => {
      timeLeft--;
      timerElem.innerText = timeLeft;
      AudioPlayer.playCountdown(timeLeft <= 3);

      if (timeLeft <= 0) {
        this.end();
      }
    }, 1000);
  }

  /* ----------------------------------------------------
     MINI-GAME 4: HAZİNE SANDIĞI KUMARI (Lucky Treasure Chests)
     ---------------------------------------------------- */
  runLuckyChests(data) {
    let timeLeft = data.duration || 10;
    let chosen = false;

    this.container.innerHTML = `
      <div class="minigame-card text-center">
        <div class="mg-stakes-badge">🏆 1.ye +15 🪙 & Eşya! • 💀 Sonuncuya -5 🪙 Ceza!</div>
        <h2>📦 ${data.title}</h2>
        <p>${data.desc}</p>
        <div class="minigame-stats">
          <div class="badge-time">⏳ <span id="chest-timer">${timeLeft}</span>s</div>
          <div class="badge-score">Sonuç: <span id="chest-result-badge">Bir Sandık Seç!</span></div>
        </div>
        <div class="lucky-chests-row" id="chests-row">
          <div class="lucky-chest-box" data-idx="0">
            <div class="chest-icon">📦</div>
            <div class="chest-label">Altın Sandık</div>
          </div>
          <div class="lucky-chest-box" data-idx="1">
            <div class="chest-icon">💎</div>
            <div class="chest-label">Elmas Kasa</div>
          </div>
          <div class="lucky-chest-box" data-idx="2">
            <div class="chest-icon">🐉</div>
            <div class="chest-label">Ejder Sandığı</div>
          </div>
        </div>
      </div>
    `;

    const timerElem = document.getElementById('chest-timer');
    const resultElem = document.getElementById('chest-result-badge');
    const chestBoxes = document.querySelectorAll('.lucky-chest-box');

    chestBoxes.forEach(box => {
      box.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        if (chosen || this.gameFinished) return;
        chosen = true;

        box.classList.add('selected');
        AudioPlayer.playChestOpen();

        // Roll outcome
        const rand = Math.random();
        setTimeout(() => {
          if (rand < 0.5) {
            // Jackpot!
            box.querySelector('.chest-icon').innerText = '👑';
            resultElem.innerText = '🎉 BÜYÜK HAZİNE! +25 Puan!';
            this.score = 25;
            AudioPlayer.playStarFanfare();
          } else if (rand < 0.8) {
            // Nice reward
            box.querySelector('.chest-icon').innerText = '🪙';
            resultElem.innerText = '💰 Altın Kaptın! +15 Puan!';
            this.score = 15;
            AudioPlayer.playCoinSound();
          } else {
            // Mimic monster trap!
            box.querySelector('.chest-icon').innerText = '👾';
            resultElem.innerText = '💀 CANAVAR TUZAĞI! 0 Puan!';
            this.score = 0;
            AudioPlayer.playTrapSound();
          }
          const speed = window.GAME_SPEED || 1;
          setTimeout(() => this.end(), Math.max(250, Math.round(500 / speed)));
        }, Math.max(150, Math.round(300 / speed)));
      });
    });

    this.timerInterval = setInterval(() => {
      timeLeft--;
      timerElem.innerText = timeLeft;
      AudioPlayer.playCountdown(timeLeft <= 3);

      if (timeLeft <= 0) {
        if (!chosen) {
          this.score = 0;
          this.end();
        }
      }
    }, 1000);
  }

  /* ----------------------------------------------------
     MINI-GAME 5: PARTİ HAFIZASI & HIZLI RENKLER (Memory Matrix)
     ---------------------------------------------------- */
  runMemoryMatrix(data) {
    let timeLeft = data.duration || 14;

    this.container.innerHTML = `
      <div class="minigame-card text-center">
        <div class="mg-stakes-badge">🏆 1.ye +15 🪙 & Eşya! • 💀 Sonuncuya -5 🪙 Ceza!</div>
        <h2>🧩 ${data.title}</h2>
        <p>${data.desc}</p>
        <div class="minigame-stats">
          <div class="badge-time">⏳ <span id="mem-timer">${timeLeft}</span>s</div>
          <div class="badge-score">⭐ Skor: <span id="mem-score">0</span></div>
        </div>
        <div class="memory-grid" id="memory-grid">
          <div class="mem-pad pad-red" data-color="red" style="touch-action: none;">🔴</div>
          <div class="mem-pad pad-blue" data-color="blue" style="touch-action: none;">🔵</div>
          <div class="mem-pad pad-green" data-color="green" style="touch-action: none;">🟢</div>
          <div class="mem-pad pad-yellow" data-color="yellow" style="touch-action: none;">🟡</div>
        </div>
        <div class="mem-status" id="mem-status">Sırayı İzle...</div>
      </div>
    `;

    const timerElem = document.getElementById('mem-timer');
    const scoreElem = document.getElementById('mem-score');
    const statusElem = document.getElementById('mem-status');
    const pads = document.querySelectorAll('.mem-pad');

    const colors = ['red', 'blue', 'green', 'yellow'];
    let sequence = [colors[Math.floor(Math.random() * 4)], colors[Math.floor(Math.random() * 4)], colors[Math.floor(Math.random() * 4)]];
    let userStep = 0;
    let acceptingInput = false;

    const playSequence = () => {
      acceptingInput = false;
      userStep = 0;
      statusElem.innerText = '👀 Dikkatle İzle...';

      sequence.forEach((col, idx) => {
        setTimeout(() => {
          if (this.gameFinished) return;
          const targetPad = document.querySelector(`.pad-${col}`);
          if (targetPad) {
            targetPad.classList.add('flash');
            AudioPlayer.playTone(col === 'red' ? 330 : (col === 'blue' ? 440 : (col === 'green' ? 550 : 660)), 'triangle', 0.15, 0.25);
            setTimeout(() => targetPad.classList.remove('flash'), 250);
          }
          if (idx === sequence.length - 1) {
            setTimeout(() => {
              if (this.gameFinished) return;
              acceptingInput = true;
              statusElem.innerText = '👉 Sırayı Şimdi Dokunarak Tekrarla!';
            }, 300);
          }
        }, idx * 450 + 200);
      });
    };

    setTimeout(playSequence, 600);

    pads.forEach(p => {
      p.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        if (!acceptingInput || this.gameFinished) return;
        const col = p.getAttribute('data-color');

        p.classList.add('flash');
        setTimeout(() => p.classList.remove('flash'), 180);
        AudioPlayer.playTone(col === 'red' ? 330 : (col === 'blue' ? 440 : (col === 'green' ? 550 : 660)), 'sine', 0.1, 0.2);

        if (col === sequence[userStep]) {
          userStep++;
          if (userStep >= sequence.length) {
            // Completed wave!
            this.score += 8;
            scoreElem.innerText = this.score;
            AudioPlayer.playCoinSound();
            statusElem.innerText = '✨ Harika! Yeni Renk Ekleniyor...';
            // Add next color
            sequence.push(colors[Math.floor(Math.random() * 4)]);
            setTimeout(playSequence, 800);
          }
        } else {
          // Mistake!
          AudioPlayer.playTrapSound();
          statusElem.innerText = '❌ Hatalı Sıra! Baştan Deneniyor...';
          acceptingInput = false;
          setTimeout(playSequence, 900);
        }
      });
    });

    this.timerInterval = setInterval(() => {
      timeLeft--;
      timerElem.innerText = timeLeft;
      AudioPlayer.playCountdown(timeLeft <= 3);

      if (timeLeft <= 0) {
        this.end();
      }
    }, 1000);
  }

  runTimingHammer(data) {
    const lang = (window.i18n && window.i18n.getLang()) ? window.i18n.getLang() : 'tr';
    const titles = {
      tr: 'Güç Çekici & Hassas Zamanlama',
      en: 'Timing Hammer & Power Striker',
      de: 'Krafthammer & Präzision',
      es: 'Martillo de Fuerza y Precisión',
      fr: 'Marteau de Force & Précision'
    };
    const descs = {
      tr: 'Gösterge tam tepedeki %100 altın zili gösterdiğinde VUR! (3 Vuruş Hakkın Var)',
      en: 'Hit when the power meter reaches the 100% Golden Bell! (3 Hits)',
      de: 'Triff, wenn die Anzeige die 100% Goldene Glocke erreicht! (3 Schläge)',
      es: '¡Golpea cuando el medidor llegue al 100% de la Campana Dorada! (3 Golpes)',
      fr: 'Frappez quand la jauge atteint la Cloche Dorée 100% ! (3 Coups)'
    };
    const hitBtnLabels = {
      tr: '🔨 VUR! (TIKLA)',
      en: '🔨 HIT! (TAP)',
      de: '🔨 SCHLAGEN! (TIPPEN)',
      es: '🔨 ¡GOLPEAR! (TOCAR)',
      fr: '🔨 FRAPPER ! (CLIQUER)'
    };
    const attemptsLabels = {
      tr: 'Kalan Vuruş',
      en: 'Hits Left',
      de: 'Schläge übrig',
      es: 'Intentos restantes',
      fr: 'Coups restants'
    };

    let timeLeft = 12;
    let attemptsLeft = 3;
    let animId = null;
    let currentPower = 0;
    let direction = 1;
    let speed = 2.4;
    let canHit = true;

    this.container.innerHTML = `
      <div class="minigame-card text-center" style="max-width: 440px;">
        <div class="mg-stakes-badge">🏆 1.ye +15 🪙 & Eşya!   💀 Sonuncuya -5 🪙 Ceza!</div>
        <h2>🔨 ${titles[lang] || titles.tr}</h2>
        <p>${descs[lang] || descs.tr}</p>
        <div class="minigame-stats">
          <div class="badge-time">⏱️ <span id="th-timer">${timeLeft}</span>s</div>
          <div class="badge-score">🎯 <span id="th-attempts">${attemptsLeft}</span> ${attemptsLabels[lang] || attemptsLabels.tr}</div>
          <div class="badge-score">🪙 Skor: <span id="th-score">0</span></div>
        </div>

        <div class="hammer-striker-wrapper" style="margin: 16px auto; width: 100%; max-width: 340px; background: #0F172A; border-radius: 16px; padding: 14px; box-sizing: border-box; border: 3px solid #334155; box-shadow: inset 0 2px 8px rgba(0,0,0,0.5);">
          <!-- Top Bell -->
          <div class="striker-bell" id="striker-bell" style="font-size: 32px; filter: drop-shadow(0 2px 6px rgba(234,179,8,0.5)); transition: transform 0.15s ease;">🔔 100</div>
          
          <!-- Track & Bar -->
          <div class="striker-track" style="position: relative; height: 32px; background: #1E293B; border-radius: 12px; margin: 12px 0; overflow: hidden; border: 2px solid #475569;">
            <div id="striker-fill" style="height: 100%; width: 0%; background: linear-gradient(90deg, #3B82F6 0%, #10B981 60%, #F59E0B 85%, #EF4444 95%, #FACC15 100%); transition: none; border-radius: 10px;"></div>
            <div style="position: absolute; right: 0; top: 0; width: 8%; height: 100%; background: rgba(254, 240, 138, 0.4); border-left: 2px dashed #FEF08A;"></div>
          </div>

          <div style="display: flex; justify-content: space-between; font-size: 11px; font-weight: 800; color: #94A3B8; padding: 0 4px;">
            <span>0%</span>
            <span>50%</span>
            <span>85%</span>
            <span style="color: #FACC15;">🎯 100% ZİL</span>
          </div>

          <!-- Impact Message -->
          <div id="th-feedback" style="min-height: 28px; margin-top: 10px; font-weight: 900; font-size: 16px; color: #F8FAFC;">
            Zamanı yakala ve vur!
          </div>
        </div>

        <button class="mash-btn" id="btn-hammer-hit" style="width: 100%; max-width: 320px; font-size: 20px; padding: 14px; background: #EF4444; color: white; border: none; border-radius: 16px; box-shadow: 0 6px 0 #B91C1C; cursor: pointer; touch-action: manipulation; user-select: none;">
          ${hitBtnLabels[lang] || hitBtnLabels.tr}
        </button>
      </div>
    `;

    const fillElem = document.getElementById('striker-fill');
    const bellElem = document.getElementById('striker-bell');
    const scoreElem = document.getElementById('th-score');
    const attemptsElem = document.getElementById('th-attempts');
    const feedbackElem = document.getElementById('th-feedback');
    const timerElem = document.getElementById('th-timer');
    const hitBtn = document.getElementById('btn-hammer-hit');

    // Oscillation loop
    const loop = () => {
      if (this.gameFinished) return;
      currentPower += direction * speed;
      if (currentPower >= 100) {
        currentPower = 100;
        direction = -1;
      } else if (currentPower <= 0) {
        currentPower = 0;
        direction = 1;
      }
      if (fillElem) fillElem.style.width = `${currentPower}%`;
      animId = requestAnimationFrame(loop);
    };
    animId = requestAnimationFrame(loop);

    const onHit = (e) => {
      if (e) { e.preventDefault(); e.stopPropagation(); }
      if (!canHit || this.gameFinished || attemptsLeft <= 0) return;
      canHit = false;

      let hitScore = 0;
      let text = '';
      if (currentPower >= 96) {
        hitScore = 50;
        text = '🔔 DİNG DİNG! 100 PUANLIK MÜKEMMEL VURUŞ! (+50)';
        AudioPlayer.playStarFanfare();
        if (bellElem) {
          bellElem.style.transform = 'scale(1.4) rotate(15deg)';
          setTimeout(() => { if (bellElem) bellElem.style.transform = 'scale(1)'; }, 300);
        }
      } else if (currentPower >= 85) {
        hitScore = 35;
        text = '💥 GÜÇLÜ VURUŞ! Harika zamanlama! (+35)';
        AudioPlayer.playCoinSound();
      } else if (currentPower >= 60) {
        hitScore = 20;
        text = '⚡ Fena Değil! (+20)';
        AudioPlayer.playClick();
      } else {
        hitScore = 10;
        text = '💨 Zayıf Vuruş! (+10)';
        AudioPlayer.playClick();
      }

      this.score += hitScore;
      scoreElem.innerText = this.score;
      feedbackElem.innerText = text;
      attemptsLeft--;
      attemptsElem.innerText = attemptsLeft;

      if (attemptsLeft <= 0) {
        setTimeout(() => {
          if (animId) cancelAnimationFrame(animId);
          this.end();
        }, 1100);
      } else {
        speed += 0.8;
        setTimeout(() => {
          canHit = true;
          if (feedbackElem) feedbackElem.innerText = 'Sıradaki vuruşa hazırlan!';
        }, 700);
      }
    };

    hitBtn.addEventListener('pointerdown', onHit);

    const keyHandler = (e) => {
      if (e.code === 'Space') {
        onHit(e);
      }
    };
    window.addEventListener('keydown', keyHandler);

    this.timerInterval = setInterval(() => {
      timeLeft--;
      if (timerElem) timerElem.innerText = timeLeft;
      AudioPlayer.playCountdown(timeLeft <= 3);

      if (timeLeft <= 0) {
        window.removeEventListener('keydown', keyHandler);
        if (animId) cancelAnimationFrame(animId);
        this.end();
      }
    }, 1000);
  }
}

const MiniGames = new MiniGameManager();


/* =================== 7. LOCAL GAME SERVER (STANDALONE ENGINE) =================== */

// ============================================================================
// STANDALONE IN-BROWSER GAME ENGINE (Local / Bot / Pass-and-Play Mode)
// Enables the game to run 100% offline from a single HTML file without Node.js!
// ============================================================================

function generateBoardForTheme(theme = 'istanbul') {
  // Aliases for backward compatibility
  if (theme === 'cyber') theme = 'tokyo';
  if (theme === 'candy') theme = 'paris';
  if (theme === 'tropics') theme = 'istanbul';

  if (theme === 'tokyo') {
    return [
      { id: 0, type: 'start', title: 'Shibuya Meydanı', desc: '+10 Altın Başlangıç Bonusu!', icon: 'flag', color: '#10B981' },
      { id: 1, type: 'coin', amount: 4, title: 'Akihabara Tech', desc: '+4 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
      { id: 2, type: 'mystery', title: 'Gacha Kapsülü', desc: 'Gizemli anime sürprizi!', icon: 'sparkles', color: '#EC4899' },
      { id: 3, type: 'coin', amount: 5, title: 'Shinjuku Neon', desc: '+5 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
      { id: 4, type: 'freeze', title: 'EMP Siber Şok', desc: 'Sistem dondu! 1 tur eşya kullanamazsın!', icon: 'zap', color: '#0284C7' },
      { id: 5, type: 'shop', title: 'Harajuku Market', desc: 'Fütüristik eşyalar satın al!', icon: 'shopping-bag', color: '#F59E0B' },
      { id: 6, type: 'coin', amount: 6, title: 'Ginza Lüksü', desc: '+6 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
      { id: 7, type: 'star', title: 'Tokyo Skytree', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
      { id: 8, type: 'warp', target: 20, title: 'Shinkansen Hızlı Tren', desc: '20. karoya ışınlan!', icon: 'zap', color: '#06B6D4' },
      { id: 9, type: 'coin', amount: 4, title: 'Roppongi Gece', desc: '+4 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 10, type: 'jail', title: 'Siber Kodes', desc: '1 tur kilitli kal veya 5 altın kefalet öde!', icon: 'shield', color: '#DC2626' },
      { id: 11, type: 'trap', penalty: 5, title: 'Neon Aşırı Yükleme', desc: '-5 Altın hasarı!', icon: 'flame', color: '#EF4444' },
      { id: 12, type: 'mystery', title: 'Şans Kedisi Maneki', desc: 'Şans ruletini çevir!', icon: 'sparkles', color: '#EC4899' },
      { id: 13, type: 'bank', title: 'Tokyo Merkez Bankası', desc: 'Biriken havuz altınlarını tek seferde topla!', icon: 'coins', color: '#10B981' },
      { id: 14, type: 'shop', title: 'Akiba Dükkanı', desc: 'Siber eşyalar!', icon: 'shopping-bag', color: '#F59E0B' },
      { id: 15, type: 'star', title: 'Tokyo Kulesi', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
      { id: 16, type: 'coin', amount: 4, title: 'Ueno Parkı', desc: '+4 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 17, type: 'slip', steps: -3, title: 'Islak Ramen Zemini', desc: '3 adım geri kaydın!', icon: 'undo-2', color: '#EAB308' },
      { id: 18, type: 'mystery', title: 'Torii Çarkı', desc: 'Kutsal tapınak ödülü!', icon: 'sparkles', color: '#EC4899' },
      { id: 19, type: 'coin', amount: 5, title: 'Asakusa Feneri', desc: '+5 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 20, type: 'duel', title: 'Samuray Düellosu', desc: 'Rakipten altın kap!', icon: 'swords', color: '#EC4899' },
      { id: 21, type: 'reverse', title: 'Zaman Bükülmesi', desc: 'Sonraki zarda ters yöne yürü!', icon: 'undo-2', color: '#9333EA' },
      { id: 22, type: 'coin', amount: 6, title: 'Tsukiji Balık Pazarı', desc: '+6 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 23, type: 'star', title: 'Fuji Dağı Kaidesi', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
      { id: 24, type: 'tax', title: 'Tokyo Belediye Vergisi', desc: '%25 Altın cezası en fakir oyuncuya gider!', icon: 'coins', color: '#E11D48' },
      { id: 25, type: 'mystery', title: 'Sakura Sandığı', desc: 'Şansını sına!', icon: 'sparkles', color: '#EC4899' },
      { id: 26, type: 'shop', title: 'Shibuya Alışveriş', desc: 'Nadir taktik eşyaları!', icon: 'shopping-bag', color: '#F59E0B' },
      { id: 27, type: 'coin', amount: 8, title: 'İmparatorluk Sarayı', desc: '+8 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 28, type: 'trap', penalty: 5, title: 'Yakuza Pususu', desc: '-5 Altın kaybettin!', icon: 'flame', color: '#EF4444' },
      { id: 29, type: 'duel', title: 'Sumo Arenası', desc: 'Liderden altın arakla!', icon: 'swords', color: '#EC4899' },
      { id: 30, type: 'coin', amount: 5, title: 'Omotesando Caddesi', desc: '+5 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 31, type: 'star', title: 'Meiji Tapınağı', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' }
    ];
  }

  if (theme === 'paris') {
    return [
      { id: 0, type: 'start', title: 'Eyfel Kulesi', desc: '+10 Altın Başlangıç Bonusu!', icon: 'flag', color: '#10B981' },
      { id: 1, type: 'coin', amount: 4, title: 'Champs-Élysées', desc: '+4 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
      { id: 2, type: 'mystery', title: 'Louvre Tablosu', desc: 'Mona Lisa gülümsedi!', icon: 'sparkles', color: '#8B5CF6' },
      { id: 3, type: 'coin', amount: 5, title: 'Kruvasan Fırını', desc: '+5 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
      { id: 4, type: 'trap', penalty: 4, title: 'Parke Taşı Çukuru', desc: '-4 Altın kaybettin!', icon: 'flame', color: '#EF4444' },
      { id: 5, type: 'shop', title: 'Fransız Butiği', desc: 'Lüks parti eşyaları al!', icon: 'shopping-bag', color: '#F59E0B' },
      { id: 6, type: 'coin', amount: 6, title: 'Notre-Dame Avlusu', desc: '+6 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
      { id: 7, type: 'star', title: 'Zafer Takı', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
      { id: 8, type: 'warp', target: 18, title: 'Sen Nehri Teknesi', desc: '18. karoya yüz!', icon: 'zap', color: '#06B6D4' },
      { id: 9, type: 'coin', amount: 4, title: 'Montmartre Tepesi', desc: '+4 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 10, type: 'jail', title: 'Bastille Kalesi', desc: '1 tur kilitli kal veya 5 altın kefalet öde!', icon: 'shield', color: '#DC2626' },
      { id: 11, type: 'tax', title: 'Lüks Moda Vergisi', desc: '%25 Altın cezası en fakir oyuncuya dağıtılır!', icon: 'coins', color: '#E11D48' },
      { id: 12, type: 'mystery', title: 'Cam Piramit', desc: 'Rulet çarkını çevir!', icon: 'sparkles', color: '#8B5CF6' },
      { id: 13, type: 'bank', title: 'Banque de France', desc: 'Kasadaki tüm altınları süpür!', icon: 'coins', color: '#10B981' },
      { id: 14, type: 'shop', title: 'Parfüm Marketi', desc: 'Taktik eşyaları!', icon: 'shopping-bag', color: '#F59E0B' },
      { id: 15, type: 'star', title: 'Sacre-Coeur', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
      { id: 16, type: 'coin', amount: 4, title: 'Latin Mahallesi', desc: '+4 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 17, type: 'slip', steps: -3, title: 'Eriyen Dondurma', desc: '3 adım geri kaydın!', icon: 'undo-2', color: '#EAB308' },
      { id: 18, type: 'mystery', title: 'Moulin Rouge Çarkı', desc: 'Büyük ödüller!', icon: 'sparkles', color: '#8B5CF6' },
      { id: 19, type: 'coin', amount: 5, title: 'Lüksemburg Bahçesi', desc: '+5 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 20, type: 'duel', title: 'Eskrim Meydanı', desc: 'Rakipten altın kap!', icon: 'swords', color: '#EC4899' },
      { id: 21, type: 'reverse', title: 'Sen Nehri Akıntısı', desc: 'Sonraki zarda ters yöne yürü!', icon: 'undo-2', color: '#9333EA' },
      { id: 22, type: 'coin', amount: 6, title: 'Opera Garnier', desc: '+6 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 23, type: 'star', title: 'Pantheon Kaidesi', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
      { id: 24, type: 'freeze', title: 'Paris Kar Fırtınası', desc: '1 tur eşya kullanımın engellendi!', icon: 'zap', color: '#0284C7' },
      { id: 25, type: 'mystery', title: 'Sanatçı Sandığı', desc: 'Şansını sına!', icon: 'sparkles', color: '#8B5CF6' },
      { id: 26, type: 'shop', title: 'Fransız Butiği', desc: 'Eşya kuşan!', icon: 'shopping-bag', color: '#F59E0B' },
      { id: 27, type: 'coin', amount: 8, title: 'Vendome Meydanı', desc: '+8 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 28, type: 'trap', penalty: 5, title: 'Metro Arızası', desc: '-5 Altın!', icon: 'flame', color: '#EF4444' },
      { id: 29, type: 'duel', title: 'Şövalye Düellosu', desc: 'Liderden altın arakla!', icon: 'swords', color: '#EC4899' },
      { id: 30, type: 'coin', amount: 5, title: 'Saint-Germain', desc: '+5 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 31, type: 'star', title: 'Louvre Sarayı', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' }
    ];
  }

  if (theme === 'newyork') {
    return [
      { id: 0, type: 'start', title: 'Times Square', desc: '+10 Altın Başlangıç Bonusu!', icon: 'flag', color: '#10B981' },
      { id: 1, type: 'coin', amount: 4, title: 'Broadway Işıkları', desc: '+4 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
      { id: 2, type: 'mystery', title: 'Sarı Taksi Şansı', desc: 'Sürpriz yolculuk!', icon: 'sparkles', color: '#F59E0B' },
      { id: 3, type: 'coin', amount: 5, title: '5th Avenue Alışverişi', desc: '+5 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
      { id: 4, type: 'trap', penalty: 4, title: 'Buhar Rogarı', desc: '-4 Altın kaybettin!', icon: 'flame', color: '#EF4444' },
      { id: 5, type: 'shop', title: 'Manhattan Market', desc: 'Güçlü eşyalar satın al!', icon: 'shopping-bag', color: '#F59E0B' },
      { id: 6, type: 'coin', amount: 6, title: 'Wall Street Borsası', desc: '+6 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
      { id: 7, type: 'star', title: 'Empire State', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
      { id: 8, type: 'warp', target: 20, title: 'Subway Ekspres', desc: '20. karoya fırla!', icon: 'zap', color: '#06B6D4' },
      { id: 9, type: 'coin', amount: 4, title: 'SoHo Sanat', desc: '+4 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 10, type: 'jail', title: 'Rikers Kodesi', desc: '1 tur kilitli kal veya 5 altın kefalet öde!', icon: 'shield', color: '#DC2626' },
      { id: 11, type: 'tax', title: 'Wall Street Vergisi', desc: '%25 Altın cezası en fakir oyuncuya dağıtılır!', icon: 'coins', color: '#E11D48' },
      { id: 12, type: 'mystery', title: 'Gizemli Çatı Katı', desc: 'Rulet çarkını çevir!', icon: 'sparkles', color: '#F59E0B' },
      { id: 13, type: 'bank', title: 'Federal Reserve Bankası', desc: 'Kasadaki tüm altınları topla!', icon: 'coins', color: '#10B981' },
      { id: 14, type: 'shop', title: 'Brooklyn Deposu', desc: 'Taktik eşyaları!', icon: 'shopping-bag', color: '#F59E0B' },
      { id: 15, type: 'star', title: 'Özgürlük Heykeli', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
      { id: 16, type: 'coin', amount: 4, title: 'Central Park', desc: '+4 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 17, type: 'slip', steps: -3, title: 'Muzlu Donut Zemini', desc: '3 adım geri kaydın!', icon: 'undo-2', color: '#EAB308' },
      { id: 18, type: 'mystery', title: 'Grand Central Saati', desc: 'Büyük ödüller!', icon: 'sparkles', color: '#F59E0B' },
      { id: 19, type: 'coin', amount: 5, title: 'DUMBO Manzarası', desc: '+5 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 20, type: 'duel', title: 'Boks Ringi', desc: 'Rakipten altın kap!', icon: 'swords', color: '#EC4899' },
      { id: 21, type: 'freeze', title: 'Blizzard Kar Fırtınası', desc: '1 tur eşya kullanımın engellendi!', icon: 'zap', color: '#0284C7' },
      { id: 22, type: 'coin', amount: 6, title: 'Chrysler Binası', desc: '+6 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 23, type: 'star', title: 'Brooklyn Köprüsü', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
      { id: 24, type: 'reverse', title: 'Trafik Tıkanıklığı', desc: 'Ters yöne gitmek zorundasın!', icon: 'undo-2', color: '#9333EA' },
      { id: 25, type: 'mystery', title: 'Broadway Sandığı', desc: 'Şansını sına!', icon: 'sparkles', color: '#F59E0B' },
      { id: 26, type: 'shop', title: 'Manhattan Market', desc: 'Eşya kuşan!', icon: 'shopping-bag', color: '#F59E0B' },
      { id: 27, type: 'coin', amount: 8, title: 'Federal Reserve Altını', desc: '+8 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 28, type: 'trap', penalty: 5, title: 'Park Cezası', desc: '-5 Altın!', icon: 'flame', color: '#EF4444' },
      { id: 29, type: 'duel', title: 'Wall Street Düellosu', desc: 'Liderden altın arakla!', icon: 'swords', color: '#EC4899' },
      { id: 30, type: 'coin', amount: 5, title: 'Greenwich Village', desc: '+5 Altın!', icon: 'coins', color: '#3B82F6' },
      { id: 31, type: 'star', title: 'One World Observatory', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' }
    ];
  }

  // Default: 'istanbul' (İstanbul - Boğazın İncisi)
  return [
    { id: 0, type: 'start', title: 'Eminönü İskelesi', desc: '+10 Altın Başlangıç Bonusu!', icon: 'flag', color: '#10B981' },
    { id: 1, type: 'coin', amount: 4, title: 'Mısır Çarşısı', desc: '+4 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
    { id: 2, type: 'mystery', title: 'Kapalıçarşı Sandığı', desc: 'Tarihi bir hazine sürprizi!', icon: 'sparkles', color: '#8B5CF6' },
    { id: 3, type: 'coin', amount: 5, title: 'Sultanahmet Meydanı', desc: '+5 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
    { id: 4, type: 'trap', penalty: 4, title: 'Tarihi Arnavutkaldırımı', desc: '-4 Altın düşürdün!', icon: 'flame', color: '#EF4444' },
    { id: 5, type: 'shop', title: 'Kapalıçarşı Bedesteni', desc: 'Güçlü eşyalar satın al!', icon: 'shopping-bag', color: '#F59E0B' },
    { id: 6, type: 'coin', amount: 6, title: 'Karaköy Rıhtımı', desc: '+6 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
    { id: 7, type: 'star', title: 'Galata Kulesi', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
    { id: 8, type: 'warp', target: 16, title: 'Şehir Hatları Vapuru', desc: '16. karoya yüz!', icon: 'zap', color: '#06B6D4' },
    { id: 9, type: 'coin', amount: 4, title: 'İstiklal Caddesi', desc: '+4 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
    { id: 10, type: 'duel', title: 'Kırkpınar Er Meydanı', desc: 'Rakipten altın kap!', icon: 'swords', color: '#EC4899' },
    { id: 11, type: 'tax', title: 'Boğaz Köprüsü Gişesi', desc: '%25 Altın cezası en fakir oyuncuya dağıtılır!', icon: 'coins', color: '#E11D48' },
    { id: 12, type: 'mystery', title: 'Yerebatan Sarnıcı', desc: 'Rulet çarkını çevir!', icon: 'sparkles', color: '#8B5CF6' },
    { id: 13, type: 'bank', title: 'Topkapı Hazine Kasası', desc: 'Kasadaki tüm altınları tek seferde kap!', icon: 'coins', color: '#10B981' },
    { id: 14, type: 'shop', title: 'Tahtakale Pazarı', desc: 'Nadir taktik eşyaları!', icon: 'shopping-bag', color: '#F59E0B' },
    { id: 15, type: 'star', title: 'Kız Kulesi Kaidesi', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
    { id: 16, type: 'coin', amount: 4, title: 'Üsküdar Sahili', desc: '+4 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
    { id: 17, type: 'jail', title: 'Yedikule Zindanları', desc: '1 tur kilitli kal veya 5 altın kefalet öde!', icon: 'shield', color: '#DC2626' },
    { id: 18, type: 'mystery', title: 'Çamlıca Tepesi', desc: 'Büyük ödüller veya sürprizler!', icon: 'sparkles', color: '#8B5CF6' },
    { id: 19, type: 'coin', amount: 5, title: 'Kadıköy Boğa Meydanı', desc: '+5 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
    { id: 20, type: 'duel', title: 'Boğaziçi Arenası', desc: 'Rakiplerle düello!', icon: 'swords', color: '#EC4899' },
    { id: 21, type: 'freeze', title: 'Karadeniz Kar Fırtınası', desc: 'Buz fırtınası! 1 tur eşya kullanamazsın!', icon: 'zap', color: '#0284C7' },
    { id: 22, type: 'coin', amount: 6, title: 'Dolmabahçe Sarayı', desc: '+6 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
    { id: 23, type: 'star', title: 'Ortaköy Camii Kaidesi', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' },
    { id: 24, type: 'reverse', title: 'Boğaz Ters Akıntısı', desc: 'Pusula bozuldu! Sonraki zarda geriye yürüyeceksin!', icon: 'undo-2', color: '#9333EA' },
    { id: 25, type: 'mystery', title: 'Balat Renkli Sandık', desc: 'Şansını sına!', icon: 'sparkles', color: '#8B5CF6' },
    { id: 26, type: 'shop', title: 'Beşiktaş Çarşısı', desc: 'Zafer için eşya kuşan!', icon: 'shopping-bag', color: '#F59E0B' },
    { id: 27, type: 'coin', amount: 8, title: 'Boğaziçi Yalıları', desc: '+8 Altın!', icon: 'coins', color: '#3B82F6' },
    { id: 28, type: 'trap', penalty: 4, title: 'Trafik Yoğunluğu', desc: '-4 Altın kaybettin!', icon: 'flame', color: '#EF4444' },
    { id: 29, type: 'duel', title: 'Haliç Hesaplaşması', desc: 'Liderden altın arakla!', icon: 'swords', color: '#EC4899' },
    { id: 30, type: 'coin', amount: 5, title: 'Taksim Meydanı', desc: '+5 Altın kazandın!', icon: 'coins', color: '#3B82F6' },
    { id: 31, type: 'star', title: 'Ayasofya Kaidesi', desc: '20 Altına 1 Altın Yıldız!', icon: 'star', color: '#FBBF24' }
  ];
}

// BOARD_TILES already declared in board-map.js

const BOT_NAMES = [
  { name: 'Lego Usta', avatar: 'builder', title: 'Mimar', color: '#3B82F6', personality: 'balanced' },
  { name: 'Yeşil Dino', avatar: 'dino', title: 'Parti Canavarı', color: '#10B981', personality: 'chaotic' },
  { name: 'Siber Kedi', avatar: 'cat', title: 'Hızlı Patiler', color: '#EC4899', personality: 'greedy' },
  { name: 'Gandi Bot', avatar: 'wizard', title: 'Büyücü', color: '#8B5CF6', personality: 'strategic' },
  { name: 'Robo-X', avatar: 'robot', title: 'Hesap Uzmanı', color: '#06B6D4', personality: 'balanced' },
  { name: 'Dedektif', avatar: 'detective', title: 'Gizem Avcısı', color: '#F59E0B', personality: 'strategic' }
];

class LocalRoom {
  constructor(roomId, hostSessionId, hostName, settings = {}) {
    this.id = roomId;
    this.hostSessionId = hostSessionId;
    this.state = 'lobby'; // 'lobby' | 'playing' | 'minigame' | 'gameover'
    this.totalRounds = settings.totalRounds || 10;
    this.mapTheme = settings.mapTheme || 'tropics';
    this.currentRound = 1;
    this.turnIndex = 0; // index in players array
    this.players = []; // list of Player objects
    this.activeStarTile = 7; // initial star tile location
    this.board = generateBoardForTheme(this.mapTheme);
    this.trapsOnBoard = {}; // tileIndex -> ownerPlayerId
    this.pendingTrades = {}; // tradeId -> TradeObject
    this.log = []; // recent event feed
    this.minigame = null;
    this.createdAt = Date.now();
    this.turnTimer = null;
    this.botActionTimeout = null;
    this.isProcessingTurn = false;
    this.gameSpeed = 1;
  }

  addPlayer(sessionId, name, avatar = 'builder', diceSkin = 'default', level = 1, title = 'Acemi Zarcı', ws = null, hat = 'none', customColor = null) {
    let existing = this.players.find(p => p.sessionId === sessionId);
    if (existing) {
      // Reconnection!
      existing.ws = ws;
      existing.isBot = false;
      existing.disconnected = false;
      existing.name = name || existing.name;
      existing.avatar = avatar || existing.avatar;
      if (hat && hat !== 'none') existing.hat = hat;
      if (customColor) existing.color = customColor;
      this.addLog(`🌟 ${existing.name} oyuna geri döndü!`);
      return existing;
    }

    if (this.players.length >= 6) return null;

    const colors = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#06B6D4', '#1E293B'];
    const playerColor = customColor || colors[this.players.length % colors.length];

    const newPlayer = {
      id: 'p_' + Math.random().toString(36).substr(2, 6),
      sessionId,
      name: name || `Oyuncu ${this.players.length + 1}`,
      avatar,
      hat: hat || 'none',
      diceSkin,
      level: level || 1,
      title: title || 'Acemi Zarcı',
      color: playerColor,
      position: 0,
      coins: 15, // starting coins
      stars: 0,
      inventory: [],
      shieldActive: 0, // turns remaining
      jailedTurns: 0,
      frozenTurns: 0,
      reverseNext: false,
      doubleDiceActive: false,
      ghostCloakActive: 0,
      fixedRollNext: null,
      isBot: false,
      disconnected: false,
      ws: ws
    };

    this.players.push(newPlayer);
    this.addLog(`👋 ${newPlayer.name} partiye katıldı!`);
    return newPlayer;
  }

  updatePlayerProfile(sessionId, profileData = {}) {
    const player = this.players.find(p => p.sessionId === sessionId);
    if (!player) return;
    if (profileData.name) player.name = profileData.name;
    if (profileData.avatar) player.avatar = profileData.avatar;
    if (profileData.hat) player.hat = profileData.hat;
    if (profileData.color) player.color = profileData.color;
    if (profileData.diceSkin) player.diceSkin = profileData.diceSkin;
    if (profileData.title) player.title = profileData.title;
  }

  addBot(personality = null) {
    if (this.players.length >= 6) return null;
    const botTemplate = BOT_NAMES[this.players.length % BOT_NAMES.length];
    const colors = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#06B6D4'];
    const botColor = colors[this.players.length % colors.length];
    const botHats = ['crown', 'wizard', 'pirate', 'cat_ears', 'party_hat', 'visor', 'detective', 'viking'];
    const randomHat = botHats[Math.floor(Math.random() * botHats.length)];

    const botPlayer = {
      id: 'bot_' + Math.random().toString(36).substr(2, 6),
      sessionId: 'bot_sess_' + Math.random().toString(36).substr(2, 8),
      name: `[BOT] ${botTemplate.name}`,
      avatar: botTemplate.avatar,
      hat: randomHat,
      diceSkin: 'neon',
      level: Math.floor(Math.random() * 8) + 3,
      title: botTemplate.title,
      color: botColor,
      position: 0,
      coins: 15,
      stars: 0,
      inventory: ['double_dice'],
      shieldActive: 0,
      jailedTurns: 0,
      frozenTurns: 0,
      reverseNext: false,
      doubleDiceActive: false,
      ghostCloakActive: 0,
      fixedRollNext: null,
      isBot: true,
      personality: personality || botTemplate.personality,
      disconnected: false,
      ws: null
    };

    this.players.push(botPlayer);
    this.addLog(`🤖 ${botPlayer.name} oyuna eklendi!`);
    return botPlayer;
  }

  removePlayer(sessionId) {
    const idx = this.players.findIndex(p => p.sessionId === sessionId);
    if (idx !== -1) {
      const removed = this.players.splice(idx, 1)[0];
      this.addLog(`🚪 ${removed.name} ayrıldı.`);
      if (this.turnIndex >= this.players.length) {
        this.turnIndex = 0;
      }
    }
  }

  handleDisconnect(sessionId) {
    const player = this.players.find(p => p.sessionId === sessionId);
    if (!player) return;

    if (this.state === 'lobby') {
      this.removePlayer(sessionId);
    } else {
      // During game: Bot seamlessly takes over!
      player.isBot = true;
      player.disconnected = true;
      player.ws = null;
      this.addLog(`🤖 ${player.name} ayrıldı, yerine akıllı bot geçti!`);
      // If it was currently their turn, trigger bot turn
      if (this.getCurrentPlayer() && this.getCurrentPlayer().sessionId === sessionId) {
        this.scheduleBotTurn();
      }
    }
  }

  getCurrentPlayer() {
    return this.players[this.turnIndex] || null;
  }

  addLog(message) {
    this.log.unshift({
      id: Math.random().toString(36).substr(2, 6),
      time: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      text: message
    });
    if (this.log.length > 25) this.log.pop();
  }

  broadcast(type, payload = {}) {
    const message = JSON.stringify({ type, ...payload });
    this.players.forEach(p => {
      if (p.ws && p.ws.readyState === WebSocket.OPEN) {
        p.ws.send(message);
      }
    });
  }

  broadcastState() {
    this.broadcast('state_update', {
      roomId: this.id,
      state: this.state,
      mapTheme: this.mapTheme,
      totalRounds: this.totalRounds,
      currentRound: this.currentRound,
      turnIndex: this.turnIndex,
      activeStarTile: this.activeStarTile,
      trapsOnBoard: this.trapsOnBoard,
      board: this.board,
      players: this.players.map(p => ({
        id: p.id,
        sessionId: p.sessionId,
        name: p.name,
        avatar: p.avatar,
        hat: p.hat || 'none',
        diceSkin: p.diceSkin,
        level: p.level,
        title: p.title,
        color: p.color,
        position: p.position,
        coins: p.coins,
        stars: p.stars,
        inventory: p.inventory,
        shieldActive: p.shieldActive || 0,
        ghostCloakActive: p.ghostCloakActive || 0,
        doubleDiceActive: !!p.doubleDiceActive,
        fixedRollNext: p.fixedRollNext || null,
        jailedTurns: p.jailedTurns,
        frozenTurns: p.frozenTurns,
        reverseNext: p.reverseNext,
        isBot: p.isBot,
        disconnected: p.disconnected
      })),
      log: this.log.slice(0, 15)
    });
  }

  startGame() {
    if (this.players.length < 1) return false;
    // Auto fill with bots if single player
    while (this.players.length < 4) {
      this.addBot();
    }

    this.state = 'playing';
    this.currentRound = 1;
    this.turnIndex = 0;
    this.activeStarTile = [7, 15, 23, 31][Math.floor(Math.random() * 4)];
    this.addLog(`🚀 Parti başladı! Toplam ${this.totalRounds} tur oynanacak. Yıldız kaidesi ${this.activeStarTile}. karoda!`);

    this.broadcastState();
    this.checkNextTurnAction();
    return true;
  }

  checkNextTurnAction() {
    clearTimeout(this.botActionTimeout);
    const current = this.getCurrentPlayer();
    if (!current) return;

    if (current.isBot) {
      this.scheduleBotTurn();
    }
  }

  scheduleBotTurn() {
    clearTimeout(this.botActionTimeout);
    const spd = this.gameSpeed || 1;
    this.botActionTimeout = setTimeout(() => {
      this.executeBotTurn();
    }, Math.max(250, Math.round(1600 / spd)));
  }

  executeBotTurn() {
    const bot = this.getCurrentPlayer();
    if (!bot || !bot.isBot || this.state !== 'playing') return;

    // Bot decision: Maybe use item?
    if (bot.inventory.length > 0) {
      const itemToUse = bot.inventory[0];
      if (itemToUse === 'double_dice' && !bot.doubleDiceActive) {
        this.useItem(bot.sessionId, 'double_dice');
      } else if (itemToUse === 'magnet' && Math.random() > 0.4) {
        this.useItem(bot.sessionId, 'magnet');
      } else if (itemToUse === 'shield' && bot.shieldActive === 0) {
        this.useItem(bot.sessionId, 'shield');
      } else if (itemToUse === 'banana' && Math.random() > 0.5) {
        this.useItem(bot.sessionId, 'banana');
      }
    }

    // Bot rolls dice after small pause
    const spd = this.gameSpeed || 1;
    setTimeout(() => {
      this.rollDice(bot.sessionId);
    }, Math.max(180, Math.round(800 / spd)));
  }

  rollDice(sessionId) {
    if (this.isProcessingTurn) return;
    const player = this.getCurrentPlayer();
    if (!player || player.sessionId !== sessionId || this.state !== 'playing') return;

    this.isProcessingTurn = true;

    const spd = this.gameSpeed || 1;

    // Check if player is jailed
    if (player.jailedTurns > 0) {
      if (player.coins >= 5) {
        player.coins -= 5;
        player.jailedTurns = 0;
        this.addLog(`🔑 ${player.name} 5 altın kefalet ödeyerek Kodes'ten serbest kaldı!`);
      } else {
        player.jailedTurns--;
        this.addLog(`⛓️ ${player.name} Kodes cezasını çekiyor, bu turu pas geçti!`);
        this.broadcastState();
        setTimeout(() => this.finishTurn(), Math.max(300, Math.round(1200 / spd)));
        return;
      }
    }

    let die1 = player.fixedRollNext ? player.fixedRollNext : (Math.floor(Math.random() * 6) + 1);
    const wasFixed = !!player.fixedRollNext;
    player.fixedRollNext = null;
    let die2 = null;
    let totalRoll = die1;

    if (player.doubleDiceActive) {
      die2 = Math.floor(Math.random() * 6) + 1;
      totalRoll = die1 + die2;
      player.doubleDiceActive = false;
      this.addLog(`🎲 ${player.name} ÇİFT ZAR attı: [${die1}] + [${die2}] = ${totalRoll} adım!`);
    } else {
      if (wasFixed) {
        this.addLog(`🎯 ${player.name} Şanslı Altın Zarını attı: [${die1}]!`);
      } else {
        this.addLog(`🎲 ${player.name} zar attı: [${die1}]!`);
      }
    }

    // Broadcast dice roll event so client can play 3D dice rolling animation
    this.broadcast('dice_rolled', {
      playerId: player.id,
      playerName: player.name,
      die1,
      die2,
      totalRoll
    });

    // Move player step by step AFTER dice modal finishes and closes completely
    setTimeout(() => {
      this.movePlayerSteps(player, totalRoll);
    }, Math.max(300, Math.round(1500 / spd)));
  }

  movePlayerSteps(player, steps) {
    const isReverse = !!player.reverseNext;
    player.reverseNext = false;
    const effectiveSteps = isReverse ? -steps : steps;

    const oldPos = player.position;
    let newPos = (oldPos + effectiveSteps + this.board.length) % this.board.length;

    if (isReverse) {
      this.addLog(`🌀 Ters Yön Laneti devrede! ${player.name} ${steps} adım GERİYE yürüdü!`);
    }

    // Check if player passed or landed on start tile (forward only)
    if (!isReverse && oldPos + steps >= this.board.length) {
      player.coins += 10;
      this.addLog(`💰 ${player.name} Başlangıçtan geçti ve +10 Altın kazandı!`);
    }

    // Check if player passed by Bank tile (deposits 2 coins into the jackpot pool)
    if (!isReverse) {
      for (let s = 1; s <= steps; s++) {
        let passedPos = (oldPos + s) % this.board.length;
        if (this.board[passedPos] && this.board[passedPos].type === 'bank') {
          this.bankPool = (this.bankPool || 10) + 2;
          this.addLog(`🏦 ${player.name} Bankadan geçti ve kasaya +2 Altın faiz eklendi (Kasa: ${this.bankPool} 🪙)!`);
        }
      }
    }

    // Check if player passed by active Star tile along the way
    if (!isReverse) {
      for (let s = 1; s <= steps; s++) {
        let passedPos = (oldPos + s) % this.board.length;
        if (passedPos === this.activeStarTile) {
          // Player has chance to buy star!
          if (player.coins >= 20) {
            player.coins -= 20;
            player.stars += 1;
            this.addLog(`⭐ TEBRİKLER! ${player.name} 20 altına bir ALTIN YILDIZ satın aldı!`);
            this.relocateStar();
            break;
          } else {
            this.addLog(`✨ ${player.name} Yıldız kaidesinden geçti ama 20 altını yoktu (${player.coins}/20).`);
          }
        }
      }
    }

    player.position = newPos;
    this.broadcastState();

    // Trigger Tile Effect strictly after Monopoly-style hopping completes
    const spd = this.gameSpeed || 1;
    const hopDurationMs = Math.max(300, Math.round(((Math.abs(steps) * 380) + 400) / spd));
    setTimeout(() => {
      this.resolveTileEffect(player, newPos);
    }, hopDurationMs);
  }

  relocateStar() {
    const starCandidates = [3, 7, 11, 15, 19, 23, 27, 31].filter(idx => idx !== this.activeStarTile);
    this.activeStarTile = starCandidates[Math.floor(Math.random() * starCandidates.length)];
    this.addLog(`🌟 Yıldız yeni bir konuma ışınlandı: ${this.activeStarTile}. Karo!`);
  }

  resolveTileEffect(player, tileIndex) {
    const tile = this.board[tileIndex];
    const spd = this.gameSpeed || 1;

    // Check if there is a Banana Trap set here by another player
    if (this.trapsOnBoard[tileIndex] && this.trapsOnBoard[tileIndex] !== player.id) {
      if (player.ghostCloakActive > 0) {
        this.addLog(`👻 ${player.name} Hayalet Pelerin sayesinde muz kabuğu tuzağının üstünden süzülüp geçti!`);
      } else {
        delete this.trapsOnBoard[tileIndex];
        this.addLog(`🍌 Oooops! ${player.name} muz kabuğuna bastı ve 3 adım geri kaydı!`);
        player.position = (player.position - 3 + this.board.length) % this.board.length;
        this.broadcast('tile_event', {
          playerId: player.id,
          playerName: player.name,
          avatar: player.avatar,
          category: 'penalty',
          title: '🍌 MUZ KABUĞUNA BASTI!',
          message: `${player.name} muz kabuğuna basıp 360° takla attı ve 3 adım geri kaydı! 😂`,
          animation: 'banana_slip',
          sound: 'slip'
        });
        this.broadcastState();
        setTimeout(() => this.finishTurn(), Math.max(350, Math.round(1800 / spd)));
        return;
      }
    }

    // Check Ghost Cloak immunity against hazard tiles
    if (player.ghostCloakActive > 0 && (tile.type === 'trap' || tile.type === 'tax' || tile.type === 'jail' || tile.type === 'slip' || tile.type === 'freeze')) {
      this.addLog(`👻 Hayalet Pelerin devrede! ${player.name} ${tile.type.toUpperCase()} cezasını dokunmadan es geçti!`);
      this.broadcastState();
      setTimeout(() => this.finishTurn(), Math.max(250, Math.round(900 / spd)));
      return;
    }

    switch (tile.type) {
      case 'coin': {
        player.coins += tile.amount;
        this.addLog(`🪙 ${player.name} altın karosuna bastı: +${tile.amount} Altın!`);
        this.broadcast('tile_event', {
          playerId: player.id,
          playerName: player.name,
          avatar: player.avatar,
          category: 'reward',
          title: `🪙 +${tile.amount} ALTIN!`,
          message: `${player.name} hazine karosuna bastı ve ${tile.amount} altın kazandı!`,
          animation: 'coin_shower',
          amount: tile.amount,
          sound: 'coin'
        });
        this.broadcastState();
        setTimeout(() => this.finishTurn(), 2000);
        break;
      }

      case 'bank': {
        const pool = this.bankPool || 10;
        player.coins += pool;
        this.bankPool = 4;
        this.addLog(`🏦 PARTİ BANKASI! ${player.name} kasadaki ${pool} altını tek seferde süpürdü!`);
        this.broadcast('tile_event', {
          playerId: player.id,
          playerName: player.name,
          avatar: player.avatar,
          category: 'reward',
          title: `🏦 BANKA KASASI PATLADI! (+${pool} 🪙)`,
          message: `${player.name} biriken banka kasasındaki ${pool} altını tek hamlede cebe indirdi!`,
          animation: 'coin_shower',
          amount: pool,
          sound: 'fanfare'
        });
        this.broadcastState();
        setTimeout(() => this.finishTurn(), 2200);
        break;
      }

      case 'trap': {
        if (player.shieldActive > 0) {
          player.shieldActive--;
          this.addLog(`🛡️ ${player.name} Kalkanı sayesinde tuzağı savuşturdu!`);
          this.broadcast('tile_event', {
            playerId: player.id,
            playerName: player.name,
            avatar: player.avatar,
            category: 'neutral',
            title: '🛡️ KALKAN KORUDU!',
            message: `${player.name} tuzağa bastı ama koruma kalkanı hasarı tamamen engelledi!`,
            animation: 'shield_block',
            sound: 'shield'
          });
        } else {
          const penalty = tile.penalty || 5;
          const lostCoins = Math.min(player.coins, penalty);
          player.coins = Math.max(0, player.coins - penalty);
          this.addLog(`💥 ${player.name} tuzağa düştü: -${penalty} Altın!`);
          this.broadcast('tile_event', {
            playerId: player.id,
            playerName: player.name,
            avatar: player.avatar,
            category: 'penalty',
            title: `💥 DİKENLİ TUZAK! (-${penalty} Altın)`,
            message: `${player.name} kızgın tuzağa düştü ve ${lostCoins} altını çevreye saçıldı!`,
            animation: 'trap_explosion',
            amount: -penalty,
            sound: 'trap'
          });
        }
        this.broadcastState();
        setTimeout(() => this.finishTurn(), 2200);
        break;
      }

      case 'mystery':
        this.triggerMysteryEvent(player);
        break;

      case 'shop':
        this.triggerShop(player);
        break;

      case 'warp': {
        this.addLog(`🌀 ${player.name} hava geçidinden geçerek ${tile.target}. karoya ışınlandı!`);
        player.position = tile.target;
        this.broadcast('tile_event', {
          playerId: player.id,
          playerName: player.name,
          avatar: player.avatar,
          category: 'neutral',
          title: '🌀 IŞINLANMA GEÇİDİ!',
          message: `${player.name} gizemli portaldan geçerek ${tile.target}. karoya fırladı!`,
          animation: 'warp_portal',
          sound: 'warp'
        });
        this.broadcastState();
        setTimeout(() => this.finishTurn(), 2200);
        break;
      }

      case 'slip': {
        this.addLog(`🍌 ${player.name} kaygan zeminde 3 adım geri kaydı!`);
        player.position = (player.position - 3 + this.board.length) % this.board.length;
        this.broadcast('tile_event', {
          playerId: player.id,
          playerName: player.name,
          avatar: player.avatar,
          category: 'penalty',
          title: '🍌 KAYGAN ZEMİN!',
          message: `${player.name} dengesini kaybedip 360° takla attı ve 3 adım geriye yuvarlandı! 😂`,
          animation: 'banana_slip',
          sound: 'slip'
        });
        this.broadcastState();
        setTimeout(() => this.finishTurn(), 2200);
        break;
      }

      case 'jail': {
        player.jailedTurns = 1;
        this.addLog(`🔒 KODES! ${player.name} nezarete atıldı! 1 tur kilitli kalacak veya 5 altın kefalet ödeyecek!`);
        this.broadcast('tile_event', {
          playerId: player.id,
          playerName: player.name,
          avatar: player.avatar,
          category: 'penalty',
          title: '⛓️ KODES\'E TIKILDI!',
          message: `${player.name} tutuklandı! 1 tur parmaklıklar ardında kalacak veya 5 altın kefalet ödeyecek!`,
          animation: 'jail_slam',
          sound: 'jail'
        });
        this.broadcastState();
        setTimeout(() => this.finishTurn(), 2200);
        break;
      }

      case 'tax': {
        const taxVal = Math.max(3, Math.floor(player.coins * 0.25));
        player.coins = Math.max(0, player.coins - taxVal);
        const poorest = this.players.filter(p => p.id !== player.id).sort((a, b) => a.coins - b.coins)[0];
        if (poorest) {
          poorest.coins += taxVal;
          this.addLog(`💸 SOYGUN! ${player.name} ${taxVal} altın vergi ödedi, altınlar ${poorest.name}'a dağıtıldı!`);
          this.broadcast('tile_event', {
            playerId: player.id,
            playerName: player.name,
            avatar: player.avatar,
            category: 'penalty',
            title: `💸 VERGİ BASKINI! (-${taxVal} Altın)`,
            message: `${player.name}'dan kesilen ${taxVal} altın en fakir oyuncu ${poorest.name}'a dağıtıldı!`,
            animation: 'tax_robbery',
            amount: -taxVal,
            sound: 'tax'
          });
        } else {
          this.addLog(`💸 VERGİ! ${player.name} ${taxVal} altın vergi ödedi!`);
          this.broadcast('tile_event', {
            playerId: player.id,
            playerName: player.name,
            avatar: player.avatar,
            category: 'penalty',
            title: `💸 VERGİ BASKINI! (-${taxVal} Altın)`,
            message: `${player.name} kasaya ${taxVal} altın ceza vergisi ödedi!`,
            animation: 'tax_robbery',
            amount: -taxVal,
            sound: 'tax'
          });
        }
        this.broadcastState();
        setTimeout(() => this.finishTurn(), 2200);
        break;
      }

      case 'freeze': {
        player.frozenTurns = 1;
        this.addLog(`🧊 BUZ TUZAĞI! ${player.name} donduruldu! Bir tur boyunca eşya kullanamaz!`);
        this.broadcast('tile_event', {
          playerId: player.id,
          playerName: player.name,
          avatar: player.avatar,
          category: 'penalty',
          title: '🧊 BUZ KESTİ!',
          message: `${player.name} kutup soğuğunda dondu! Bir sonraki turunda hiçbir eşya kullanamaz!`,
          animation: 'freeze_frost',
          sound: 'freeze'
        });
        this.broadcastState();
        setTimeout(() => this.finishTurn(), 2000);
        break;
      }

      case 'reverse': {
        player.reverseNext = true;
        this.addLog(`🔄 TERS YÖN LANETİ! ${player.name} sonraki zarında ters yöne gidecek!`);
        this.broadcast('tile_event', {
          playerId: player.id,
          playerName: player.name,
          avatar: player.avatar,
          category: 'penalty',
          title: '🔄 PUSULA ŞAŞTI!',
          message: `Lanet devrede! ${player.name} bir sonraki hamlesinde GERİYE doğru yürüyecek!`,
          animation: 'reverse_curse',
          sound: 'reverse'
        });
        this.broadcastState();
        setTimeout(() => this.finishTurn(), Math.max(350, Math.round(1600 / spd)));
        break;
      }

      case 'duel':
        this.triggerDuel(player);
        break;

      default:
        this.broadcastState();
        setTimeout(() => this.finishTurn(), Math.max(200, Math.round(700 / spd)));
        break;
    }
  }

  triggerMysteryEvent(player) {
    const spd = this.gameSpeed || 1;
    const events = [
      { name: 'Gökten Altın', fn: () => { player.coins += 12; this.addLog(`🎁 Şans Çarkı: ${player.name} gökten düşen sandıktan +12 Altın kaptı!`); } },
      { name: 'Çifte Şans', fn: () => { player.inventory.push('double_dice'); this.addLog(`🎁 Şans Çarkı: ${player.name} ücretsiz Çift Zar kazandı!`); } },
      { name: 'Kalkan Hediyesi', fn: () => { player.shieldActive = 2; this.addLog(`🎁 Şans Çarkı: ${player.name} 2 turluk koruma kalkanı kazandı!`); } },
      { name: 'Liderden Arakla', fn: () => {
        const others = this.players.filter(p => p.id !== player.id && p.coins > 0);
        if (others.length > 0) {
          const target = others.reduce((max, p) => p.coins > max.coins ? p : max, others[0]);
          const stolen = Math.min(6, target.coins);
          target.coins -= stolen;
          player.coins += stolen;
          this.addLog(`🎁 Şans Çarkı: ${player.name}, ${target.name}'dan ${stolen} altın aşırdı!`);
        } else {
          player.coins += 8;
          this.addLog(`🎁 Şans Çarkı: ${player.name} +8 Altın kazandı!`);
        }
      }},
      { name: 'Yıldız İndirimi', fn: () => { player.coins += 15; this.addLog(`🎁 Şans Çarkı: Yıldız yardım fonu! ${player.name} +15 Altın kazandı!`); } }
    ];

    const chosen = events[Math.floor(Math.random() * events.length)];
    this.broadcast('mystery_triggered', {
      playerId: player.id,
      playerName: player.name,
      eventName: chosen.name
    });

    setTimeout(() => {
      chosen.fn();
      this.broadcastState();
      setTimeout(() => this.finishTurn(), Math.max(250, Math.round(1000 / spd)));
    }, Math.max(350, Math.round(1400 / spd)));
  }

  triggerShop(player) {
    const spd = this.gameSpeed || 1;
    // If bot, auto buy useful item if afford
    if (player.isBot) {
      if (player.coins >= 10 && !player.inventory.includes('double_dice')) {
        player.coins -= 7;
        player.inventory.push('double_dice');
        this.addLog(`🏪 ${player.name} Dükkandan Çift Zar satın aldı!`);
      } else if (player.coins >= 12 && !player.inventory.includes('magnet')) {
        player.coins -= 10;
        player.inventory.push('magnet');
        this.addLog(`🏪 ${player.name} Dükkandan Altın Mıknatısı aldı!`);
      }
      this.broadcastState();
      setTimeout(() => this.finishTurn(), Math.max(200, Math.round(800 / spd)));
      return;
    }

    // If human, notify client to open shop modal
    this.broadcast('open_shop', {
      playerId: player.id,
      items: SHOP_ITEMS
    });

    // Auto close shop after 15 seconds if player is idle
    setTimeout(() => {
      if (this.getCurrentPlayer() && this.getCurrentPlayer().id === player.id) {
        this.finishTurn();
      }
    }, 15000);
  }

  triggerDuel(player) {
    const spd = this.gameSpeed || 1;
    const rivals = this.players.filter(p => p.id !== player.id);
    if (rivals.length === 0) {
      this.finishTurn();
      return;
    }
    const rival = rivals[Math.floor(Math.random() * rivals.length)];
    const roll1 = Math.floor(Math.random() * 6) + 1;
    const roll2 = Math.floor(Math.random() * 6) + 1;

    let duelResult = '';
    if (roll1 >= roll2) {
      const loot = Math.min(5, rival.coins);
      rival.coins -= loot;
      player.coins += loot;
      duelResult = `${player.name} (${roll1}) vs ${rival.name} (${roll2}) -> ${player.name} kazandı ve ${loot} altın aldı!`;
    } else {
      const lost = Math.min(5, player.coins);
      player.coins -= lost;
      rival.coins += lost;
      duelResult = `${player.name} (${roll1}) vs ${rival.name} (${roll2}) -> ${rival.name} kazandı ve ${lost} altın aldı!`;
    }

    this.addLog(`⚔️ Düello! ${duelResult}`);
    this.broadcast('duel_result', { text: duelResult });
    this.broadcastState();
    setTimeout(() => this.finishTurn(), Math.max(300, Math.round(1200 / spd)));
  }

  useItem(sessionId, itemId, targetPlayerId = null) {
    const player = this.players.find(p => p.sessionId === sessionId);
    if (!player) return;

    if (player.frozenTurns > 0) {
      this.addLog(`🧊 ${player.name} donmuş durumda, eşya kullanamaz!`);
      return;
    }

    const idx = player.inventory.indexOf(itemId);
    if (idx === -1) return;

    player.inventory.splice(idx, 1);

    switch (itemId) {
      case 'double_dice':
        player.doubleDiceActive = true;
        this.addLog(`⚡ ${player.name} Çift Zar gücünü etkinleştirdi!`);
        break;

      case 'rocket':
        this.addLog(`🚀 ${player.name} Roket ateşledi ve 7 adım ileri fırladı!`);
        this.movePlayerSteps(player, 7);
        return;

      case 'shield':
        player.shieldActive = 2;
        this.addLog(`🛡️ ${player.name} Manyetik Kalkan kuşandı (2 tur koruma)!`);
        break;

      case 'magnet':
        let totalStolen = 0;
        this.players.forEach(other => {
          if (other.id !== player.id && other.shieldActive === 0) {
            const steal = Math.min(4, other.coins);
            other.coins -= steal;
            totalStolen += steal;
          }
        });
        player.coins += totalStolen;
        this.addLog(`🧲 ${player.name} Altın Mıknatısı kullandı ve toplam ${totalStolen} altın topladı!`);
        break;

      case 'banana':
        this.trapsOnBoard[player.position] = player.id;
        this.addLog(`🍌 ${player.name} ${player.position}. karoya muz kabuğu tuzağı bıraktı!`);
        break;

      case 'swap_wand':
        const target = this.players.find(p => p.id === targetPlayerId) || this.players.find(p => p.id !== player.id);
        if (target) {
          const tempPos = player.position;
          player.position = target.position;
          target.position = tempPos;
          this.addLog(`🪄 ${player.name} Takas Asası ile ${target.name} ile konumlarını değiştirdi!`);
        }
        break;

      case 'ghost_cloak':
        player.ghostCloakActive = 2;
        this.addLog(`👻 ${player.name} Hayalet Pelerin kuşandı! 2 tur boyunca cezalardan ve tuzaklardan muaf!`);
        break;

      case 'lucky_die':
        const fixedVal = Math.min(6, Math.max(1, parseInt(targetPlayerId) || 6));
        player.fixedRollNext = fixedVal;
        this.addLog(`🎯 ${player.name} Şanslı Altın Zar ayarladı: Sıradaki zarı garanti [${fixedVal}] gelecek!`);
        break;
    }

    this.broadcastState();
  }

  finishTurn() {
    this.isProcessingTurn = false;
    const current = this.getCurrentPlayer();
    if (current) {
      if (current.shieldActive > 0) current.shieldActive--;
      if (current.ghostCloakActive > 0) current.ghostCloakActive--;
      if (current.frozenTurns > 0) current.frozenTurns--;
    }
    if (this.state !== 'playing') return;

    this.turnIndex++;
    if (this.turnIndex >= this.players.length) {
      // Round Complete!
      this.turnIndex = 0;
      this.currentRound++;

      if (this.currentRound > this.totalRounds) {
        this.endGame();
        return;
      }

      // Trigger End-of-Round Mini Game!
      this.startRoundMiniGame();
      return;
    }

    this.broadcastState();
    this.checkNextTurnAction();
  }

  handleTradeOffer(fromSessionId, offer) {
    const sender = this.players.find(p => p.sessionId === fromSessionId);
    const receiver = this.players.find(p => p.id === offer.toPlayerId);
    if (!sender || !receiver) return;

    const offerCoins = parseInt(offer.offerCoins) || 0;
    const requestCoins = parseInt(offer.requestCoins) || 0;

    if (sender.coins < offerCoins) return;
    if (offer.offerItem && !sender.inventory.includes(offer.offerItem)) return;

    const tradeId = 'tr_' + Math.random().toString(36).substr(2, 6);
    this.pendingTrades[tradeId] = {
      id: tradeId,
      senderId: sender.id,
      receiverId: receiver.id,
      offerCoins,
      offerItem: offer.offerItem || null,
      requestCoins,
      requestItem: offer.requestItem || null
    };

    if (receiver.isBot) {
      // Bot evaluates trade offer
      setTimeout(() => {
        const valOffer = offerCoins + (offer.offerItem ? 8 : 0);
        const valReq = requestCoins + (offer.requestItem ? 8 : 0);
        const accepts = (valOffer >= valReq && receiver.coins >= requestCoins);
        this.resolveTrade(tradeId, accepts);
      }, 1300);
    } else {
      if (receiver.ws && receiver.ws.readyState === WebSocket.OPEN) {
        receiver.ws.send(JSON.stringify({
          type: 'incoming_trade_offer',
          tradeId,
          senderName: sender.name,
          senderAvatar: sender.avatar,
          offerCoins,
          offerItem: offer.offerItem,
          requestCoins,
          requestItem: offer.requestItem
        }));
      }
    }
  }

  resolveTrade(tradeId, accepted) {
    const trade = this.pendingTrades[tradeId];
    if (!trade) return;
    delete this.pendingTrades[tradeId];

    const sender = this.players.find(p => p.id === trade.senderId);
    const receiver = this.players.find(p => p.id === trade.receiverId);
    if (!sender || !receiver) return;

    if (!accepted) {
      this.addLog(`❌ ${receiver.name}, ${sender.name}'ın takas teklifini reddetti.`);
      this.broadcast('trade_rejected', { senderName: sender.name, receiverName: receiver.name });
      return;
    }

    // Verify balances
    if (sender.coins < trade.offerCoins || receiver.coins < trade.requestCoins) return;
    if (trade.offerItem && !sender.inventory.includes(trade.offerItem)) return;
    if (trade.requestItem && !receiver.inventory.includes(trade.requestItem)) return;

    // Execute swap
    sender.coins -= trade.offerCoins;
    receiver.coins += trade.offerCoins;
    receiver.coins -= trade.requestCoins;
    sender.coins += trade.requestCoins;

    if (trade.offerItem) {
      const idx = sender.inventory.indexOf(trade.offerItem);
      if (idx !== -1) sender.inventory.splice(idx, 1);
      receiver.inventory.push(trade.offerItem);
    }
    if (trade.requestItem) {
      const idx = receiver.inventory.indexOf(trade.requestItem);
      if (idx !== -1) receiver.inventory.splice(idx, 1);
      sender.inventory.push(trade.requestItem);
    }

    this.addLog(`🤝 TAKAS GERÇEKLEŞTİ! ${sender.name} ile ${receiver.name} başarıyla takas yaptı!`);
    this.broadcast('trade_completed', {
      senderName: sender.name,
      receiverName: receiver.name
    });
    this.broadcastState();
  }

  sendQuickChat(sessionId, text) {
    const player = this.players.find(p => p.sessionId === sessionId);
    if (!player) return;

    this.broadcast('player_chat', {
      playerId: player.id,
      playerName: player.name,
      text: text
    });
  }

  startRoundMiniGame() {
    this.state = 'minigame';
    const games = [
      { id: 'coin_catch', title: 'Gökten Altın Yağmuru', desc: 'Düşen altınları sepete topla, bombalardan kaç!', duration: 15 },
      { id: 'reflex_pop', title: 'Hızlı Parmak / Refleks', desc: 'Yeşil sinyal geldiğinde ilk tıklayan kazanır!', duration: 10 },
      { id: 'balloon_mash', title: 'Lego Balon Şişirme', desc: 'En hızlı tıkla, balonunu ilk patlatan sen ol!', duration: 12 },
      { id: 'lucky_chests', title: 'Hazine Sandığı Kumarı', desc: '3 gizemli sandıktan birini seç! Ya büyük ödül ya da tuzak!', duration: 11 },
      { id: 'memory_matrix', title: 'Parti Hafızası & Hızlı Renkler', desc: 'Yanan renk dizisini hafızanda tut ve hatasız tekrarla!', duration: 14 },
      { id: 'timing_hammer', title: 'Güç Çekici & Hassas Zamanlama', desc: 'Tam ortadaki 100 puanlık altın zili tuttur!', duration: 12 }
    ];

    const chosenGame = games[Math.floor(Math.random() * games.length)];
    this.minigame = {
      ...chosenGame,
      scores: {},
      finished: false,
      stakes: {
        first: '+15 Altın & Bonus Eşya',
        second: '+8 Altın',
        third: '+3 Altın',
        last: '-5 Altın Ceza'
      }
    };

    this.players.forEach(p => {
      this.minigame.scores[p.id] = 0;
    });

    this.addLog(`🎮 ${this.currentRound - 1}. Tur bitti! Mini-Oyun Başlıyor: "${chosenGame.title}"!`);

    this.broadcast('minigame_start', {
      minigame: this.minigame,
      round: this.currentRound - 1
    });

    // Simulate bot scores
    this.players.filter(p => p.isBot).forEach(bot => {
      setTimeout(() => {
        if (this.minigame && !this.minigame.finished) {
          const botScore = Math.floor(Math.random() * 22) + 10;
          this.minigame.scores[bot.id] = botScore;
          this.broadcast('minigame_score_update', { playerId: bot.id, score: botScore });
        }
      }, Math.random() * 5000 + 3000);
    });

    // Auto finish minigame after duration + 2s
    setTimeout(() => {
      this.resolveMiniGame();
    }, (chosenGame.duration + 3) * 1000);
  }

  handleMiniGameScore(sessionId, score) {
    if (this.state !== 'minigame' || !this.minigame || this.minigame.finished) return;
    const player = this.players.find(p => p.sessionId === sessionId);
    if (!player) return;

    this.minigame.scores[player.id] = score;
    this.broadcast('minigame_score_update', { playerId: player.id, score: score });
  }

  resolveMiniGame() {
    if (this.state !== 'minigame' || !this.minigame || this.minigame.finished) return;
    this.minigame.finished = true;

    // Rank players by score
    const ranked = [...this.players].sort((a, b) => {
      const sa = this.minigame.scores[a.id] || 0;
      const sb = this.minigame.scores[b.id] || 0;
      return sb - sa;
    });

    let firstItemWon = null;
    // Award high-stakes bonuses & penalties
    if (ranked[0]) {
      ranked[0].coins += 15;
      const bonusItems = ['rocket', 'shield', 'double_dice'];
      firstItemWon = bonusItems[Math.floor(Math.random() * bonusItems.length)];
      if (!ranked[0].inventory) ranked[0].inventory = [];
      ranked[0].inventory.push(firstItemWon);
      this.addLog(`🏆 Mini-Oyun 1.si: ${ranked[0].name} (+15 Altın & 1x ${firstItemWon})!`);
    }
    if (ranked[1]) {
      ranked[1].coins += 8;
      this.addLog(`🥈 Mini-Oyun 2.si: ${ranked[1].name} (+8 Altın)!`);
    }
    if (ranked[2]) {
      ranked[2].coins += 3;
      this.addLog(`🥉 Mini-Oyun 3.sü: ${ranked[2].name} (+3 Altın)!`);
    }
    // Last place penalty (if at least 3 players)
    if (ranked.length >= 3) {
      const last = ranked[ranked.length - 1];
      const penalty = Math.min(5, last.coins);
      last.coins = Math.max(0, last.coins - penalty);
      this.addLog(`💀 Mini-Oyun Sonuncusu: ${last.name} (-${penalty} Altın Ceza)!`);
    }

    this.broadcast('minigame_end', {
      scores: this.minigame.scores,
      bonusItemWon: firstItemWon,
      ranked: ranked.map(p => ({
        id: p.id,
        name: p.name,
        avatar: p.avatar,
        score: this.minigame.scores[p.id] || 0,
        coins: p.coins
      }))
    });

    this.minigame = null;
    this.state = 'playing';

    setTimeout(() => {
      this.broadcastState();
      this.checkNextTurnAction();
    }, 1800);
  }

  endGame() {
    this.state = 'gameover';

    // Calculate final scores: 1 Star = 1000 pts, 1 Coin = 10 pts
    const leaderboard = [...this.players].map(p => ({
      id: p.id,
      sessionId: p.sessionId, // Critical for client XP attribution
      name: p.name,
      avatar: p.avatar,
      hat: p.hat,
      color: p.color,
      stars: p.stars,
      coins: p.coins,
      totalScore: (p.stars * 1000) + (p.coins * 10),
      xpEarned: Math.floor(150 + (p.stars * 80) + (p.coins * 2))
    })).sort((a, b) => b.totalScore - a.totalScore);

    this.addLog(`🎉 PARTİ TAMAMLANDI! Şampiyon: 👑 ${leaderboard[0].name}!`);

    this.broadcast('game_over', {
      leaderboard: leaderboard,
      winner: leaderboard[0]
    });
  }

  sendEmote(sessionId, emoteId) {
    const player = this.players.find(p => p.sessionId === sessionId);
    if (!player) return;

    this.broadcast('player_emote', {
      playerId: player.id,
      playerName: player.name,
      emoteId
    });

    // Sometimes bots react too!
    if (Math.random() > 0.4) {
      const bots = this.players.filter(p => p.isBot);
      if (bots.length > 0) {
        const randomBot = bots[Math.floor(Math.random() * bots.length)];
        const botEmotes = ['laugh', 'cool', 'party', 'fire', 'shock'];
        setTimeout(() => {
          this.broadcast('player_emote', {
            playerId: randomBot.id,
            playerName: randomBot.name,
            emoteId: botEmotes[Math.floor(Math.random() * botEmotes.length)]
          });
        }, 1200);
      }
    }
  }
}

// Route all LocalRoom broadcasts directly to GameClient
LocalRoom.prototype.broadcast = function(type, payload = {}) {
  const msg = { type, ...payload };
  setTimeout(() => {
    if (window.GameClient) {
      window.GameClient.handleServerMessage(msg);
    }
  }, 10);
};

class LocalGameServer {
  constructor() {
    this.currentRoom = null;
  }

  createRoom(hostPlayer, settings = {}) {
    const roomId = 'SOLO';
    this.currentRoom = new LocalRoom(roomId, hostPlayer.sessionId, hostPlayer.name, settings);
    
    // Register the host player into the room
    const player = this.currentRoom.addPlayer(
      hostPlayer.sessionId,
      hostPlayer.name,
      hostPlayer.avatar,
      hostPlayer.diceSkin,
      hostPlayer.level,
      hostPlayer.title,
      null, // ws
      hostPlayer.hat,
      hostPlayer.color
    );

    setTimeout(() => {
      if (window.GameClient) {
        window.GameClient.handleServerMessage({
          type: 'room_created',
          roomId: roomId,
          sessionId: hostPlayer.sessionId,
          player: player
        });
      }
      this.currentRoom.broadcastState();
    }, 30);

    return this.currentRoom;
  }

  handleMessage(sessionId, type, data = {}) {
    if (!this.currentRoom) return;
    const room = this.currentRoom;

    switch (type) {
      case 'add_bot':
        room.addBot();
        room.broadcastState();
        break;

      case 'switch_map':
        room.mapTheme = data.mapTheme || 'istanbul';
        room.board = generateBoardForTheme(room.mapTheme);
        room.addLog('🗺️ Harita seçildi: ' + room.mapTheme.toUpperCase());
        room.broadcastState();
        break;

      case 'start_game':
        room.startGame();
        break;

      case 'roll_dice':
        room.rollDice(sessionId);
        break;

      case 'set_game_speed':
        room.gameSpeed = data.speed || 1;
        break;

      case 'buy_item': {
        const player = room.players.find(p => p.sessionId === sessionId);
        const item = SHOP_ITEMS.find(i => i.id === data.itemId);
        if (player && item && player.coins >= item.cost) {
          player.coins -= item.cost;
          player.inventory.push(item.id);
          room.addLog('🛍️ ' + player.name + ' ' + item.name + ' satın aldı!');
          room.broadcastState();
        }
        break;
      }

      case 'use_item':
        room.useItem(sessionId, data.itemId, data.targetPlayerId);
        break;

      case 'close_shop':
        if (room.getCurrentPlayer() && room.getCurrentPlayer().sessionId === sessionId) {
          room.finishTurn();
        }
        break;

      case 'send_trade_offer':
        room.handleTradeOffer(sessionId, data.offer || data);
        break;

      case 'respond_trade_offer':
        room.resolveTrade(data.tradeId, data.accepted);
        break;

      case 'send_emote':
        room.sendEmote(sessionId, data.emoteId);
        break;

      case 'leave_room': {
        this.currentRoom = null;
        break;
      }

      case 'kick_player': {
        const pIdx = room.players.findIndex(p => p.id === data.playerId || p.sessionId === data.playerId);
        if (pIdx > 0) {
          const kicked = room.players.splice(pIdx, 1)[0];
          room.addLog('👋 ' + kicked.name + ' odadan ayrıldı.');
          room.broadcastState();
        }
        break;
      }

      case 'send_quick_chat':
        room.sendQuickChat(sessionId, data.text);
        break;

      case 'minigame_score':
        room.handleMiniGameScore(sessionId, data.score);
        break;
    }
  }
}

window.LocalServer = new LocalGameServer();


/* =================== 8. GAME CLIENT =================== */
/**
 * Multi-Backend Game Client & Networking Layer
 * Supports:
 *  1. PHP Serverless Backend ('api.php' with atomic file locking and zero DB)
 *  2. Pure Offline / Standalone Mode (100% In-Browser LocalServer Engine)
 *  3. WebSocket Server (Node.js fallback for LAN multiplayer)
 */
class ClientEngine {
  constructor() {
    this.ws = null;
    this.connected = false;
    this.backendType = 'offline'; // 'php', 'ws', 'offline'
    this.apiEndpoint = 'api.php';
    this.isStandalone = true;
    this.roomId = null;
    this.player = null; // My player object
    this.state = null; // Current room state
    this.reconnectAttempts = 0;
    this.pollInterval = null;
    this.lastStateHash = '';
  }

  async init() {
    await this.detectBackend();
    this.checkUrlParams();
  }

  async detectBackend() {
    const pill = document.getElementById('server-status-pill');
    const pillText = document.getElementById('server-status-text');

    // 1. If running on file:// protocol, force offline standalone
    if (window.location.protocol === 'file:') {
      this.backendType = 'offline';
      this.isStandalone = true;
      if (pill) pill.className = 'server-status-pill offline';
      if (pillText) pillText.innerText = '⚡ Yerel Dosya Modu (Bağımsız Oyun Motoru Aktif)';
      return;
    }

    // 2. Try checking PHP Backend (probing api.php, index.php, or current endpoint)
    const endpointsToProbe = ['api.php', 'index.php'];
    if (window.location.pathname.endsWith('.php')) {
      endpointsToProbe.unshift(window.location.pathname);
    } else {
      endpointsToProbe.push('?action=health');
    }

    for (const ep of endpointsToProbe) {
      try {
        const url = ep.includes('?') ? ep : `${ep}?action=health`;
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 1600);
        const res = await fetch(url, {
          signal: controller.signal,
          cache: 'no-store'
        });
        clearTimeout(timeoutId);

        if (res.ok) {
          const data = await res.json();
          if (data && data.status === 'ok') {
            console.log('✅ PHP Çok Oyunculu Arka Ucu aktif! Uç nokta:', ep);
            this.apiEndpoint = ep.split('?')[0] || 'index.php';
            this.backendType = 'php';
            this.isStandalone = false;
            this.connected = true;
            if (pill) pill.className = 'server-status-pill online';
            if (pillText) pillText.innerText = '🟢 Çevrimiçi Çok Oyunculu Mod Aktif';
            return;
          }
        }
      } catch (e) {
        // Continue to next probe
      }
    }

    // 3. Fallback to offline standalone LocalServer
    console.log('🌐 Statik / Çevrimdışı ortam tespit edildi. Bağımsız Yerel Motor (LocalServer) devrede.');
    this.backendType = 'offline';
    this.isStandalone = true;
    this.connected = true;
    if (pill) pill.className = 'server-status-pill offline';
    if (pillText) pillText.innerText = '⚡ Statik Mod (Bağımsız Çevrimdışı & Botlu Oyun)';
  }

  checkUrlParams() {
    try {
      const params = new URLSearchParams(window.location.search);
      const roomParam = params.get('room');
      if (roomParam) {
        const cleanRoom = roomParam.trim().toUpperCase();
        console.log('🔗 Davet bağlantısı algılandı. Oda:', cleanRoom);
        setTimeout(() => {
          if (this.backendType === 'php') {
            UI.showToast(`🔗 "${cleanRoom}" odasına bağlanılıyor...`, 'info');
            this.joinRoom(cleanRoom);
          } else {
            UI.showToast(`ℹ️ Bu web sitesi statik modda çalışıyor. Bot partisine başlanıyor!`, 'info');
            this.createRoom(10, 'istanbul');
          }
        }, 400);
        return true;
      }
    } catch (e) {}
    return false;
  }

  // ---------------------------------------------------------------------------
  // API & Communication Layer
  // ---------------------------------------------------------------------------

  getApiUrl(actionParams) {
    const ep = this.apiEndpoint || 'api.php';
    const glue = ep.includes('?') ? '&' : '?';
    return `${ep}${glue}action=${actionParams}`;
  }

  async apiPost(action, payload = {}) {
    try {
      const sessId = this.player ? this.player.sessionId : (PlayerProgression.profile ? PlayerProgression.profile.sessionId : 's_guest');
      const targetUrl = this.getApiUrl(action);
      const res = await fetch(targetUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          roomId: this.roomId,
          sessionId: sessId,
          ...payload
        })
      });
      const data = await res.json();
      if (data && data.type === 'error') {
        UI.showToast(data.message, 'error');
        return null;
      }
      return data;
    } catch (e) {
      console.warn('API isteği başarısız:', e);
      return null;
    }
  }

  startPolling() {
    this.stopPolling();
    this.pollInterval = setInterval(async () => {
      if (!this.roomId || this.backendType !== 'php') return;
      try {
        const sessId = this.player ? this.player.sessionId : PlayerProgression.profile.sessionId;
        const targetUrl = this.getApiUrl(`get_state&roomId=${encodeURIComponent(this.roomId)}&sessionId=${encodeURIComponent(sessId)}`);
        const res = await fetch(targetUrl, {
          cache: 'no-store'
        });
        if (res.ok) {
          const msg = await res.json();
          if (msg && msg.type === 'state_update') {
            const hash = JSON.stringify({ r: msg.currentRound, t: msg.turnIndex, s: msg.state, p: msg.players.map(x=>x.position) });
            if (hash !== this.lastStateHash) {
              this.lastStateHash = hash;
              this.handleServerMessage(msg);
            }
          }
        }
      } catch (err) {}
    }, 1200);
  }

  stopPolling() {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
  }

  async leaveRoom() {
    this.stopPolling();
    const rId = this.roomId;
    const pId = this.player ? (this.player.id || this.player.sessionId) : null;

    if (this.backendType === 'php' && rId) {
      try {
        await this.apiPost('leave_room', { playerId: pId });
      } catch (e) {}
    } else if (this.backendType === 'ws' && this.ws && this.connected) {
      this.send('leave_room', { roomId: rId });
    } else if (window.LocalServer) {
      window.LocalServer.handleMessage(pId || 's_host', 'leave_room', {});
    }

    this.roomId = null;
    this.player = null;
    this.state = null;
    window.CURRENT_ROOM_STATE = null;
    try {
      localStorage.removeItem('partycraft_active_room');
    } catch (e) {}

    // Clean URL query parameter (?room=...)
    if (window.history && window.history.replaceState) {
      const cleanUrl = window.location.origin + window.location.pathname;
      window.history.replaceState({}, document.title, cleanUrl);
    }

    if (window.UI) {
      window.UI.returnToHomeScreen();
    }
  }

  connect() {
    return Promise.resolve();
  }

  // ---------------------------------------------------------------------------
  // Actions (Create, Join, Start, Roll, Items)
  // ---------------------------------------------------------------------------

  async createRoom(rounds = 10, mapTheme = 'istanbul', password = '') {
    const prof = PlayerProgression.profile;

    // 1. PHP Backend Mode
    if (this.backendType === 'php') {
      const res = await this.apiPost('create_room', {
        playerName: prof.name,
        avatar: prof.avatar,
        hat: prof.hat || 'none',
        color: prof.color || '#3B82F6',
        diceSkin: prof.diceSkin,
        level: prof.level,
        title: prof.title,
        rounds: rounds,
        mapTheme: mapTheme,
        password: password
      });

      if (res && res.type === 'room_created') {
        this.roomId = res.roomId;
        this.player = res.player;
        localStorage.setItem('partycraft_active_room', res.roomId);
        this.handleServerMessage(res);
        this.startPolling();
      }
      return;
    }

    // 2. Standalone / Offline Mode (LocalServer)
    const hostPlayer = {
      sessionId: prof.sessionId,
      name: prof.name,
      avatar: prof.avatar,
      hat: prof.hat || 'none',
      color: prof.color || '#3B82F6',
      diceSkin: prof.diceSkin,
      level: prof.level,
      title: prof.title
    };
    this.player = hostPlayer;
    if (window.LocalServer) {
      window.LocalServer.createRoom(hostPlayer, {
        totalRounds: parseInt(rounds) || 10,
        mapTheme: mapTheme
      });
    }
  }

  async joinRoom(roomId, password = '') {
    const prof = PlayerProgression.profile;
    const cleanId = (roomId || '').trim().toUpperCase();

    // 1. PHP Backend Mode
    if (this.backendType === 'php') {
      const res = await this.apiPost('join_room', {
        roomId: cleanId,
        playerName: prof.name,
        avatar: prof.avatar,
        hat: prof.hat || 'none',
        color: prof.color || '#3B82F6',
        diceSkin: prof.diceSkin,
        level: prof.level,
        title: prof.title,
        password: password
      });

      if (res && res.type === 'room_joined') {
        this.roomId = res.roomId;
        this.player = res.player;
        localStorage.setItem('partycraft_active_room', res.roomId);
        this.handleServerMessage(res);
        this.startPolling();
      }
      return;
    }

    // 2. Offline Mode
    this.createRoom(10, 'istanbul');
  }

  async startGame() {
    if (this.backendType === 'php') {
      const res = await this.apiPost('start_game');
      if (res && res.type === 'state_update') {
        this.handleServerMessage(res);
      }
      return;
    }

    if (window.LocalServer) {
      window.LocalServer.handleMessage(this.player ? this.player.sessionId : 's_host', 'start_game', {});
    }
  }

  async addBot() {
    if (this.backendType === 'php') {
      const res = await this.apiPost('add_bot');
      if (res) this.handleServerMessage(res);
      return;
    }

    if (window.LocalServer) {
      window.LocalServer.handleMessage(this.player ? this.player.sessionId : 's_host', 'add_bot', {});
    }
  }

  async kickPlayer(targetPlayerId) {
    if (this.backendType === 'php') {
      const res = await this.apiPost('kick_player', { targetPlayerId });
      if (res) this.handleServerMessage(res);
      return;
    }

    if (window.LocalServer && window.LocalServer.currentRoom) {
      const room = window.LocalServer.currentRoom;
      const idx = room.players.findIndex(p => p.id === targetPlayerId);
      if (idx !== -1) {
        const removed = room.players.splice(idx, 1)[0];
        room.addLog(`🚪 ${removed.name} odadan çıkarıldı.`);
        room.broadcastState();
      }
    }
  }

  async switchMap(mapTheme) {
    if (this.backendType === 'php') {
      const res = await this.apiPost('switch_map', { mapTheme });
      if (res) this.handleServerMessage(res);
      return;
    }

    if (window.LocalServer) {
      window.LocalServer.handleMessage(this.player ? this.player.sessionId : 's_host', 'switch_map', { mapTheme });
    }
  }

  async rollDice() {
    if (this.backendType === 'php') {
      const res = await this.apiPost('roll_dice');
      if (res && res.type === 'dice_rolled') {
        UI.showDiceRollAnimation(res);
        setTimeout(() => {
          if (res.state) this.handleServerMessage(res.state);
        }, 1600);
      }
      return;
    }

    if (window.LocalServer) {
      window.LocalServer.handleMessage(this.player ? this.player.sessionId : 's_host', 'roll_dice', {});
    }
  }

  async buyItem(itemId) {
    if (this.backendType === 'php') {
      const res = await this.apiPost('buy_item', { itemId });
      if (res && res.room) this.handleServerMessage(res.room);
      return;
    }

    if (window.LocalServer) {
      window.LocalServer.handleMessage(this.player ? this.player.sessionId : 's_host', 'buy_item', { itemId });
    }
  }

  async useItem(itemId, targetPlayerId = null) {
    if (this.backendType === 'php') {
      const res = await this.apiPost('use_item', { itemId, targetPlayerId });
      if (res && res.room) this.handleServerMessage(res.room);
      return;
    }

    if (window.LocalServer) {
      window.LocalServer.handleMessage(this.player ? this.player.sessionId : 's_host', 'use_item', { itemId, targetPlayerId });
    }
  }

  async closeShop() {
    if (this.backendType === 'php') {
      await this.apiPost('close_shop');
      return;
    }

    if (window.LocalServer) {
      window.LocalServer.handleMessage(this.player ? this.player.sessionId : 's_host', 'close_shop', {});
    }
  }

  async sendEmote(emoteId) {
    if (this.backendType === 'php') {
      await this.apiPost('send_emote', { emoteId });
      return;
    }

    if (window.LocalServer) {
      window.LocalServer.handleMessage(this.player ? this.player.sessionId : 's_host', 'send_emote', { emoteId });
    }
  }

  async sendQuickChat(text) {
    if (this.backendType === 'php') {
      await this.apiPost('send_quick_chat', { text });
      return;
    }

    if (window.LocalServer) {
      window.LocalServer.handleMessage(this.player ? this.player.sessionId : 's_host', 'send_quick_chat', { text });
    }
  }

  async sendMiniGameScore(score) {
    if (this.backendType === 'php') {
      await this.apiPost('minigame_score', { score });
      return;
    }

    if (window.LocalServer) {
      window.LocalServer.handleMessage(this.player ? this.player.sessionId : 's_host', 'minigame_score', { score });
    }
  }

  setGameSpeed(speed) {
    window.GAME_SPEED = speed;
    if (window.BoardMap) {
      window.BoardMap.gameSpeed = speed;
    }
    if (window.LocalServer) {
      window.LocalServer.handleMessage(this.player ? this.player.sessionId : 's_host', 'set_game_speed', { speed });
    }
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.send('set_game_speed', { speed });
    }
  }

  // ---------------------------------------------------------------------------
  // Message Handling Dispatcher
  // ---------------------------------------------------------------------------

  handleServerMessage(msg) {
    if (!msg) return;

    switch (msg.type) {
      case 'room_created':
      case 'room_joined':
        this.roomId = msg.roomId;
        this.player = msg.player;
        UI.showLobbyScreen(msg.roomId, this.player);
        if (msg.state) UI.updateGameState(msg.state);
        break;

      case 'state_update':
        this.state = msg;
        window.CURRENT_ROOM_STATE = msg;
        UI.updateGameState(msg);
        break;

      case 'dice_rolled':
        UI.showDiceRollAnimation(msg);
        break;

      case 'mystery_triggered':
        UI.showMysteryRoulette(msg);
        break;

      case 'tile_event':
        UI.showTileEventCard(msg);
        break;

      case 'open_shop':
        UI.openShopModal(msg.items, msg.playerId === (this.player ? this.player.id : null));
        break;

      case 'minigame_start':
        MiniGames.start(msg.minigame);
        break;

      case 'minigame_end':
        MiniGames.close();
        UI.showMiniGameResults(msg);
        break;

      case 'player_emote':
        UI.showPlayerEmote(msg.playerId, msg.emoteId);
        break;

      case 'player_chat':
        UI.showPlayerChatBubble(msg.playerId, msg.playerName, msg.text);
        break;

      case 'incoming_trade_offer':
        UI.showIncomingTradeModal(msg);
        break;

      case 'trade_completed':
        AudioPlayer.playStarFanfare();
        UI.showToast(`🤝 ${msg.senderName} ve ${msg.receiverName} başarıyla takas yaptı!`, 'success');
        break;

      case 'trade_rejected':
        UI.showToast(`❌ Takas teklifi reddedildi.`, 'info');
        break;

      case 'game_over':
        this.stopPolling();
        localStorage.removeItem('partycraft_active_room');
        UI.showVictoryPodium(msg);
        break;

      case 'error':
        UI.showToast(msg.message, 'error');
        break;
    }
  }
}

const GameClient = new ClientEngine();
window.GameClient = GameClient;


/* =================== 9. UI MANAGER =================== */
/**
 * UI Controller, Screen Transitions, Modals, Micro-interactions & Social Trade Engine
 */
class UIEngine {
  constructor() {
    this.homeScreen = document.getElementById('screen-home');
    this.lobbyScreen = document.getElementById('screen-lobby');
    this.gameScreen = document.getElementById('screen-game');
    this.boardRenderer = null;
    this.toastContainer = document.getElementById('toast-container');
    this.activeTradeOffer = null;
  }

  init() {
    if (window.i18n) {
      window.i18n.applyTranslations();
    }
    const savedSpeed = parseInt(localStorage.getItem('partycraft_game_speed') || '1', 10);
    window.GAME_SPEED = [1, 2, 4].includes(savedSpeed) ? savedSpeed : 1;
    this.updateSpeedUI();

    GameClient.init();
    this.initSettings();
    this.renderProfileCard();
    this.bindHomeEvents();
    this.bindGameEvents();
  }

  updateSpeedUI() {
    const lbl = document.getElementById('speed-label');
    const btn = document.getElementById('btn-toggle-speed');
    const spd = window.GAME_SPEED || 1;
    if (lbl) {
      lbl.innerText = spd === 4 ? '4x 🚀' : (spd === 2 ? '2x ⚡' : '1x');
    }
    if (btn) {
      btn.classList.toggle('active-speed', spd > 1);
    }
  }

  onLanguageChanged(lang) {
    this.renderCharacterStudio();
    this.renderProfileCard();
    if (GameClient.state) {
      this.renderGameHeader(GameClient.state);
      this.renderScoreboard(GameClient.state);
    }
    this.initSettings();
  }

  initSettings() {
    let settings = { sfx: true, music: false, dice3d: true, lowPower: false };
    try {
      const saved = localStorage.getItem('partycraft_settings');
      if (saved) settings = Object.assign(settings, JSON.parse(saved));
    } catch (e) {}

    window.PARTY_SETTINGS = settings;
    AudioPlayer.muted = !settings.sfx;

    const sfxInput = document.getElementById('setting-sfx');
    const musicInput = document.getElementById('setting-music');
    const diceInput = document.getElementById('setting-dice3d');
    const powerInput = document.getElementById('setting-lowpower');

    if (sfxInput) sfxInput.checked = !!settings.sfx;
    if (musicInput) musicInput.checked = !!settings.music;
    if (diceInput) diceInput.checked = !!settings.dice3d;
    if (powerInput) powerInput.checked = !!settings.lowPower;

    if (window.i18n) {
      const curLang = window.i18n.getLang();
      document.querySelectorAll('.lang-btn, .lang-pill-btn').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-lang') === curLang);
      });
    }
  }

  checkUrlForRoom() {
    // Handled in GameClient.init()
  }

  renderProfileCard() {
    this.renderCharacterStudio();
  }

  renderCharacterStudio() {
    const prof = PlayerProgression.profile;
    const avatarDef = AVATAR_DEFS[prof.avatar] || AVATAR_DEFS.builder;
    const hatDef = HAT_DEFS[prof.hat] || HAT_DEFS.none;

    // 1. Live Avatar Preview & Glow
    const avatarBox = document.getElementById('profile-avatar-box');
    if (avatarBox) {
      avatarBox.innerHTML = avatarDef.svg;
    }

    const glowBox = document.getElementById('studio-avatar-glow');
    if (glowBox) {
      glowBox.style.borderColor = prof.color || '#3B82F6';
      glowBox.style.boxShadow = `0 0 24px ${prof.color || '#3B82F6'}55, inset 0 2px 6px rgba(0,0,0,0.1)`;
    }

    const hatBadge = document.getElementById('studio-hat-badge');
    if (hatBadge) {
      hatBadge.innerText = hatDef.icon || '🙂';
    }

    const nameInput = document.getElementById('home-name-input');
    if (nameInput && document.activeElement !== nameInput) {
      nameInput.value = prof.name;
    }

    const titleElem = document.getElementById('profile-title');
    if (titleElem) titleElem.innerText = PlayerProgression.getDisplayTitle(prof.title);

    const levelElem = document.getElementById('profile-level');
    if (levelElem) levelElem.innerText = `Lv. ${prof.level}`;

    const xpText = document.getElementById('profile-xp-text');
    const needed = PlayerProgression.getXpRequired(prof.level);
    if (xpText) {
      xpText.innerText = `${prof.xp} / ${needed} XP`;
    }

    // 2. Avatar Model Chips
    const avatarContainer = document.getElementById('home-avatar-chips');
    if (avatarContainer && avatarContainer.children.length === 0) {
      Object.values(AVATAR_DEFS).forEach(av => {
        const isUnlocked = prof.level >= av.requiredLevel;
        const chip = document.createElement('button');
        chip.className = `studio-chip-btn ${prof.avatar === av.id ? 'active' : ''}`;
        chip.id = `chip-av-${av.id}`;
        chip.innerHTML = `${av.name} ${!isUnlocked ? '🔒' : ''}`;
        chip.onclick = () => {
          if (!isUnlocked) {
            this.showToast(`Bu karakter Lv. ${av.requiredLevel}'de açılır!`, 'info');
            return;
          }
          AudioPlayer.playClick();
          PlayerProgression.setAvatar(av.id);
          this.refreshStudioChips();
          this.renderCharacterStudio();
        };
        avatarContainer.appendChild(chip);
      });
    }

    // 3. Hat / Accessory Chips
    const hatContainer = document.getElementById('home-hat-chips');
    if (hatContainer && hatContainer.children.length === 0) {
      Object.values(HAT_DEFS).forEach(h => {
        const isUnlocked = prof.level >= h.requiredLevel;
        const chip = document.createElement('button');
        chip.className = `studio-chip-btn ${prof.hat === h.id ? 'active' : ''}`;
        chip.id = `chip-hat-${h.id}`;
        chip.innerHTML = `${h.icon} ${h.name} ${!isUnlocked ? '🔒' : ''}`;
        chip.onclick = () => {
          if (!isUnlocked) {
            this.showToast(`Bu şapka Lv. ${h.requiredLevel}'de açılır!`, 'info');
            return;
          }
          AudioPlayer.playClick();
          PlayerProgression.setHat(h.id);
          this.refreshStudioChips();
          this.renderCharacterStudio();
        };
        hatContainer.appendChild(chip);
      });
    }

    // 4. Color Palette Chips
    const colorContainer = document.getElementById('home-color-chips');
    if (colorContainer && colorContainer.children.length === 0) {
      COLOR_PRESETS.forEach(c => {
        const circle = document.createElement('div');
        circle.className = `studio-color-circle ${prof.color === c.hex ? 'active' : ''}`;
        circle.id = `chip-color-${c.id}`;
        circle.style.backgroundColor = c.hex;
        circle.title = c.name;
        circle.onclick = () => {
          AudioPlayer.playClick();
          PlayerProgression.setColor(c.hex);
          this.refreshStudioChips();
          this.renderCharacterStudio();
        };
        colorContainer.appendChild(circle);
      });
    }
  }

  refreshStudioChips() {
    const prof = PlayerProgression.profile;
    document.querySelectorAll('#home-avatar-chips .studio-chip-btn').forEach(btn => {
      btn.classList.toggle('active', btn.id === `chip-av-${prof.avatar}`);
    });
    document.querySelectorAll('#home-hat-chips .studio-chip-btn').forEach(btn => {
      btn.classList.toggle('active', btn.id === `chip-hat-${prof.hat}`);
    });
    document.querySelectorAll('#home-color-chips .studio-color-circle').forEach(btn => {
      btn.classList.toggle('active', btn.style.backgroundColor === prof.color || btn.id === `chip-color-${prof.color}`);
    });
  }

  bindHomeEvents() {
    // Name input live update
    const nameInput = document.getElementById('home-name-input');
    if (nameInput) {
      nameInput.addEventListener('input', (e) => {
        PlayerProgression.setName(e.target.value);
      });
    }

    // 1. Quick Play (Instant Solo against 3 smart bots in a random city)
    const btnQuick = document.getElementById('btn-quick-play');
    if (btnQuick) {
      btnQuick.addEventListener('click', async () => {
        AudioPlayer.playClick();
        await GameClient.connect();
        const mapKeys = ['istanbul', 'tokyo', 'paris', 'newyork'];
        const chosenMap = mapKeys[Math.floor(Math.random() * mapKeys.length)];
        GameClient.createRoom(10, chosenMap);
        setTimeout(() => {
          GameClient.addBot();
          GameClient.addBot();
          GameClient.addBot();
          setTimeout(() => GameClient.startGame(), 400);
        }, 500);
      });
    }

    // 2. Play with Friends (1-click room creation with shareable link & QR code)
    const btnFriends = document.getElementById('btn-play-friends');
    if (btnFriends) {
      btnFriends.addEventListener('click', async () => {
        AudioPlayer.playClick();
        await GameClient.connect();
        GameClient.createRoom(10, 'istanbul');
      });
    }

    // 3. Play with Bots (Opens room configuration modal to pick city & round count)
    const btnBots = document.getElementById('btn-play-bots');
    if (btnBots) {
      btnBots.addEventListener('click', () => {
        AudioPlayer.playClick();
        const modal = document.getElementById('modal-create-room');
        if (modal) modal.classList.remove('hidden');
      });
    }

    // Backward-compatibility for any legacy create room button
    const btnLegacyCreate = document.getElementById('btn-create-room');
    if (btnLegacyCreate) {
      btnLegacyCreate.addEventListener('click', () => {
        AudioPlayer.playClick();
        const modal = document.getElementById('modal-create-room');
        if (modal) modal.classList.remove('hidden');
      });
    }

    // Confirm Create Room in modal
    const btnConfirmCreate = document.getElementById('btn-confirm-create');
    if (btnConfirmCreate) {
      btnConfirmCreate.addEventListener('click', async () => {
        AudioPlayer.playClick();
        const roundElem = document.querySelector('input[name="round-select"]:checked');
        const rounds = roundElem ? roundElem.value : 10;
        const mapThemeElem = document.querySelector('input[name="map-theme-select"]:checked');
        const mapTheme = mapThemeElem ? mapThemeElem.value : 'istanbul';
        await GameClient.connect();
        GameClient.createRoom(rounds, mapTheme);
        const modal = document.getElementById('modal-create-room');
        if (modal) modal.classList.add('hidden');
      });
    }

    // 4. How to Play Rules Modal
    const btnHowToPlay = document.getElementById('btn-how-to-play');
    const modalHowToPlay = document.getElementById('modal-how-to-play');
    const btnCloseHowToPlay = document.getElementById('btn-close-how-to-play');
    const btnOkHowToPlay = document.getElementById('btn-ok-how-to-play');
    if (btnHowToPlay && modalHowToPlay) {
      btnHowToPlay.addEventListener('click', () => {
        AudioPlayer.playClick();
        modalHowToPlay.classList.remove('hidden');
      });
    }
    if (btnCloseHowToPlay && modalHowToPlay) {
      btnCloseHowToPlay.addEventListener('click', () => {
        AudioPlayer.playClick();
        modalHowToPlay.classList.add('hidden');
      });
    }
    if (btnOkHowToPlay && modalHowToPlay) {
      btnOkHowToPlay.addEventListener('click', () => {
        AudioPlayer.playClick();
        modalHowToPlay.classList.add('hidden');
      });
    }

    // 5. Settings Modal
    const btnSettings = document.getElementById('btn-settings');
    const modalSettings = document.getElementById('modal-settings');
    const btnCloseSettings = document.getElementById('btn-close-settings');
    const btnSaveSettings = document.getElementById('btn-save-settings');
    const btnResetProfile = document.getElementById('btn-reset-profile');

    if (btnSettings && modalSettings) {
      btnSettings.addEventListener('click', () => {
        AudioPlayer.playClick();
        this.initSettings();
        modalSettings.classList.remove('hidden');
      });
    }
    if (btnCloseSettings && modalSettings) {
      btnCloseSettings.addEventListener('click', () => {
        AudioPlayer.playClick();
        modalSettings.classList.add('hidden');
      });
    }
    if (btnSaveSettings && modalSettings) {
      btnSaveSettings.addEventListener('click', () => {
        AudioPlayer.playClick();
        const sfx = document.getElementById('setting-sfx')?.checked ?? true;
        const music = document.getElementById('setting-music')?.checked ?? false;
        const dice3d = document.getElementById('setting-dice3d')?.checked ?? true;
        const lowPower = document.getElementById('setting-lowpower')?.checked ?? false;
        const s = { sfx, music, dice3d, lowPower };
        window.PARTY_SETTINGS = s;
        try { localStorage.setItem('partycraft_settings', JSON.stringify(s)); } catch (e) {}
        AudioPlayer.muted = !sfx;
        if (music && !AudioPlayer.musicPlaying) {
          AudioPlayer.toggleMusic();
        } else if (!music && AudioPlayer.musicPlaying) {
          AudioPlayer.toggleMusic();
        }
        modalSettings.classList.add('hidden');
        this.showToast('✅ Ayarlar başarıyla kaydedildi!', 'success');
      });
    }
    if (btnResetProfile) {
      btnResetProfile.addEventListener('click', () => {
        if (confirm('Tüm oyuncu seviyen ve biriken XP puanların sıfırlansın mı?')) {
          PlayerProgression.reset();
          this.renderCharacterStudio();
          this.showToast('🔄 Profil verileri sıfırlandı.', 'info');
        }
      });
    }

    // Language selector buttons
    document.querySelectorAll('.lang-btn, .lang-pill-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        AudioPlayer.playClick();
        const lang = btn.getAttribute('data-lang');
        if (lang && window.setLanguage) {
          window.setLanguage(lang);
        }
      });
    });

    // Join Room Button
    const btnJoin = document.getElementById('btn-join-room');
    if (btnJoin) {
      btnJoin.addEventListener('click', async () => {
        AudioPlayer.playClick();
        const roomCode = document.getElementById('input-room-code').value.trim().toUpperCase();
        if (!roomCode) {
          this.showToast('Lütfen oda kodunu gir!', 'error');
          return;
        }
        await GameClient.connect();
        GameClient.joinRoom(roomCode);
      });
    }

    // QR Modal Controls
    const btnCloseQr = document.getElementById('btn-close-qr');
    const modalQr = document.getElementById('modal-qr');
    if (btnCloseQr && modalQr) {
      btnCloseQr.addEventListener('click', () => {
        AudioPlayer.playClick();
        modalQr.classList.add('hidden');
      });
    }
    const btnCopyLan = document.getElementById('btn-copy-lan-link');
    if (btnCopyLan) {
      btnCopyLan.addEventListener('click', () => {
        const link = document.getElementById('lan-qr-link-text')?.innerText || '';
        if (link) {
          AudioPlayer.playClick();
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(link).then(() => {
              this.showToast('📋 Bağlantı kopyalandı!', 'success');
            }).catch(() => prompt('Bağlantıyı kopyala:', link));
          } else {
            prompt('Bağlantıyı kopyala:', link);
          }
        }
      });
    }

    // HUD QR Trigger button
    const btnHudQr = document.getElementById('btn-hud-qr');
    if (btnHudQr) {
      btnHudQr.addEventListener('click', () => {
        AudioPlayer.playClick();
        if (modalQr) modalQr.classList.remove('hidden');
      });
    }

    // Wardrobe / Customization Modal
    const btnWardrobe = document.getElementById('btn-open-wardrobe');
    if (btnWardrobe) {
      btnWardrobe.addEventListener('click', () => {
        AudioPlayer.playClick();
        this.openWardrobeModal();
      });
    }

    // Sound / Music Toggles on Home
    const btnHomeMusic = document.getElementById('btn-home-music');
    if (btnHomeMusic) {
      btnHomeMusic.addEventListener('click', (e) => {
        const playing = AudioPlayer.toggleMusic();
        e.currentTarget.classList.toggle('active', playing);
        e.currentTarget.innerHTML = playing ? getIcon('volume2') : getIcon('volumeX');
      });
    }
  }

  openWardrobeModal() {
    const modal = document.getElementById('modal-wardrobe');
    modal.classList.remove('hidden');

    const prof = PlayerProgression.profile;
    const nameInput = document.getElementById('wardrobe-name-input');
    nameInput.value = prof.name;

    // Render Avatars Grid
    const avatarGrid = document.getElementById('wardrobe-avatars');
    avatarGrid.innerHTML = '';
    Object.values(AVATAR_DEFS).forEach(av => {
      const isUnlocked = prof.level >= av.requiredLevel;
      const isSelected = prof.avatar === av.id;

      const item = document.createElement('div');
      item.className = `wardrobe-item ${isSelected ? 'selected' : ''} ${!isUnlocked ? 'locked' : ''}`;
      item.innerHTML = `
        <div class="wardrobe-avatar-preview">${av.svg}</div>
        <div class="wardrobe-item-name">${av.name}</div>
        <div class="wardrobe-item-tag">${isUnlocked ? (isSelected ? 'Kuşanıldı' : 'Seç') : `Lv. ${av.requiredLevel}`}</div>
      `;

      if (isUnlocked) {
        item.addEventListener('click', () => {
          PlayerProgression.setAvatar(av.id);
          AudioPlayer.playClick();
          this.renderProfileCard();
          this.openWardrobeModal();
        });
      }
      avatarGrid.appendChild(item);
    });

    // Render Dice Skins Grid
    const diceGrid = document.getElementById('wardrobe-dice');
    diceGrid.innerHTML = '';
    Object.values(DICE_SKINS).forEach(ds => {
      const isUnlocked = prof.level >= ds.requiredLevel;
      const isSelected = prof.diceSkin === ds.id;

      const item = document.createElement('div');
      item.className = `wardrobe-item ${isSelected ? 'selected' : ''} ${!isUnlocked ? 'locked' : ''}`;
      item.innerHTML = `
        <div class="wardrobe-dice-preview" style="background:${ds.color}; border: 2px solid ${ds.border};">🎲</div>
        <div class="wardrobe-item-name">${ds.name}</div>
        <div class="wardrobe-item-tag">${isUnlocked ? (isSelected ? 'Kuşanıldı' : 'Seç') : `Lv. ${ds.requiredLevel}`}</div>
      `;

      if (isUnlocked) {
        item.addEventListener('click', () => {
          PlayerProgression.setDiceSkin(ds.id);
          AudioPlayer.playClick();
          this.renderProfileCard();
          this.openWardrobeModal();
        });
      }
      diceGrid.appendChild(item);
    });

    // Render Titles Select
    const titleSelect = document.getElementById('wardrobe-titles');
    titleSelect.innerHTML = '';
    PlayerProgression.getUnlockedTitles().forEach(t => {
      const opt = document.createElement('option');
      opt.value = t.title;
      opt.innerText = t.title;
      if (prof.title === t.title) opt.selected = true;
      titleSelect.appendChild(opt);
    });

    // Save Name & Title
    document.getElementById('btn-save-wardrobe').onclick = () => {
      const newName = nameInput.value.trim();
      if (newName) PlayerProgression.setName(newName);
      PlayerProgression.setTitle(titleSelect.value);
      AudioPlayer.playClick();
      this.renderProfileCard();
      modal.classList.add('hidden');
    };
  }

  showLobbyScreen(roomId, player) {
    this.homeScreen.classList.add('hidden');
    this.gameScreen.classList.add('hidden');
    this.lobbyScreen.classList.remove('hidden');

    const codeElem = document.getElementById('lobby-room-code');
    if (codeElem) codeElem.innerText = roomId;

    const joinUrl = `${window.location.origin}${window.location.pathname}?room=${roomId}`;
    const shareUrlInput = document.getElementById('lobby-share-url');
    if (shareUrlInput) {
      shareUrlInput.value = joinUrl;
    }

    // Generate Crisp Inline SVG QR Code (Zero External Dependencies)
    const qrSvgBox = document.getElementById('lobby-qr-svg');
    if (qrSvgBox && typeof window.generateQRCodeSVG === 'function') {
      qrSvgBox.innerHTML = window.generateQRCodeSVG(joinUrl, 140);
    }

    // Update LAN / Mobile Modal QR
    const lanQrImg = document.getElementById('lan-qr-image');
    if (lanQrImg && typeof window.generateQRCodeSVG === 'function') {
      lanQrImg.src = 'data:image/svg+xml;utf8,' + encodeURIComponent(window.generateQRCodeSVG(joinUrl, 200));
    }
    const lanLinkText = document.getElementById('lan-qr-link-text');
    if (lanLinkText) lanLinkText.innerText = joinUrl;

    // Show QR Modal Button
    const btnShowQr = document.getElementById('btn-show-qr');
    if (btnShowQr) {
      btnShowQr.onclick = () => {
        AudioPlayer.playClick();
        const modalQr = document.getElementById('modal-qr');
        if (modalQr) modalQr.classList.remove('hidden');
      };
    }

    // Copy link button
    const btnCopy = document.getElementById('btn-copy-link');
    if (btnCopy) {
      btnCopy.onclick = () => {
        AudioPlayer.playClick();
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(joinUrl).then(() => {
            this.showToast('📋 Davet bağlantısı panoya kopyalandı!', 'success');
          }).catch(() => prompt('Davet linkini kopyala:', joinUrl));
        } else {
          prompt('Davet linkini kopyala:', joinUrl);
        }
      };
    }

    // Bot Add Button
    const btnAddBot = document.getElementById('btn-lobby-add-bot');
    if (btnAddBot) {
      btnAddBot.onclick = () => {
        AudioPlayer.playClick();
        GameClient.addBot();
      };
    }

    // Switch Map buttons in lobby
    const mapSelects = document.querySelectorAll('.lobby-map-btn');
    mapSelects.forEach(btn => {
      btn.onclick = () => {
        const theme = btn.dataset.theme;
        GameClient.switchMap(theme);
        AudioPlayer.playClick();
      };
    });

    // Leave Lobby Button
    const btnLobbyLeave = document.getElementById('btn-lobby-leave');
    if (btnLobbyLeave) {
      btnLobbyLeave.onclick = () => {
        AudioPlayer.playClick();
        GameClient.leaveRoom();
      };
    }

    // Start Game Button
    const btnStart = document.getElementById('btn-lobby-start');
    if (btnStart) {
      btnStart.onclick = () => {
        AudioPlayer.playClick();
        GameClient.startGame();
      };
    }
  }

  updateGameState(state) {
    if (state.state === 'lobby') {
      this.renderLobbyPlayers(state.players);
      this.updateLobbyMapTheme(state.mapTheme);
      return;
    }

    if (state.state === 'playing' || state.state === 'minigame') {
      if (this.gameScreen.classList.contains('hidden')) {
        this.homeScreen.classList.add('hidden');
        this.lobbyScreen.classList.add('hidden');
        this.gameScreen.classList.remove('hidden');

        if (!this.boardRenderer) {
          this.boardRenderer = new BoardRenderer('board-canvas');
        }

        // Guarantee crisp canvas resize & character visibility immediately upon entering
        requestAnimationFrame(() => {
          if (this.boardRenderer) {
            this.boardRenderer.resizeCanvas();
            this.boardRenderer.resetCamera();
          }
        });
      }

      if (this.boardRenderer && state.mapTheme) {
        this.boardRenderer.setTheme(state.mapTheme);
      }

      this.renderGameHeader(state);
      this.renderScoreboard(state);
      this.updateTurnControls(state);
      this.renderEventLog(state.log);
    }
  }

  updateLobbyMapTheme(themeId) {
    const themeDef = MAP_THEMES[themeId] || MAP_THEMES.istanbul;
    const badge = document.getElementById('lobby-map-badge');
    if (badge) {
      badge.innerText = `🗺️ Harita: ${themeDef.name}`;
    }
    const mapBtns = document.querySelectorAll('.lobby-map-btn');
    mapBtns.forEach(b => {
      b.classList.toggle('active', b.dataset.theme === themeId);
    });
  }

  renderLobbyPlayers(players) {
    const list = document.getElementById('lobby-players-list');
    if (!list) return;
    list.innerHTML = '';

    const countElem = document.getElementById('lobby-player-count');
    if (countElem) countElem.innerText = players.length;

    const isHost = (GameClient.isHost || (players[0] && players[0].id === GameClient.playerId));

    players.forEach((p, idx) => {
      const avatarDef = AVATAR_DEFS[p.avatar] || AVATAR_DEFS.builder;
      const hatDef = HAT_DEFS[p.hat] || HAT_DEFS.none;
      const card = document.createElement('div');
      card.className = 'lobby-player-card';
      card.style.borderLeft = `5px solid ${p.color}`;
      card.innerHTML = `
        <div class="lobby-player-avatar">${avatarDef.svg}</div>
        <div class="lobby-player-info">
          <div class="lobby-player-name">${p.name} ${hatDef.id !== 'none' ? hatDef.icon : ''} ${p.isBot ? '🤖' : ''}</div>
          <div class="lobby-player-title">${p.title} • Lv.${p.level}</div>
        </div>
        <div style="display:flex; align-items:center; gap:6px;">
          <div class="lobby-player-badge">${idx === 0 ? '👑 Oda Sahibi' : 'Hazır'}</div>
          ${(isHost && idx !== 0) ? `<button class="btn-kick-player" data-player-id="${p.id}" title="Oyuncuyu Odadan Çıkar">✕</button>` : ''}
        </div>
      `;
      list.appendChild(card);
    });

    list.querySelectorAll('.btn-kick-player').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const pid = btn.dataset.playerId;
        if (pid) {
          AudioPlayer.playClick();
          GameClient.kickPlayer(pid);
        }
      };
    });

    const startBtn = document.getElementById('btn-lobby-start');
    if (startBtn) {
      startBtn.disabled = (players.length < 1);
    }
  }

  renderGameHeader(state) {
    const lang = (window.i18n && window.i18n.getLang()) ? window.i18n.getLang() : 'tr';
    const roundLabels = { tr: 'Tur', en: 'Round', de: 'Runde', es: 'Ronda', fr: 'Manche' };
    const finalLabels = { tr: 'FİNAL TURU!', en: 'FINAL ROUND!', de: 'FINALE RUNDE!', es: '¡RONDA FINAL!', fr: 'MANCHE FINALE !' };
    const leftLabels = { tr: 'Tur Kaldı', en: 'Rounds Left', de: 'Runden übrig', es: 'Rondas restantes', fr: 'Tours restants' };
    const yourTurnLabels = { tr: '✨ Sıra Sende!', en: '✨ Your Turn!', de: '✨ Du bist dran!', es: '✨ ¡Tu Turno!', fr: '✨ À votre tour !' };
    const turnPrefixLabels = { tr: 'Sıra: ', en: 'Turn: ', de: 'Zug: ', es: 'Turno: ', fr: 'Tour : ' };

    const current = state.currentRound || 1;
    const total = state.totalRounds || 10;
    const remaining = Math.max(0, total - current);

    const roundElem = document.getElementById('hud-round');
    if (roundElem) roundElem.innerText = `${roundLabels[lang] || 'Tur'} ${current} / ${total}`;

    const remElem = document.getElementById('hud-round-remaining');
    if (remElem) {
      remElem.innerText = (remaining === 0 ? (finalLabels[lang] || 'FİNAL TURU!') : `${remaining} ${leftLabels[lang] || 'Tur Kaldı'}`);
      remElem.classList.toggle('final-pulse', remaining <= 1);
    }

    const fillElem = document.getElementById('hud-round-fill');
    if (fillElem) {
      const pct = Math.min(100, Math.round((current / total) * 100));
      fillElem.style.width = `${pct}%`;
    }

    // Trigger Golden Final Round Alert Banner when entering final round!
    const finalBanner = document.getElementById('final-round-banner');
    if (finalBanner) {
      if (current === total) {
        finalBanner.classList.remove('hidden');
        if (!this.finalBannerSoundPlayed) {
          this.finalBannerSoundPlayed = true;
          AudioPlayer.playStarFanfare();
        }
      } else {
        finalBanner.classList.add('hidden');
      }
    }

    const theme = MAP_THEMES[state.mapTheme] || MAP_THEMES.istanbul;
    const mapLabel = document.getElementById('hud-map-name');
    if (mapLabel) mapLabel.innerText = theme.name.split(' - ')[0];

    const activePlayer = state.players[state.turnIndex];
    if (activePlayer) {
      const isMe = (GameClient.player && GameClient.player.sessionId === activePlayer.sessionId);
      const turnLabel = isMe 
        ? (yourTurnLabels[lang] || '✨ Sıra Sende!') 
        : `${turnPrefixLabels[lang] || 'Sıra: '}${activePlayer.name}`;
      document.getElementById('hud-turn-name').innerText = turnLabel;
      document.getElementById('hud-turn-avatar').style.borderColor = activePlayer.color;
    }
  }

  renderScoreboard(state) {
    const boardElem = document.getElementById('players-carousel');
    if (!boardElem) return;
    boardElem.innerHTML = '';

    state.players.forEach((p, idx) => {
      const isCurrent = (idx === state.turnIndex);
      const isMe = (GameClient.player && GameClient.player.sessionId === p.sessionId);
      const avatarDef = AVATAR_DEFS[p.avatar] || AVATAR_DEFS.builder;
      const hatDef = HAT_DEFS[p.hat] || HAT_DEFS.none;

      const card = document.createElement('div');
      card.className = `player-hud-card ${isCurrent ? 'active-turn' : ''} ${isMe ? 'is-me' : ''}`;
      card.id = `player-card-${p.id}`;
      card.style.borderColor = p.color;

      // Status badges
      let statusIcons = '';
      if (hatDef.id !== 'none') statusIcons += `<span class="status-icon" title="Şapka">${hatDef.icon}</span>`;
      if (p.jailedTurns > 0) statusIcons += '<span class="status-icon" title="Kodes Cezası">🔒</span>';
      if (p.frozenTurns > 0) statusIcons += '<span class="status-icon" title="Dondu">🧊</span>';
      if (p.reverseNext) statusIcons += '<span class="status-icon" title="Ters Yön">🔄</span>';
      if (p.shieldActive > 0) statusIcons += '<span class="status-icon" title="Kalkan">🛡️</span>';
      if (p.isBot) statusIcons += '<span class="status-icon">🤖</span>';

      card.innerHTML = `
        <div class="hud-avatar-box">
          ${avatarDef.svg}
          <div class="hud-badges-row">${statusIcons}</div>
        </div>
        <div class="hud-player-stats">
          <div class="hud-pname">${p.name}</div>
          <div class="hud-scores">
            <span class="hud-star">⭐ ${p.stars}</span>
            <span class="hud-coin">🪙 ${p.coins}</span>
          </div>
        </div>
      `;

      boardElem.appendChild(card);
    });
  }

  updateTurnControls(state) {
    const activePlayer = state.players[state.turnIndex];
    const isMyTurn = (GameClient.player && activePlayer && GameClient.player.sessionId === activePlayer.sessionId && !activePlayer.isBot);

    const rollBtn = document.getElementById('btn-roll-dice');
    const dockStatus = document.getElementById('dock-status-text');

    if (rollBtn) {
      rollBtn.disabled = !isMyTurn;
      rollBtn.classList.toggle('pulse-turn', isMyTurn);
      if (isMyTurn && activePlayer) {
        if (activePlayer.doubleDiceActive) {
          rollBtn.innerHTML = '<span>🎲🎲</span> 2X ÇİFT ZAR! (SPACE)';
          rollBtn.style.background = 'linear-gradient(135deg, #F59E0B, #D97706)';
          rollBtn.style.boxShadow = '0 8px 24px rgba(245, 158, 11, 0.45)';
        } else if (activePlayer.fixedRollNext) {
          rollBtn.innerHTML = `<span>🎯</span> KİLİTLİ ZAR: ${activePlayer.fixedRollNext} (SPACE)`;
          rollBtn.style.background = 'linear-gradient(135deg, #10B981, #059669)';
          rollBtn.style.boxShadow = '0 8px 24px rgba(16, 185, 129, 0.45)';
        } else {
          rollBtn.innerHTML = '<span>🎲</span> ZAR AT! (SPACE)';
          rollBtn.style.background = '';
          rollBtn.style.boxShadow = '';
        }
      } else {
        rollBtn.innerHTML = '<span>🎲</span> ZAR AT! (SPACE)';
        rollBtn.style.background = '';
        rollBtn.style.boxShadow = '';
      }
    }

    // Update Top Screen Unmissable Turn Alert Banner
    const turnBanner = document.getElementById('hud-turn-alert-banner');
    const bannerIcon = document.getElementById('turn-banner-icon');
    const bannerTitle = document.getElementById('turn-banner-title');
    const bannerSub = document.getElementById('turn-banner-sub');

    if (turnBanner && activePlayer) {
      if (isMyTurn) {
        turnBanner.classList.add('my-turn');
        if (bannerIcon) bannerIcon.innerText = '🎲';
        if (bannerTitle) bannerTitle.innerText = '🎯 SIRA SENDE!';
        if (bannerSub) {
          if (activePlayer.jailedTurns > 0) {
            bannerSub.innerText = '🔒 Kodes Cezası: 5 altın kefalet öde veya pas geç!';
          } else if (activePlayer.doubleDiceActive) {
            bannerSub.innerText = '🎲🎲 2X Çift Zar Etkin! Bu tur iki zar birden atacaksın!';
          } else if (activePlayer.fixedRollNext) {
            bannerSub.innerText = `🎯 Şanslı Zar Etkin! Bu tur tam ${activePlayer.fixedRollNext} adım atacaksın!`;
          } else if (activePlayer.ghostCloakActive > 0) {
            bannerSub.innerText = `👻 Hayalet Pelerini Aktif (${activePlayer.ghostCloakActive} tur)! Tüm tuzak ve cezalardan muafsın!`;
          } else if (activePlayer.reverseNext) {
            bannerSub.innerText = '🔄 Boğaz Ters Akıntısı: Bir sonraki zarda geriye doğru yürüyeceksin!';
          } else {
            bannerSub.innerText = 'Zarı at (SPACE) veya çantandan taktik eşyası kullan!';
          }
        }
      } else {
        turnBanner.classList.remove('my-turn');
        if (bannerIcon) bannerIcon.innerText = '⏳';
        if (bannerTitle) bannerTitle.innerText = `⏳ Sıra: ${activePlayer.name}`;
        if (bannerSub) bannerSub.innerText = `${activePlayer.title} hamlesini yapıyor, hamle bekleniyor...`;
      }
    }

    if (dockStatus) {
      if (isMyTurn) {
        if (activePlayer.jailedTurns > 0) {
          dockStatus.innerHTML = '🔒 <strong>Kodes\'tesin!</strong> 5 altın kefalet ödeyeceksin ya da pas geçeceksin!';
        } else {
          dockStatus.innerHTML = '👉 <strong>Sıra Sende!</strong> Zarı at ya da takas teklif et!';
        }
      } else if (activePlayer) {
        dockStatus.innerHTML = `⏳ <strong>${activePlayer.name}</strong> hamlesini yapıyor...`;
      }
    }

    // Update inventory badge
    const myPlayer = state.players.find(p => GameClient.player && p.sessionId === GameClient.player.sessionId);
    const invBadge = document.getElementById('inventory-badge');
    if (invBadge && myPlayer) {
      invBadge.innerText = myPlayer.inventory.length;
    }
  }

  bindGameEvents() {
    // Roll Dice Button
    document.getElementById('btn-roll-dice').addEventListener('click', () => {
      AudioPlayer.playClick();
      GameClient.rollDice();
    });

    // Speed Toggle Button (1x -> 2x -> 4x -> 1x)
    const btnToggleSpeed = document.getElementById('btn-toggle-speed');
    if (btnToggleSpeed) {
      btnToggleSpeed.onclick = () => {
        let current = window.GAME_SPEED || 1;
        let next = 1;
        if (current === 1) next = 2;
        else if (current === 2) next = 4;
        else next = 1;

        window.GAME_SPEED = next;
        localStorage.setItem('partycraft_game_speed', next.toString());
        this.updateSpeedUI();
        if (window.GameClient) {
          window.GameClient.setGameSpeed(next);
        }
        AudioPlayer.playClick();
        const toastMsg = next === 4 ? '🚀 Oyun Hızı: 4x Turbo!' : (next === 2 ? '⚡ Oyun Hızı: 2x Hızlı!' : '⚡ Oyun Hızı: 1x Normal');
        this.showToast(toastMsg, 'info');
      };
    }

    // Inventory Button
    document.getElementById('btn-open-inventory').addEventListener('click', () => {
      AudioPlayer.playClick();
      this.openInventoryModal();
    });

    // Trade Button
    document.getElementById('btn-open-trade').addEventListener('click', () => {
      AudioPlayer.playClick();
      this.openTradeModal();
    });

    // Emotes Button
    document.getElementById('btn-open-emotes').addEventListener('click', () => {
      AudioPlayer.playClick();
      this.openEmoteWheel();
    });

    // Quick Chat Button
    document.getElementById('btn-open-chat').addEventListener('click', () => {
      AudioPlayer.playClick();
      this.openQuickChatModal();
    });

    // Camera Controls
    document.getElementById('btn-cam-zoom-in').onclick = () => {
      if (this.boardRenderer) this.boardRenderer.zoomIn();
    };
    document.getElementById('btn-cam-zoom-out').onclick = () => {
      if (this.boardRenderer) this.boardRenderer.zoomOut();
    };
    document.getElementById('btn-reset-cam').onclick = () => {
      AudioPlayer.playClick();
      if (this.boardRenderer) this.boardRenderer.resetCamera();
    };

    // Show LAN QR Code Button
    document.getElementById('btn-hud-qr').addEventListener('click', () => {
      AudioPlayer.playClick();
      this.openQrModal();
    });

    // Music Toggle
    document.getElementById('btn-hud-music').addEventListener('click', (e) => {
      const playing = AudioPlayer.toggleMusic();
      e.currentTarget.classList.toggle('active', playing);
      e.currentTarget.innerHTML = playing ? getIcon('volume2') : getIcon('volumeX');
    });

    // Leave Game Modal Controls (In-Game HUD Leave Button)
    const btnHudLeave = document.getElementById('btn-hud-leave');
    const modalLeave = document.getElementById('modal-confirm-leave');
    const btnCancelLeave = document.getElementById('btn-cancel-leave');
    const btnConfirmLeave = document.getElementById('btn-confirm-leave');

    if (btnHudLeave && modalLeave) {
      btnHudLeave.addEventListener('click', () => {
        AudioPlayer.playClick();
        modalLeave.classList.remove('hidden');
      });
    }
    if (btnCancelLeave && modalLeave) {
      btnCancelLeave.addEventListener('click', () => {
        AudioPlayer.playClick();
        modalLeave.classList.add('hidden');
      });
    }
    if (btnConfirmLeave && modalLeave) {
      btnConfirmLeave.addEventListener('click', () => {
        AudioPlayer.playClick();
        modalLeave.classList.add('hidden');
        GameClient.leaveRoom();
      });
    }

    // Keyboard Shortcuts
    window.addEventListener('keydown', (e) => {
      if (e.code === 'Space') {
        const rollBtn = document.getElementById('btn-roll-dice');
        if (rollBtn && !rollBtn.disabled) {
          rollBtn.click();
        }
      } else if (e.key === 't' || e.key === 'T') {
        document.getElementById('btn-open-trade').click();
      } else if (e.key === 'e' || e.key === 'E') {
        document.getElementById('btn-open-emotes').click();
      } else if (e.key === 'i' || e.key === 'I') {
        document.getElementById('btn-open-inventory').click();
      } else if (e.key === 'Escape') {
        // ESC key can close modals or open leave confirm
        const openModal = document.querySelector('.modal-overlay:not(.hidden)');
        if (openModal) {
          openModal.classList.add('hidden');
        } else if (!this.gameScreen.classList.contains('hidden')) {
          const m = document.getElementById('modal-confirm-leave');
          if (m) m.classList.remove('hidden');
        }
      }
    });
  }

  returnToHomeScreen() {
    this.gameScreen.classList.add('hidden');
    this.lobbyScreen.classList.add('hidden');
    this.homeScreen.classList.remove('hidden');

    const modalLeave = document.getElementById('modal-confirm-leave');
    if (modalLeave) modalLeave.classList.add('hidden');

    // Close any other open modals
    document.querySelectorAll('.modal-overlay').forEach(m => m.classList.add('hidden'));

    this.renderCharacterStudio();
    this.showToast('🚪 Oyundan ayrıldın. Ana menüye dönüldü.', 'info');
  }

  showTileInspector(tile, index, playersOnTile, stepsAway) {
    const modal = document.getElementById('modal-tile-inspector');
    modal.classList.remove('hidden');

    const lang = (window.i18n && window.i18n.getLang()) ? window.i18n.getLang() : 'tr';
    const stepsDict = {
      tr: `${stepsAway} adım mesafede`,
      en: `${stepsAway} steps away`,
      de: `${stepsAway} Schritte entfernt`,
      es: `a ${stepsAway} casillas de distancia`,
      fr: `à ${stepsAway} cases de distance`
    };
    const emptyDict = {
      tr: 'Şu an bu karoda kimse yok.',
      en: 'No players on this tile.',
      de: 'Derzeit keine Spieler auf diesem Feld.',
      es: 'No hay jugadores en esta casilla.',
      fr: 'Aucun joueur sur cette case.'
    };
    document.getElementById('ti-tile-title').innerText = `${index}. ${tile.title}`;
    document.getElementById('ti-tile-desc').innerText = tile.desc;
    document.getElementById('ti-tile-steps').innerText = stepsDict[lang] || stepsDict.tr;

    const playersList = document.getElementById('ti-players-here');
    playersList.innerHTML = '';
    if (playersOnTile.length === 0) {
      playersList.innerHTML = `<span style="color:#94A3B8; font-size:12px;">${emptyDict[lang] || emptyDict.tr}</span>`;
    } else {
      playersOnTile.forEach(p => {
        const pBadge = document.createElement('span');
        pBadge.className = 'ti-player-pill';
        pBadge.style.borderColor = p.color;
        pBadge.innerText = `${p.name} (⭐${p.stars})`;
        playersList.appendChild(pBadge);
      });
    }

    document.getElementById('btn-close-tile-inspector').onclick = () => {
      modal.classList.add('hidden');
    };
  }

  /* ----------------------------------------------------
     TRADE SYSTEM UI (Oyuncular Arası Takas)
     ---------------------------------------------------- */
  openTradeModal() {
    const modal = document.getElementById('modal-trade');
    modal.classList.remove('hidden');

    const state = GameClient.state;
    if (!state || !state.players) return;

    const myPlayer = state.players.find(p => GameClient.player && p.sessionId === GameClient.player.sessionId);
    if (!myPlayer) return;

    const targetSelect = document.getElementById('trade-target-player');
    targetSelect.innerHTML = '';
    const otherPlayers = state.players.filter(p => p.id !== myPlayer.id);

    if (otherPlayers.length === 0) {
      targetSelect.innerHTML = '<option value="">Odada başka oyuncu yok!</option>';
      document.getElementById('btn-send-trade-offer').disabled = true;
      return;
    }

    document.getElementById('btn-send-trade-offer').disabled = false;
    otherPlayers.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.id;
      opt.innerText = `${p.name} (🪙 ${p.coins} Altın, 🎒 ${p.inventory.length} Eşya)`;
      targetSelect.appendChild(opt);
    });

    // Populate My Offer Item
    const myItemSelect = document.getElementById('trade-offer-item');
    myItemSelect.innerHTML = '<option value="">-- Eşya Teklif Etme --</option>';
    myPlayer.inventory.forEach(itemId => {
      const itemDef = SHOP_ITEMS.find(i => i.id === itemId) || { name: itemId };
      const opt = document.createElement('option');
      opt.value = itemId;
      opt.innerText = itemDef.name;
      myItemSelect.appendChild(opt);
    });

    // Populate Requested Item based on selected target
    const reqItemSelect = document.getElementById('trade-request-item');
    const updateTargetInventory = () => {
      const targetId = targetSelect.value;
      const targetP = state.players.find(p => p.id === targetId);
      reqItemSelect.innerHTML = '<option value="">-- Eşya İsteme --</option>';
      if (targetP && targetP.inventory.length > 0) {
        targetP.inventory.forEach(itemId => {
          const itemDef = SHOP_ITEMS.find(i => i.id === itemId) || { name: itemId };
          const opt = document.createElement('option');
          opt.value = itemId;
          opt.innerText = itemDef.name;
          reqItemSelect.appendChild(opt);
        });
      }
    };

    targetSelect.onchange = updateTargetInventory;
    updateTargetInventory();

    // Set Max Coin limits
    const offerCoinsInput = document.getElementById('trade-offer-coins');
    offerCoinsInput.max = myPlayer.coins;
    offerCoinsInput.value = 0;

    const reqCoinsInput = document.getElementById('trade-request-coins');
    reqCoinsInput.value = 0;

    // Send Button
    document.getElementById('btn-send-trade-offer').onclick = () => {
      const targetId = targetSelect.value;
      const offerCoins = parseInt(offerCoinsInput.value) || 0;
      const offerItem = myItemSelect.value || null;
      const requestCoins = parseInt(reqCoinsInput.value) || 0;
      const requestItem = reqItemSelect.value || null;

      if (!targetId) return;

      GameClient.sendTradeOffer({
        toPlayerId: targetId,
        offerCoins,
        offerItem,
        requestCoins,
        requestItem
      });

      AudioPlayer.playClick();
      modal.classList.add('hidden');
      this.showToast('🤝 Takas teklifin gönderildi!', 'info');
    };

    document.getElementById('btn-close-trade').onclick = () => {
      modal.classList.add('hidden');
    };
  }

  showIncomingTradeModal(data) {
    AudioPlayer.playStarFanfare();
    const modal = document.getElementById('modal-incoming-trade');
    modal.classList.remove('hidden');

    document.getElementById('inc-sender-name').innerText = data.senderName;
    
    // What sender offers
    let offerText = `${data.offerCoins} Altın`;
    if (data.offerItem) {
      const itemDef = SHOP_ITEMS.find(i => i.id === data.offerItem) || { name: data.offerItem };
      offerText += ` + [${itemDef.name}]`;
    }
    document.getElementById('inc-offer-details').innerText = offerText;

    // What sender asks from you
    let reqText = `${data.requestCoins} Altın`;
    if (data.requestItem) {
      const itemDef = SHOP_ITEMS.find(i => i.id === data.requestItem) || { name: data.requestItem };
      reqText += ` + [${itemDef.name}]`;
    }
    document.getElementById('inc-request-details').innerText = reqText;

    // Accept / Decline handlers
    document.getElementById('btn-accept-trade').onclick = () => {
      AudioPlayer.playCoinSound();
      GameClient.respondTradeOffer(data.tradeId, true);
      modal.classList.add('hidden');
    };

    document.getElementById('btn-decline-trade').onclick = () => {
      AudioPlayer.playTrapSound();
      GameClient.respondTradeOffer(data.tradeId, false);
      modal.classList.add('hidden');
    };
  }

  /* ----------------------------------------------------
     QUICK TACTICAL CHAT UI
     ---------------------------------------------------- */
  openQuickChatModal() {
    const modal = document.getElementById('modal-quick-chat');
    modal.classList.remove('hidden');

    const list = document.getElementById('quick-chat-options');
    list.innerHTML = '';

    const quickMessages = [
      '🤝 Kim takas yapmak ister?',
      '👑 Yıldızıma kimse dokunmasın!',
      '😱 İntikamım çok fena olacak!',
      '👏 Harika hamle, tebrikler!',
      '🍀 Biraz zar şansı verin!',
      '🔥 Haydi hızlanın, sıra kimde?'
    ];

    quickMessages.forEach(msg => {
      const btn = document.createElement('button');
      btn.className = 'chat-preset-btn';
      btn.innerText = msg;
      btn.onclick = () => {
        AudioPlayer.playClick();
        GameClient.sendQuickChat(msg);
        modal.classList.add('hidden');
      };
      list.appendChild(btn);
    });

    document.getElementById('btn-close-quick-chat').onclick = () => {
      modal.classList.add('hidden');
    };
  }

  showPlayerChatBubble(playerId, playerName, text) {
    AudioPlayer.playEmoteReaction();

    // Spawn floating speech bubble over player HUD card
    const targetCard = document.getElementById(`player-card-${playerId}`);
    const bubble = document.createElement('div');
    bubble.className = 'speech-bubble-pop';
    bubble.innerHTML = `<strong>${playerName}:</strong> ${text}`;

    if (targetCard) {
      targetCard.appendChild(bubble);
    } else {
      document.body.appendChild(bubble);
    }

    setTimeout(() => {
      bubble.remove();
    }, 3800);
  }

  renderDicePips(val) {
    const pipsCount = Math.max(1, Math.min(6, val));
    if (pipsCount === 1) {
      return '<span class="pip pip-center"></span>';
    } else if (pipsCount === 2) {
      return '<span class="pip pip-top-left"></span><span class="pip pip-bottom-right"></span>';
    } else if (pipsCount === 3) {
      return '<span class="pip pip-top-left"></span><span class="pip pip-center"></span><span class="pip pip-bottom-right"></span>';
    } else if (pipsCount === 4) {
      return '<span class="pip pip-top-left"></span><span class="pip pip-top-right"></span><span class="pip pip-bottom-left"></span><span class="pip pip-bottom-right"></span>';
    } else if (pipsCount === 5) {
      return '<span class="pip pip-top-left"></span><span class="pip pip-top-right"></span><span class="pip pip-center"></span><span class="pip pip-bottom-left"></span><span class="pip pip-bottom-right"></span>';
    } else {
      return '<span class="pip pip-top-left"></span><span class="pip pip-top-right"></span><span class="pip pip-mid-left"></span><span class="pip pip-mid-right"></span><span class="pip pip-bottom-left"></span><span class="pip pip-bottom-right"></span>';
    }
  }

  showDiceRollAnimation(data) {
    AudioPlayer.playDiceRoll();
    const overlay = document.getElementById('dice-roll-overlay');
    if (!overlay) return;
    overlay.classList.remove('hidden');

    const titleBox = document.getElementById('dice-roller-name');
    const resultBox = document.getElementById('dice-result-value');
    const dieBox = document.getElementById('dice-cube-1');
    const pipFace = document.getElementById('dice-pip-face');

    if (titleBox) titleBox.innerText = `🎲 ${data.playerName} ZAR ATIYOR...`;
    if (resultBox) resultBox.innerText = 'Zar dönüyor...';

    if (dieBox) dieBox.className = 'single-dice-box rolling';

    const speed = window.GAME_SPEED || 1;
    const tumbleTime = Math.max(160, Math.round(550 / speed));
    const postTime = Math.max(200, Math.round(650 / speed));

    // Cycle through values rapidly while tumbling
    let cycleCount = 0;
    const interval = setInterval(() => {
      cycleCount++;
      const randVal = Math.floor(Math.random() * 6) + 1;
      if (pipFace) pipFace.innerHTML = this.renderDicePips(randVal);
      if (cycleCount > 8) clearInterval(interval);
    }, Math.max(25, Math.round(55 / speed)));

    let timer2 = null;
    const finishRoll = () => {
      clearInterval(interval);
      if (dieBox) dieBox.className = 'single-dice-box landed';
      if (pipFace) pipFace.innerHTML = this.renderDicePips(data.totalRoll);

      if (resultBox) {
        resultBox.innerText = `🎉 ${data.playerName}: ${data.totalRoll} ADIM!`;
      }

      AudioPlayer.playStep();

      timer2 = setTimeout(() => {
        overlay.classList.add('hidden');
        overlay.onclick = null;
      }, postTime);
    };

    const timer1 = setTimeout(finishRoll, tumbleTime);

    // Instant close on click / tap anywhere on overlay (No waiting!)
    overlay.onclick = () => {
      clearTimeout(timer1);
      if (timer2) clearTimeout(timer2);
      clearInterval(interval);
      overlay.classList.add('hidden');
      overlay.onclick = null;
    };
  }

  showTileEventCard(data) {
    const overlay = document.getElementById('tile-event-overlay');
    if (!overlay) return;
    overlay.classList.remove('hidden');

    const card = document.getElementById('tile-event-card');
    const icon = document.getElementById('tile-event-icon');
    const title = document.getElementById('tile-event-title');
    const desc = document.getElementById('tile-event-desc');
    const avatarBox = document.getElementById('tile-event-avatar');

    if (data.avatar && AVATAR_DEFS[data.avatar]) {
      avatarBox.innerHTML = AVATAR_DEFS[data.avatar].svg;
      avatarBox.classList.remove('hidden');
    } else {
      avatarBox.classList.add('hidden');
    }

    if (data.category === 'penalty') {
      card.className = 'tile-event-card penalty-mode screen-shake-anim';
      document.body.classList.add('screen-shake-anim');
      setTimeout(() => document.body.classList.remove('screen-shake-anim'), 450);

      if (data.sound === 'slip') AudioPlayer.playSlipSound();
      else if (data.sound === 'jail') AudioPlayer.playJailSound();
      else if (data.sound === 'trap') AudioPlayer.playTrapSound();
      else AudioPlayer.playTrapSound();
    } else if (data.category === 'reward') {
      card.className = 'tile-event-card reward-mode';
      if (data.sound === 'fanfare') AudioPlayer.playStarFanfare();
      else AudioPlayer.playCoinSound();
    } else {
      card.className = 'tile-event-card neutral-mode';
      if (data.sound === 'warp') AudioPlayer.playWarpSound();
      else AudioPlayer.playClick();
    }

    icon.innerText = data.category === 'penalty' ? (data.sound === 'slip' ? '🍌' : (data.sound === 'jail' ? '⛓️' : '💥')) : (data.amount ? '🪙' : '🎁');
    title.innerText = data.title;
    desc.innerText = data.message;

    const speed = window.GAME_SPEED || 1;
    const hideTimeoutMs = Math.max(450, Math.round(1400 / speed));

    const hideTimer = setTimeout(() => {
      overlay.classList.add('hidden');
      overlay.onclick = null;
    }, hideTimeoutMs);

    // Instant close on click / tap anywhere on overlay (No waiting!)
    overlay.onclick = () => {
      clearTimeout(hideTimer);
      overlay.classList.add('hidden');
      overlay.onclick = null;
    };
  }

  showMysteryRoulette(data) {
    const modal = document.getElementById('modal-mystery');
    if (!modal) return;
    modal.classList.remove('hidden');

    const lang = (window.i18n && window.i18n.getLang()) ? window.i18n.getLang() : 'tr';
    const atTextDict = {
      tr: 'Şans Karosunda!',
      en: 'is on Fortune Tile!',
      de: 'ist auf dem Glücksfeld!',
      es: '¡está en la casilla de la suerte!',
      fr: 'est sur la case chance !'
    };
    const spinTextDict = {
      tr: 'Çark dönüyor...',
      en: 'Spinning the wheel...',
      de: 'Das Rad dreht sich...',
      es: 'La ruleta está girando...',
      fr: 'La roue tourne...'
    };
    const diceLabels = { tr: '🎲 Çift Zar', en: '🎲 2x Dice', de: '🎲 2x Würfel', es: '🎲 2x Dado', fr: '🎲 2x Dés' };
    const shieldLabels = { tr: '🛡️ Kalkan', en: '🛡️ Shield', de: '🛡️ Schild', es: '🛡️ Escudo', fr: '🛡️ Bouclier' };
    const rocketLabels = { tr: '🚀 Roket', en: '🚀 Rocket', de: '🚀 Rakete', es: '🚀 Cohete', fr: '🚀 Fusée' };
    const starLabels = { tr: '⭐ Yıldız', en: '⭐ Star', de: '⭐ Stern', es: '⭐ Estrella', fr: '⭐ Étoile' };
    const chestLabels = { tr: '🎁 Sandık', en: '🎁 Chest', de: '🎁 Kiste', es: '🎁 Cofre', fr: '🎁 Coffre' };
    const crownLabels = { tr: '👑 Taç', en: '👑 Crown', de: '👑 Krone', es: '👑 Corona', fr: '👑 Couronne' };

    document.getElementById('mystery-player-text').innerText = `${data.playerName} ${atTextDict[lang] || atTextDict.tr}`;
    const resultBox = document.getElementById('mystery-event-result');
    resultBox.innerText = spinTextDict[lang] || spinTextDict.tr;

    const canvas = document.getElementById('roulette-canvas');
    const pointer = document.getElementById('roulette-pointer');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width;
    const H = canvas.height;
    const cx = W / 2;
    const cy = H / 2;
    const R = W / 2 - 8;

    const segments = [
      { text: '+15 🪙', color: '#F59E0B', textColor: '#FFFFFF' },
      { text: diceLabels[lang] || diceLabels.tr, color: '#3B82F6', textColor: '#FFFFFF' },
      { text: shieldLabels[lang] || shieldLabels.tr, color: '#10B981', textColor: '#FFFFFF' },
      { text: rocketLabels[lang] || rocketLabels.tr, color: '#EC4899', textColor: '#FFFFFF' },
      { text: '+10 🪙', color: '#F97316', textColor: '#FFFFFF' },
      { text: starLabels[lang] || starLabels.tr, color: '#EAB308', textColor: '#FFFFFF' },
      { text: chestLabels[lang] || chestLabels.tr, color: '#8B5CF6', textColor: '#FFFFFF' },
      { text: crownLabels[lang] || crownLabels.tr, color: '#06B6D4', textColor: '#FFFFFF' }
    ];

    const numSegs = segments.length;
    const arc = (Math.PI * 2) / numSegs;

    const drawWheel = (rotationAngle) => {
      ctx.clearRect(0, 0, W, H);

      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(rotationAngle);

      // Outer rim
      ctx.beginPath();
      ctx.arc(0, 0, R, 0, Math.PI * 2);
      ctx.fillStyle = '#CBD5E1';
      ctx.fill();

      // Wedges
      for (let i = 0; i < numSegs; i++) {
        const seg = segments[i];
        const angle = i * arc;

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, R - 6, angle, angle + arc);
        ctx.closePath();
        ctx.fillStyle = seg.color;
        ctx.fill();
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Wedge Text
        ctx.save();
        ctx.rotate(angle + arc / 2);
        ctx.textAlign = 'right';
        ctx.fillStyle = seg.textColor;
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText(seg.text, R - 16, 4);
        ctx.restore();
      }

      // Center stud
      ctx.beginPath();
      ctx.arc(0, 0, 24, 0, Math.PI * 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.restore();
    };

    // Spin animation with physics (scaled by game speed)
    let currentAngle = 0;
    const targetSpin = Math.PI * 2 * (4 + Math.random() * 2);
    const speed = window.GAME_SPEED || 1;
    const duration = Math.max(700, Math.round(2400 / speed));
    const postWait = Math.max(350, Math.round(1800 / speed));
    const startT = performance.now();
    let lastTickAngle = 0;
    let modalTimer = null;
    let isFinished = false;

    // Instant close on click / tap anywhere on modal
    modal.onclick = () => {
      if (modalTimer) clearTimeout(modalTimer);
      modal.classList.add('hidden');
      modal.onclick = null;
    };

    const animateSpin = (now) => {
      if (isFinished || modal.classList.contains('hidden')) return;
      const elapsed = now - startT;
      const progress = Math.min(1, elapsed / duration);
      // Cubic ease out
      const ease = 1 - Math.pow(1 - progress, 3);
      currentAngle = targetSpin * ease;
      drawWheel(currentAngle);

      // Flapper pointer tick sound
      if (Math.abs(currentAngle - lastTickAngle) >= arc) {
        lastTickAngle = currentAngle;
        if (pointer) {
          pointer.style.transform = 'translateX(-50%) rotate(-18deg)';
          setTimeout(() => { if (pointer) pointer.style.transform = 'translateX(-50%) rotate(0deg)'; }, 40);
        }
        AudioPlayer.playWheelTick();
      }

      if (progress < 1) {
        requestAnimationFrame(animateSpin);
      } else {
        // Spin finished
        isFinished = true;
        AudioPlayer.playStarFanfare();
        const wonDict = {
          tr: 'Büyük Ödül Kazandın!',
          en: 'Big Prize Won!',
          de: 'Großer Preis gewonnen!',
          es: '¡Ganaste el Gran Premio!',
          fr: 'Grand Prix remporté !'
        };
        const wonText = wonDict[lang] || wonDict.tr;
        resultBox.innerText = `✨ ${data.eventName || wonText}!`;
        this.triggerConfetti();
        modalTimer = setTimeout(() => {
          modal.classList.add('hidden');
          modal.onclick = null;
        }, postWait);
      }
    };

    requestAnimationFrame(animateSpin);
  }

  getItemInfo(itemId, lang) {
    const itemTranslations = {
      double_dice: {
        tr: { name: 'Çift Zar', desc: 'Bir sonraki turda 2 zar birden atarsın (2-12 adım).' },
        en: { name: 'Double Dice', desc: 'Roll 2 dice at once on your next turn (2-12 steps).' },
        de: { name: 'Doppelwürfel', desc: 'Würfle im nächsten Zug mit 2 Würfeln (2-12 Felder).' },
        es: { name: 'Dado Doble', desc: 'Tira 2 dados a la vez en tu próximo turno (2-12 casillas).' },
        fr: { name: 'Double Dé', desc: 'Lancez 2 dés à la fois lors de votre prochain tour (2-12 cases).' }
      },
      rocket: {
        tr: { name: 'Süper Roket', desc: 'Hedefine doğru direkt 7 adım uçar!' },
        en: { name: 'Super Rocket', desc: 'Blast forward 7 steps towards your goal!' },
        de: { name: 'Super-Rakete', desc: 'Fliege 7 Felder direkt nach vorne!' },
        es: { name: 'Súper Cohete', desc: '¡Vuela 7 casillas hacia adelante!' },
        fr: { name: 'Super Fusée', desc: 'Foncez de 7 cases directement vers l\'avant !' }
      },
      shield: {
        tr: { name: 'Manyetik Kalkan', desc: 'Tuzaklara ve altın çalma hamlelerine karşı 2 tur korur.' },
        en: { name: 'Magnetic Shield', desc: 'Protects against traps and coin steals for 2 turns.' },
        de: { name: 'Magnetschild', desc: 'Schützt 2 Runden vor Fallen und Münzdiebstahl.' },
        es: { name: 'Escudo Magnético', desc: 'Protege contra trampas y robos durante 2 turnos.' },
        fr: { name: 'Bouclier Magnétique', desc: 'Protège contre les pièges et les vols pendant 2 tours.' }
      },
      magnet: {
        tr: { name: 'Altın Mıknatısı', desc: 'Bütün rakiplerden 4\'er altın çeker!' },
        en: { name: 'Gold Magnet', desc: 'Draws 4 coins from every opponent!' },
        de: { name: 'Goldmagnet', desc: 'Zieht 4 Münzen von jedem Gegner ab!' },
        es: { name: 'Imán de Oro', desc: '¡Roba 4 monedas a cada oponente!' },
        fr: { name: 'Aimant à Pièces', desc: 'Aspire 4 pièces de chaque adversaire !' }
      },
      banana: {
        tr: { name: 'Muz Kabuğu', desc: 'Bulunduğun karoya tuzak kur; üstüne basan 3 adım geri kayar!' },
        en: { name: 'Banana Peel', desc: 'Lay a slippery trap; rivals slip back 3 steps!' },
        de: { name: 'Bananenschale', desc: 'Platziere eine Falle; wer drauftritt, rutscht 3 Felder zurück!' },
        es: { name: 'Piel de Plátano', desc: 'Pon una trampa; ¡los rivales resbalan 3 casillas atrás!' },
        fr: { name: 'Peau de Banane', desc: 'Posez un piège ; les rivaux glissent de 3 cases en arrière !' }
      },
      swap_wand: {
        tr: { name: 'Takas Asası', desc: 'İstediğin bir rakiple haritadaki yerlerini takas et!' },
        en: { name: 'Warp Wand', desc: 'Swap board positions with an opponent of your choice!' },
        de: { name: 'Tauschstab', desc: 'Tausche deine Position mit einem beliebigen Gegner!' },
        es: { name: 'Varita de Canje', desc: '¡Intercambia casillas con el oponente que elijas!' },
        fr: { name: 'Baguette d\'Échange', desc: 'Échangez votre place sur le plateau avec un rival !' }
      },
      ghost_cloak: {
        tr: { name: 'Hayalet Pelerin', desc: '2 tur boyunca hiçbir tuzaktan veya cezadan etkilenmezsin!' },
        en: { name: 'Ghost Cloak', desc: 'Bypass all traps, police and penalties for 2 turns!' },
        de: { name: 'Geisterumhang', desc: 'Ignoriere 2 Runden lang alle Fallen und Strafen!' },
        es: { name: 'Capa Fantasma', desc: '¡Inmune a trampas, multas y cárcel por 2 turnos!' },
        fr: { name: 'Cape Fantôme', desc: 'Traversez pièges et pénalités indemne pendant 2 tours !' }
      },
      lucky_die: {
        tr: { name: 'Şanslı Altın Zar', desc: 'Sıradaki zarda 1-6 arasında istediğin sayıyı sen seçersin!' },
        en: { name: 'Lucky Gold Die', desc: 'Pick your exact roll from 1 to 6 on your next turn!' },
        de: { name: 'Glückswürfel', desc: 'Wähle deine exakte Augenzahl (1-6) beim nächsten Wurf!' },
        es: { name: 'Dado Dorado de la Suerte', desc: '¡Elige tu número exacto del 1 al 6 en el próximo tiro!' },
        fr: { name: 'Dé d\'Or Porte-Bonheur', desc: 'Choisissez votre score exact de 1 à 6 au prochain lancer !' }
      }
    };
    const curLang = lang || (window.i18n ? window.i18n.getLang() : 'tr');
    if (itemTranslations[itemId] && itemTranslations[itemId][curLang]) {
      return itemTranslations[itemId][curLang];
    }
    return { name: itemId, desc: '' };
  }

  openShopModal(items, isCurrentPlayer) {
    const modal = document.getElementById('modal-shop');
    modal.classList.remove('hidden');

    const list = document.getElementById('shop-items-grid');
    list.innerHTML = '';

    const lang = (window.i18n && window.i18n.getLang()) ? window.i18n.getLang() : 'tr';
    const goldSuffix = { tr: 'Altın', en: 'Coins', de: 'Münzen', es: 'Monedas', fr: 'Pièces' };

    const myPlayer = GameClient.state.players.find(p => GameClient.player && p.sessionId === GameClient.player.sessionId);
    const myCoins = myPlayer ? myPlayer.coins : 0;

    items.forEach(item => {
      const canAfford = myCoins >= item.cost;
      const trans = this.getItemInfo(item.id, lang);
      const card = document.createElement('div');
      card.className = `shop-item-card ${!canAfford ? 'disabled' : ''}`;
      card.innerHTML = `
        <div class="shop-item-icon">${getIcon(item.icon, '🎁')}</div>
        <div class="shop-item-name">${trans.name || item.name}</div>
        <div class="shop-item-desc">${trans.desc || item.desc}</div>
        <button class="shop-buy-btn" ${(!canAfford || !isCurrentPlayer) ? 'disabled' : ''}>
          🪙 ${item.cost} ${goldSuffix[lang] || 'Altın'}
        </button>
      `;

      card.querySelector('.shop-buy-btn').onclick = () => {
        AudioPlayer.playCoinSound();
        GameClient.buyItem(item.id);
        modal.classList.add('hidden');
      };

      list.appendChild(card);
    });

    document.getElementById('btn-close-shop').onclick = () => {
      AudioPlayer.playClick();
      modal.classList.add('hidden');
      if (isCurrentPlayer) GameClient.closeShop();
    };
  }

  openInventoryModal() {
    const modal = document.getElementById('modal-inventory');
    modal.classList.remove('hidden');

    const list = document.getElementById('inventory-items-grid');
    list.innerHTML = '';

    const lang = (window.i18n && window.i18n.getLang()) ? window.i18n.getLang() : 'tr';
    const emptyMsgDict = {
      tr: 'Çantan şu an boş! Dükkandan ya da şans kutularından eşya topla.',
      en: 'Your bag is empty! Collect items from the shop or fortune tiles.',
      de: 'Dein Inventar ist leer! Sammle Gegenstände im Laden oder auf Glücksfeldern.',
      es: '¡Tu mochila está vacía! Consigue objetos en la tienda o casillas de suerte.',
      fr: 'Votre sac est vide ! Obtenez des objets à la boutique ou sur les cases chance.'
    };
    const useBtnDict = { tr: 'Kullan', en: 'Use', de: 'Nutzen', es: 'Usar', fr: 'Utiliser' };

    const state = GameClient.state;
    const myPlayer = state ? state.players.find(p => GameClient.player && p.sessionId === GameClient.player.sessionId) : null;
    const activePlayer = state ? state.players[state.turnIndex] : null;
    const isMyTurn = (myPlayer && activePlayer && myPlayer.id === activePlayer.id);

    if (!myPlayer || myPlayer.inventory.length === 0) {
      list.innerHTML = `<div class="empty-inv-msg">${emptyMsgDict[lang] || emptyMsgDict.tr}</div>`;
    } else {
      myPlayer.inventory.forEach(itemId => {
        const itemDef = SHOP_ITEMS.find(i => i.id === itemId) || { name: itemId, icon: 'dices', desc: 'Özel eşya' };
        const trans = this.getItemInfo(itemId, lang);
        const card = document.createElement('div');
        card.className = 'inventory-item-card';
        card.innerHTML = `
          <div class="inv-icon">${getIcon(itemDef.icon, '🎁')}</div>
          <div class="inv-info">
            <div class="inv-name">${trans.name || itemDef.name}</div>
            <div class="inv-desc">${trans.desc || itemDef.desc}</div>
          </div>
          <button class="inv-use-btn" ${!isMyTurn ? 'disabled' : ''}>${useBtnDict[lang] || 'Kullan'}</button>
        `;

        card.querySelector('.inv-use-btn').onclick = () => {
          modal.classList.add('hidden');
          if (itemId === 'lucky_die') {
            this.showLuckyDiePicker();
          } else if (itemId === 'swap_wand') {
            this.showSwapWandTargetPicker();
          } else {
            AudioPlayer.playStarFanfare();
            GameClient.useItem(itemId);
            const feedbackDict = {
              double_dice: {
                tr: '🎲🎲 2X Çift Zar hazır! Sıradaki turunda 2 zar birden atacaksın.',
                en: '🎲🎲 Double Dice ready! You will roll 2 dice next turn.',
                de: '🎲🎲 Doppelwürfel bereit! Du würfelst 2 Würfel.',
                es: '🎲🎲 ¡Dado Doble listo! Tirarás 2 dados.',
                fr: '🎲🎲 Double Dé prêt ! Vous lancerez 2 dés.'
              },
              rocket: {
                tr: '🚀 Roket ateşlendi! 5 kare ileri fırladın!',
                en: '🚀 Rocket fired! Blasted 5 steps forward!',
                de: '🚀 Rakete gezündet! 5 Felder nach vorne geflogen!',
                es: '🚀 ¡Cohete disparado! ¡5 casillas hacia adelante!',
                fr: '🚀 Fusée lancée ! 5 cases en avant !'
              },
              magnet: {
                tr: '🧲 Mıknatıs çekildi! Rakiplerden altın topladın.',
                en: '🧲 Magnet pulled! Collected coins from rivals.',
                de: '🧲 Magnet aktiviert! Münzen von Gegnern geholt.',
                es: '🧲 ¡Imán activado! Has atraído monedas de los rivales.',
                fr: '🧲 Aimant activé ! Pièces attirées des rivaux.'
              },
              shield: {
                tr: '🛡️ Koruma Kalkanı aktif! 2 tur tuzaklara bağışıklısın.',
                en: '🛡️ Shield active! Immune to traps for 2 turns.',
                de: '🛡️ Schild aktiv! 2 Runden vor Fallen geschützt.',
                es: '🛡️ ¡Escudo activo! Inmune a trampas por 2 turnos.',
                fr: '🛡️ Bouclier actif ! Immunisé aux pièges 2 tours.'
              },
              banana: {
                tr: '🍌 Muz Kabuğu yere bırakıldı! Arkandan gelen kayacak.',
                en: '🍌 Banana peel placed! Rivals behind will slip.',
                de: '🍌 Banane platziert! Nachfolgende rutschen aus.',
                es: '🍌 ¡Piel de plátano colocada! Quien la pise resbalará.',
                fr: '🍌 Peau de banane posée ! Les suivants glisseront.'
              },
              ghost_cloak: {
                tr: '👻 Hayalet Pelerini aktif! 2 tur tüm cezalardan ve tuzaklardan muafsın.',
                en: '👻 Ghost Cloak active! Immune to all penalties and traps for 2 turns.',
                de: '👻 Geisterumhang aktiv! 2 Runden immun gegen alle Strafen.',
                es: '👻 ¡Capa Fantasma activa! Inmune a multas y trampas por 2 turnos.',
                fr: '👻 Cape Fantôme active ! Immunisé contre tous les pièges 2 tours.'
              }
            };
            const fMsg = (feedbackDict[itemId] && feedbackDict[itemId][lang]) || (feedbackDict[itemId] && feedbackDict[itemId].tr) || '✨ Eşya kullanıldı!';
            this.showToast(fMsg, 'success');
          }
        };

        list.appendChild(card);
      });
    }

    document.getElementById('btn-close-inventory').onclick = () => {
      AudioPlayer.playClick();
      modal.classList.add('hidden');
    };
  }

  showLuckyDiePicker() {
    const modal = document.getElementById('modal-lucky-die');
    if (!modal) return;
    modal.classList.remove('hidden');

    const grid = document.getElementById('lucky-die-grid');
    grid.innerHTML = '';

    const lang = (window.i18n && window.i18n.getLang()) ? window.i18n.getLang() : 'tr';
    const stepWord = { tr: 'Adım', en: 'Steps', de: 'Schritte', es: 'Pasos', fr: 'Pas' }[lang] || 'Adım';

    const diceIcons = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
    for (let i = 1; i <= 6; i++) {
      const btn = document.createElement('button');
      btn.className = 'lucky-die-btn';
      btn.innerHTML = `<span>${diceIcons[i - 1]}</span><span class="die-dot">${i} ${stepWord}</span>`;
      btn.onclick = () => {
        AudioPlayer.playStarFanfare();
        GameClient.useItem('lucky_die', i);
        modal.classList.add('hidden');
        const lockedMsg = {
          tr: `🎯 Sıradaki zarın ${i} olarak kilitlendi! Zarı atabilirsin.`,
          en: `🎯 Next die roll locked to ${i}! Roll when ready.`,
          de: `🎯 Nächster Wurf auf ${i} fixiert! Würfle jetzt.`,
          es: `🎯 ¡Próximo dado fijado en ${i}! Tira cuando quieras.`,
          fr: `🎯 Prochain dé verrouillé à ${i} ! Lancez quand vous voulez.`
        }[lang] || `🎯 Sıradaki zarın ${i} olarak kilitlendi!`;
        this.showToast(lockedMsg, 'success');
      };
      grid.appendChild(btn);
    }

    const closeBtn = document.getElementById('btn-close-lucky-die');
    if (closeBtn) {
      closeBtn.onclick = () => {
        AudioPlayer.playClick();
        modal.classList.add('hidden');
      };
    }
  }

  showSwapWandTargetPicker() {
    const modal = document.getElementById('modal-swap-wand');
    if (!modal) return;
    modal.classList.remove('hidden');

    const list = document.getElementById('swap-wand-list');
    list.innerHTML = '';

    const lang = (window.i18n && window.i18n.getLang()) ? window.i18n.getLang() : 'tr';
    const state = GameClient.state;
    const myPlayer = state ? state.players.find(p => GameClient.player && p.sessionId === GameClient.player.sessionId) : null;
    const rivals = state ? state.players.filter(p => !myPlayer || p.id !== myPlayer.id) : [];

    const noRivalsMsg = {
      tr: 'Takas yapılabilecek başka oyuncu yok!',
      en: 'No other players available to swap with!',
      de: 'Keine anderen Spieler zum Tauschen verfügbar!',
      es: '¡No hay otros jugadores para intercambiar!',
      fr: 'Aucun autre joueur disponible pour l\'échange !'
    }[lang] || 'Takas yapılabilecek başka oyuncu yok!';

    const swapActionLabel = {
      tr: 'Konum Değiş',
      en: 'Swap Place',
      de: 'Position tauschen',
      es: 'Cambiar lugar',
      fr: 'Changer de place'
    }[lang] || 'Konum Değiş';

    if (rivals.length === 0) {
      list.innerHTML = `<div style="color:#64748B; font-size:13px; text-align:center; padding:16px;">${noRivalsMsg}</div>`;
    } else {
      rivals.forEach(r => {
        const card = document.createElement('div');
        card.className = 'swap-wand-card';
        card.innerHTML = `
          <div style="display:flex; align-items:center; min-width:0;">
            <div class="swap-wand-avatar">${r.avatar === 'cat' ? '🐱' : (r.avatar === 'dino' ? '🦖' : (r.avatar === 'ninja' ? '🥷' : '🤠'))}</div>
            <div class="swap-wand-info">
              <div class="swap-wand-name">${r.name}</div>
              <div class="swap-wand-sub">#${r.position} • ⭐${r.stars} • 🪙${r.coins}</div>
            </div>
          </div>
          <button class="swap-wand-action-btn">${swapActionLabel}</button>
        `;
        card.onclick = () => {
          AudioPlayer.playStarFanfare();
          GameClient.useItem('swap_wand', r.id);
          modal.classList.add('hidden');
          const swappedMsg = {
            tr: `🪄 ${r.name} ile konumlar takas edildi!`,
            en: `🪄 Swapped positions with ${r.name}!`,
            de: `🪄 Position mit ${r.name} getauscht!`,
            es: `🪄 ¡Has intercambiado lugares con ${r.name}!`,
            fr: `🪄 Positions échangées avec ${r.name} !`
          }[lang] || `🪄 ${r.name} ile konumlar takas edildi!`;
          this.showToast(swappedMsg, 'success');
        };
        list.appendChild(card);
      });
    }

    const closeBtn = document.getElementById('btn-close-swap-wand');
    if (closeBtn) {
      closeBtn.onclick = () => {
        AudioPlayer.playClick();
        modal.classList.add('hidden');
      };
    }
  }

  openEmoteWheel() {
    const modal = document.getElementById('modal-emotes');
    modal.classList.remove('hidden');

    const grid = document.getElementById('emotes-grid');
    grid.innerHTML = '';

    PlayerProgression.getUnlockedEmotes().forEach(em => {
      const btn = document.createElement('button');
      btn.className = 'emote-bubble-btn';
      btn.innerHTML = `<span class="em-char">${em.char}</span><span class="em-label">${em.name}</span>`;

      btn.onclick = () => {
        AudioPlayer.playEmoteReaction();
        GameClient.sendEmote(em.id);
        modal.classList.add('hidden');
      };

      grid.appendChild(btn);
    });

    document.getElementById('btn-close-emotes').onclick = () => {
      modal.classList.add('hidden');
    };
  }

  showPlayerEmote(playerId, emoteId) {
    const emDef = EMOTE_DEFS[emoteId] || { char: '👋' };
    AudioPlayer.playEmoteReaction();

    const bubble = document.createElement('div');
    bubble.className = 'floating-emote-bubble';
    bubble.innerText = emDef.char;
    document.body.appendChild(bubble);

    setTimeout(() => {
      bubble.remove();
    }, 2200);
  }

  openQrModal() {
    const modal = document.getElementById('modal-qr');
    modal.classList.remove('hidden');

    const joinUrl = `${window.location.origin}/?room=${GameClient.roomId || ''}`;
    document.getElementById('lan-qr-image').src = `/api/qr?url=${encodeURIComponent(joinUrl)}`;
    document.getElementById('lan-qr-link-text').innerText = joinUrl;

    document.getElementById('btn-copy-lan-link').onclick = () => {
      navigator.clipboard.writeText(joinUrl);
      this.showToast('Link kopyalandı!', 'success');
    };

    document.getElementById('btn-close-qr').onclick = () => {
      modal.classList.add('hidden');
    };
  }

  showMiniGameResults(data) {
    AudioPlayer.playStarFanfare();
    const rankedText = data.ranked.map((p, i) => `${i + 1}. ${p.name}: ${p.score} Puan`).join(' | ');
    this.showToast(`🏆 Mini-Oyun Sonuçları: ${rankedText}`, 'success');
  }

  showVictoryPodium(data) {
    AudioPlayer.playStarFanfare();
    const modal = document.getElementById('modal-gameover');
    modal.classList.remove('hidden');

    this.triggerConfetti();

    // Reward XP with robust fallback matching
    const me = data.leaderboard.find(p =>
      (GameClient.player && (p.sessionId === GameClient.player.sessionId || p.id === GameClient.player.id)) ||
      (p.name === PlayerProgression.profile.name)
    );

    if (me) {
      const xpResult = PlayerProgression.addXp(me.xpEarned);
      const xpRewardElem = document.getElementById('go-xp-reward');
      if (xpRewardElem) xpRewardElem.innerText = `+${me.xpEarned} XP Kazandın!`;

      const fillBar = document.getElementById('go-xp-bar-fill');
      const detail = document.getElementById('go-xp-detail');
      if (fillBar) {
        const pct = Math.min(100, Math.floor((PlayerProgression.profile.xp / PlayerProgression.profile.xpToNext) * 100));
        setTimeout(() => { fillBar.style.width = `${pct}%`; }, 150);
      }
      if (detail) {
        detail.innerText = `Lv. ${PlayerProgression.profile.level} • ${PlayerProgression.profile.xp} / ${PlayerProgression.profile.xpToNext} XP`;
      }

      if (xpResult.leveledUp) {
        AudioPlayer.playLevelUp();
        const lvlBadge = document.getElementById('go-level-up');
        if (lvlBadge) {
          lvlBadge.classList.remove('hidden');
          lvlBadge.innerHTML = `🎉 <strong>TEBRİKLER! Seviye ${xpResult.newLevel} oldun!</strong> Yeni gardırop ve unvan ödülleri açıldı!`;
        }
      }
      this.renderProfileCard();
    }

    const list = document.getElementById('go-podium-list');
    list.innerHTML = '';
    data.leaderboard.forEach((p, idx) => {
      const avatarDef = AVATAR_DEFS[p.avatar] || AVATAR_DEFS.builder;
      const card = document.createElement('div');
      card.className = `podium-rank-card rank-${idx + 1}`;
      card.innerHTML = `
        <div class="podium-badge">${idx === 0 ? '🥇 1. Şampiyon' : (idx === 1 ? '🥈 2.' : '🥉 3.')}</div>
        <div class="podium-avatar">${avatarDef.svg}</div>
        <div class="podium-pname">${p.name}</div>
        <div class="podium-score">⭐ ${p.stars} Yıldız • 🪙 ${p.coins} Altın</div>
      `;
      list.appendChild(card);
    });

    document.getElementById('btn-back-home').onclick = () => {
      modal.classList.add('hidden');
      window.location.reload();
    };
  }

  triggerConfetti() {
    const container = document.getElementById('confetti-container');
    if (!container) return;
    container.innerHTML = '';

    const colors = ['#EF4444', '#3B82F6', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899'];
    for (let i = 0; i < 70; i++) {
      const conf = document.createElement('div');
      conf.className = 'confetti-piece';
      conf.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
      conf.style.left = `${Math.random() * 100}%`;
      conf.style.animationDelay = `${Math.random() * 2}s`;
      conf.style.animationDuration = `${2 + Math.random() * 3}s`;
      container.appendChild(conf);
    }
  }

  renderEventLog(logs) {
    const feed = document.getElementById('hud-event-feed');
    if (!feed) return;
    feed.innerHTML = '';
    logs.slice(0, 3).forEach(log => {
      const item = document.createElement('div');
      item.className = 'hud-log-item';
      item.innerHTML = `<span class="log-time">${log.time}</span> ${log.text}`;
      feed.appendChild(item);
    });
  }

  showToast(text, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerText = text;
    this.toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('fade-out');
      setTimeout(() => toast.remove(), 400);
    }, 3500);
  }
}

const UI = new UIEngine();
window.UI = UI;

  </script>

  <script>
    // Initialize UI on window load
    window.addEventListener('DOMContentLoaded', () => {
      UI.init();
    });
  </script>
</body>
</html>

